# CHILDREN OF THE CITY — ANSI 终端 MV

> 都市不需要你理解，只需要你执行。

以 **Project Moon《都市》** 为背景、以 **食指（The Index）** 的"指令"为叙事框架，
为 Mili 的《Children of the City》制作的一部 **ANSI 终端 / 代码风格 MV**。

**三十三条歌词，二十五个场景，零个具象图形。** 没有手，没有心脏，没有白袍的人影——
每一个意象都由它在控制台里的**数据表示**来承担。

![总览](docs/images/00-overview.png)

---

## 这是什么

整部作品的世界观设定是：**屏幕属于食指的指令终端**。

歌词里每一句话都被当作一条 `Prescript`——由"都市的意志"签发、荒诞、不可质疑、
必须执行的命令。终端逐条打印、逐条执行，并把一切暴行写成 `exit_code: 0` 的日志：

```
[00:44.833] INFO  insides.spill() → 4.700 L
[00:48.033] INFO  viscosity: 3.2 mPa·s
[01:30.000] OK    room.status = PICTURESQUE   exit_code=0
```

这就是"代码的冰冷感"的来源：不是炫技式的赛博朋克，
而是**暴力被完整地、精确地、毫无波澜地记录进日志**的那种冷。

### 画面语言

| 歌词 | 画面里实际出现的东西 |
|---|---|
| 请在扣下扳机时使用右手 | `HAND_OCCUPANCY_REG 0x0001` —— 只有 bit0 置起的位域；"手"的形状是 35 个比特的掩码点阵 |
| 在 30 分钟内找到一名伴侣 | 一条**谓词过滤器链**：4,182,993 → 3,902,114 → … → 1 |
| 挥洒他们的内脏，将房间粉刷一新 | `WALL COVERAGE MAP` —— 覆盖率统计，1 格 = 1.5% 的墙 |
| 捡起一把刀，刺入温暖的身体 | `THERMAL PROBE ch0 @ 2.5 Hz` —— 温度采样表，逐行掉到 12.1 °C |
| 用剪刀剪开我身上的牵线 | 一次**字符串切分**：`"proxy_link:me"` 在 offset 5 处切开 |
| 又一场血仇 | `CALL GRAPH` —— 深度不断增长的**调用栈**，`base_case: UNDEFINED` |
| 都市之子目及之处，尽霓虹星光在污水沟之中闪耀 | **一段频谱**。都市的天际线就是频谱：楼有多高取决于那一刻有多少能量 |
| 在读完自然常数 e 之前不要回家 | 数字雨，`go_home_allowed: FALSE` |

### 特性

- **真彩色终端渲染**，窗口自适应——放大窗口画面是真的铺满，不是把 128×36 贴中间
- **音画同步可现场校准**：听到第一句开口时按一下 `1`，整首歌对齐
- **所有效果都是时间的纯函数**（随机性来自坐标哈希），所以能任意跳帧、分片并行渲染
- **三条输出管线共用同一块字符网格**：终端播放 / 视频渲染 / 预览出图，看到的是同一部作品
- **零第三方依赖**播放（只用标准库 + Windows MCI）；出图和渲染才需要 Pillow / numpy

---

## 快速开始

### 环境要求

- **Windows 10/11**（控制台播放器依赖 Windows API：MCI 音频、`SetConsoleOutputCP`、
  备用屏幕缓冲。渲染成视频那部分理论上跨平台，但没测过）
- **Python 3.10+**（用到了 `X | None` 这种类型标注）
- **字体**：Consolas（系统自带）+ SimHei 或微软雅黑（中文）

### 安装

```bash
git clone https://github.com/<你的用户名>/children-of-the-city-mv.git
cd children-of-the-city-mv
pip install -r requirements.txt
```

**然后自备一份音轨。** 因为版权原因，仓库里**不含** mp3，你需要自己准备：

```
assets/children_of_the_city.mp3
```

（Mili《Children of the City》，来自《废墟图书馆》原声。）

### 播放

**双击 `PLAY_MV.cmd`。** 它会先弹一个待机界面，确认窗口够大、音频就绪之后，
按任意键开始。

也可以在命令行里跑：

```bash
cd src
python play.py                 # 开屏 → 按键 → 从头播放
python play.py --no-wait       # 跳过开屏
python play.py --start 60      # 从 60 秒开始（副歌）
python play.py --offset -0.15  # 指定同步偏移（秒）
python play.py --fps 20        # 终端吃力时降帧
python play.py --record x.cast # 录成 asciinema 文件
```

![开屏](docs/images/01-standby.png)

待机界面不是装饰：**窗口不够大时 `FRAME` 那行会变红**，
你可以趁现在把窗口拖大，布局会实时重排；音频没就绪会显示成琥珀色 `UNAVAILABLE`。

### 操作

| 键 | 作用 |
|---|---|
| `空格` | 暂停 / 继续（音频一起停，画面定格） |
| `←` / `→` | 快退 / 快进 **1 秒** |
| `↑` / `↓` | 快退 / 快进 **5 秒** |
| **`1`** | **听到第一句开口的瞬间按一下 —— 校准整首歌的起点** |
| `2` | 听到副歌第一句开口的瞬间按一下 |
| `[` / `]` | 画面提前 / 延后 50 ms（最后微调） |
| `\` | 偏移归零 |
| `s` | 保存偏移到 `build/sync.json`（视频导出会读它） |
| `q` / `Esc` | 退出 |

### 导出视频

```bash
cd src
python export_video.py          # 1280×720 @ 24fps，分片并行
python preview.py --sheet       # 或者只出一张场景总览图
```

需要 **ffmpeg**：把 `ffmpeg.exe` 放到 `tools/ffmpeg/ffmpeg.exe`，或确保它在 `PATH` 里。
渲染整片约 130–140 秒（32 核，10 分片并行）。

> **改完代码看效果，直接跑 `PLAY_MV.cmd`，不用重渲视频。**
> 三条管线读的是同一块网格、同一套效果函数，所以终端里看到的就是成片的样子。

---

## 目录结构

```
children-of-the-city-mv/
├─ PLAY_MV.cmd                    双击在控制台里播放
├─ requirements.txt
├─ assets/
│  ├─ children_of_the_city.mp3    ← 自备，不进仓库
│  ├─ children_of_the_city.lrc    同步歌词（时间轴来源）
│  └─ lyrics.txt                  原始歌词（中英双语）
├─ src/
│  ├─ grid.py                     字符网格层（宽字符感知的"像素"）
│  ├─ theme.py                    配色：食指的白、都市的霓虹、血与锈
│  ├─ console.py                  控制台原语：hexdump / 位域 / 数据表 / 频谱 /
│  │                              调用栈 / 覆盖率矩阵 / 环形缓冲……
│  ├─ bigfont.py                  5×7 点阵大字
│  ├─ effects.py                  程序化视觉原语（数字雨 / 纸带 / 雨 / 故障）
│  ├─ lyrics.py                   歌词结构化：33 条指令 + 场景编排
│  ├─ scenes.py                   25 个场景的具体画面
│  ├─ director.py                 导演：时间轴调度、HUD、转场、日志填充
│  ├─ timeline.py                 时间轴读写
│  ├─ render.py                   字符网格 → 像素
│  ├─ play.py                     控制台播放器
│  ├─ export_video.py             视频导出（分片并行）
│  ├─ preview.py                  出图 / 场景总览
│  ├─ sync.py                     锚点校准：五下敲定音画同步
│  ├─ calibrate.py                逐句校准（33 下）
│  ├─ from_lrc.py                 LRC → 时间轴
│  └─ (analyze_audio / vocal / stereo_vocal / pitch_vocal /
│      detect_lines / structure / make_timeline)   音轨测量工具
├─ docs/
│  ├─ NOTES.md                    开发笔记：原理、踩坑、走过的弯路
│  └─ images/                     README 截图
├─ build/                         中间产物（不进仓库）
└─ dist/                          成品（不进仓库）
```

---

## 技术要点

**一块字符网格，三条输出管线。** 每一帧都是一块 128×36 的字符网格
（每格保存字符 + 前景色 + 背景色 + 属性）。终端播放器和视频渲染器读同一块网格。

- **所有效果都是时间的纯函数。** 随机性一律来自坐标哈希 `h01(x, y, t, seed)`，
  不是全局 `random` 状态。因此渲染可以任意跳帧、切成十片并行，每一片算出来完全一致。
- **框线和块元素不用字体画，用几何生成。** `─ │ ┌ ┐ █ ▓ ▒ ░` 直接合成掩膜，
  线条严丝合缝，不会因为字体 hinting 出现断缝。
- **字体度量是实测的。** Consolas 18pt 步进正好 10.0 px，黑体 20pt 全宽正好 20.0 px，
  所以 10×20 的格子里 ASCII 恰好一格、汉字恰好两格。
- **终端输出只重绘变化的行**，且只在颜色真的改变时才发 SGR 序列。稳态约 18 KB/帧。

更详细的实现说明、设计取舍和踩过的坑，见 **[docs/NOTES.md](docs/NOTES.md)**。

### 单帧长什么样

```
  1  d = y - horizon
  2  spread = 3.0 + d * d * 0.06
  3  for k in range(-9, 10):
  4      x = int(cx + k * spread * 0.72 + shift)
  5      g.put(x, y, "│", T.scale(color, 0.25 + d * 0.05))
```

真正执行的源码也会直接出现在画面里——比如句 14「400,000 米后右转」，
画面就是一段 `nav.c`，光标走到 `heading += 90.0` 那一行时，
右边变量表里的 `heading` 从 `27.4°` 跳到 `117.4°`：

![右转](docs/images/05-turn.png)

---

## 时间轴与音画同步

时间轴来自**公开的同步歌词（LRC）**，数据在 `assets/children_of_the_city.lrc`，
`from_lrc.py` 把它转成 `build/timeline.json`。

```
 1    16.77 →   20.21  ( 3.44 s)  Sleep for a total of 800 hours per day
 …
11    63.55 →   70.78  ( 7.23 s)  Children of the city sees only the neon stars
 …
33   194.01 →  228.09  (34.09 s)  2.71 8281 8284 5904 5235 3602 8747 1352 …
 *    80.08 →   91.58  (11.50 s)  [器乐间奏]
 *   177.40 →  188.06  (10.66 s)  [器乐间奏]
```

**如果还是对不齐**：播放时听到第一句 `Sleep for a total of 800 hours per day`
开口的那一瞬间，按一下 **`1`**。画面立刻跳到正确位置，并写回 `build/timeline.json`。

它做的是**重排主歌 1**（只动前 10 句、收在原来的副歌起点），而不是整体平移——
整体平移会连坐，让本来准的副歌也偏掉。副歌还差一点就按 `2`，
最后那一两百毫秒用 `[` `]` 抠，按 `s` 存下来。**视频导出读的是同一个文件。**

想要更彻底的对齐，还有 `sync.py`（五个时刻各敲一下空格）和 `calibrate.py`（33 下）。

---

## 常见问题

**Q：画面有方块/豆腐块？**
缺字体。装 Consolas + SimHei（或改 `src/theme.py` 里的字体名）。
符号（`◈ ✦ ✉ ☝ ✂`）会自动探测并退到 Segoe UI Windows 字体。

**Q：没有声音？**
播放器用 Windows MCI，需要 `assets/children_of_the_city.mp3`。
开屏界面里 `AUDIO` 那行会告诉你状态。

**Q：窗口最大化之后画面乱了？**
不应该。所有布局都按 `g.w` / `g.h` 重排，不假定 128×36。
如果你遇到了，请提 issue 并附上窗口尺寸（跑 `python src/diag_size.py` 会打印出来）。

**Q：能出 GIF / 视频发到网上吗？**
代码是 MIT，随便用。但**音乐和歌词的版权不在这个项目里**，
公开发布前请自行确认（见下面的「素材与版权」）。

---

## 素材与版权

- **音乐**《Children of the City》版权归 **Mili / Project Moon**，
  仓库不含音轨，请自备。本项目只做视觉呈现，不主张对音乐的任何权利。
- **歌词**版权归原作者。`assets/lyrics.txt` 与 `.lrc` 仅为技术性引用
  （时间轴对齐需要），同样不主张任何权利。
- **《都市》(The City)、食指 (The Index)、指令 (Prescript)** 等设定属于 **Project Moon**。
- **字体**均为系统字体，本项目不打包、不再分发。

**这是一个非商业的粉丝作品（fan work）。**

代码部分以 **MIT License** 授权，详见 [LICENSE](LICENSE)。

---

## 致谢

- **Mili** — 这首歌
- **Project Moon** — 《都市》的世界观
- 提供参考的 [`world.execute(me);`](https://github.com/mon/execute-me) Rust 终端实现
  （`crossterm` + `cpal`）。静态分析它的二进制后学到两点：`\x1b[?7l`（关闭自动换行）
  和「企业腔 + 方括号状态」的界面语感，都用上了。
- [lrc6.com](https://www.lrc6.com/geci/F44A8C8BA36B203C.html) — 同步歌词

---

```
C:\CITY\DISTRICT9> 致……请继续执行。▌
```

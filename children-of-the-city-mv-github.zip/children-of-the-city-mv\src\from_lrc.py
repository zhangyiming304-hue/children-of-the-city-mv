# -*- coding: utf-8 -*-
"""
from_lrc.py —— 直接用同步歌词生成时间轴。

前面几版时间轴都是我自己"量"出来的：能量包络、换气谷点、调制能量、
基频轨迹……全部不够准。根本原因很简单：**我听不见音频**，
所有推断都建立在间接特征上，误差会累积。

这一版换掉整个思路——用公开的同步歌词（LRC）。它是人工对齐的，
每一句都标了开口的时刻。数据抓自 lrc6.com 的《Children of the City》条目，
已存档到 assets/children_of_the_city.lrc。

生成规则：
  · 每句的起点 = LRC 时间
  · 每句的终点 = 下一句的起点
  · 两句之间隔得太远（> 12 s）说明中间是器乐，按本段平均句长截断，
    剩下的时间交给"器乐间奏"场景
"""

from __future__ import annotations

import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import timeline as TL  # noqa: E402

DURATION = 234.093
LRC_PATH = os.path.join(ROOT, "assets", "children_of_the_city.lrc")

# 器乐段判定阈值
INTERLUDE_GAP = 12.0


def parse_lrc(text: str):
    """[mm:ss.xxx] 歌词 → [(秒, 歌词), ...]，按时间排序。"""
    out = []
    for line in text.splitlines():
        m = re.match(r"\s*\[(\d+):(\d+(?:\.\d+)?)\]\s*(.*\S)", line)
        if m:
            t = int(m.group(1)) * 60 + float(m.group(2))
            out.append((t, m.group(3).strip()))
    out.sort(key=lambda p: p[0])
    return out


def build(entries):
    n = len(entries)
    spans = []
    interludes = []
    for i, (t, _) in enumerate(entries):
        last = i == n - 1
        nxt = entries[i + 1][0] if not last else DURATION
        if last:
            # 最后一句（e 的小数位）让数字雨一直下到尾奏，
            # 只把最后 6 秒留给关机画面
            spans.append([round(t, 3), round(DURATION - 6.0, 3), i])
            continue
        end = nxt
        # 间隔过大 → 中间是器乐。用本段（同侧）的平均句长截断。
        if nxt - t > INTERLUDE_GAP:
            # 找一个"正常"的句长作为参考：往前后各看两句
            ref = []
            for j in (i - 1, i - 2, i + 1, i + 2):
                if 0 <= j < n - 1:
                    ref.append(entries[j + 1][0] - entries[j][0])
            ref = [r for r in ref if 0.8 < r < INTERLUDE_GAP]
            step = (sum(ref) / len(ref)) if ref else 5.0
            end = round(t + step, 3)
            interludes.append([end, round(nxt, 3)])
        spans.append([round(t, 3), round(end, 3), i])
    return spans, interludes


def main():
    if not os.path.exists(LRC_PATH):
        print("[!] 找不到 %s" % LRC_PATH)
        return 1
    with open(LRC_PATH, encoding="utf-8") as f:
        entries = parse_lrc(f.read())
    import lyrics
    print("[*] LRC 行数 %d ；指令数 %d" % (len(entries), len(lyrics.PRESCRIPTS)))
    if len(entries) != len(lyrics.PRESCRIPTS):
        print("[!] 行数不一致，请检查 assets/children_of_the_city.lrc")
        return 1

    spans, interludes = build(entries)
    tl = {
        "duration": DURATION,
        "intro_end": spans[0][0],
        "outro_start": round(DURATION - 6.0, 3),
        "interludes": interludes,
        "spans": spans,
        "source": "lrc-synced",
    }
    TL.save(tl)
    print("[*] 已写出 build/timeline.json（来源：同步歌词）")
    for a, b, i in spans:
        print("   %2d  %7.2f → %7.2f  (%5.2f s)  %s"
              % (i + 1, a, b, b - a, lyrics.PRESCRIPTS[i][0][:44]))
    for a, b in interludes:
        print("    *  %7.2f → %7.2f  (%5.2f s)  [器乐间奏]" % (a, b, b - a))
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""
structure.py —— 歌曲结构分割。

不做"听感"判断，只做测量：
  1. 把音轨降采样成 0.25 秒一个的频带能量特征（log 频带）；
  2. 算自相似矩阵（余弦相似度），用棋盘核沿对角线卷积得到 novelty 曲线；
  3. novelty 的峰值就是段落边界（前奏结束、副歌进入、间奏、终章）。
另外单独算"音节起音密度"，用来判断某段到底在不在唱。

输出的东西全部是数字：都市的意志不接受形容词。
"""

from __future__ import annotations

import json
import os
import sys
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

SR = 22050
NFFT = 2048
HOP = 512
FRAME_RATE = SR / HOP

# 特征帧率：把 43fps 的频谱降采样到 4fps
FEAT_HOP = 0.25


def load_wav(path: str):
    with wave.open(path, "rb") as w:
        sr = w.getframerate()
        raw = w.readframes(w.getnframes())
    x = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    return x, sr


def stft(x: np.ndarray):
    n = 1 + (len(x) - NFFT) // HOP
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(n)[:, None]
    win = np.hanning(NFFT).astype(np.float32)
    return np.abs(np.fft.rfft(x[idx] * win, axis=1)) + 1e-10


def band_features(spec: np.ndarray, sr: int, n_bands: int = 24):
    """对数间隔频带能量 → 每帧一个 n_bands 维向量。"""
    freqs = np.fft.rfftfreq(NFFT, 1.0 / sr)
    edges = np.logspace(np.log10(60), np.log10(sr / 2 - 100), n_bands + 1)
    feats = np.zeros((spec.shape[0], n_bands), dtype=np.float32)
    for i in range(n_bands):
        m = (freqs >= edges[i]) & (freqs < edges[i + 1])
        if m.sum() == 0:
            continue
        feats[:, i] = np.log(spec[:, m].mean(axis=1) + 1e-9)
    return feats


def downsample(feats: np.ndarray, factor: int) -> np.ndarray:
    n = len(feats) // factor
    return feats[: n * factor].reshape(n, factor, feats.shape[1]).mean(axis=1)


def self_similarity(feats: np.ndarray) -> np.ndarray:
    f = feats - feats.mean(axis=0, keepdims=True)
    n = np.linalg.norm(f, axis=1, keepdims=True) + 1e-9
    fn = f / n
    return np.clip(fn @ fn.T, -1.0, 1.0)


def checkerboard_novelty(ssm: np.ndarray, k: int = 16) -> np.ndarray:
    """棋盘核沿对角线卷积 → novelty 曲线。"""
    n = ssm.shape[0]
    g = np.outer(np.hanning(2 * k + 1), np.hanning(2 * k + 1))
    sign = np.ones((2 * k + 1, 2 * k + 1), dtype=np.float32)
    sign[:k, :k] = -1
    sign[k + 1:, k + 1:] = -1
    sign[k + 1:, :k] = -1
    sign[:k, k + 1:] = -1
    kernel = g * sign
    kernel -= kernel.mean()
    nov = np.zeros(n, dtype=np.float32)
    for i in range(k, n - k):
        nov[i] = float((ssm[i - k:i + k + 1, i - k:i + k + 1] * kernel).sum())
    return nov


def onset_envelope(x: np.ndarray):
    """谱通量 → 起音包络（用来估计音节密度）。"""
    spec = stft(x)
    d = np.diff(np.log(spec), axis=0)
    flux = np.maximum(d, 0).sum(axis=1)
    flux = np.concatenate([[0.0], flux])
    t = np.arange(len(flux)) / FRAME_RATE
    return t, flux


def peaks(nov: np.ndarray, dt: float, min_dist_s: float = 4.0, thresh_k: float = 1.0):
    """novelty 峰值点。"""
    if nov.max() <= 0:
        return []
    v = nov / (nov.std() + 1e-9)
    min_dist = int(min_dist_s / dt)
    order = np.argsort(-v)
    taken = []
    for i in order:
        if v[i] < thresh_k:
            break
        if all(abs(i - j) >= min_dist for j in taken):
            taken.append(int(i))
    return sorted(taken)


def main():
    wav = os.path.join(ROOT, "build", "analysis.wav")
    x, sr = load_wav(wav)
    dur = len(x) / sr
    spec = stft(x)
    feats = band_features(spec, sr)

    factor = max(1, int(round(FEAT_HOP * FRAME_RATE)))
    fds = downsample(feats, factor)
    dt = factor / FRAME_RATE
    print("[*] 特征帧数 %d  帧长 %.3f s  总时长 %.2f s" % (len(fds), dt, dur))

    ssm = self_similarity(fds)
    k = max(4, int(round(8.0 / dt)))     # ±8 秒
    nov = checkerboard_novelty(ssm, k)
    pk = peaks(nov, dt, min_dist_s=5.0, thresh_k=0.9)
    print("[*] novelty 峰值（段落边界，秒）：")
    print("    " + ", ".join("%.2f" % (i * dt) for i in pk))

    # 起音密度：每秒的 onset 数（滑动 4 秒窗）
    t_on, flux = onset_envelope(x)
    win = int(4.0 * FRAME_RATE)
    dens = np.convolve(flux, np.ones(win) / win, mode="same")
    dens_ds = dens[::int(1.0 * FRAME_RATE)]
    dens_t = np.arange(len(dens_ds)) * 1.0
    dn = dens_ds / (dens_ds.max() + 1e-9)

    # 输出每 5 秒的 novelty 与起音密度表，方便肉眼核对
    print("\n[*] 每 5 秒：N=novelty, D=onset密度, E=带内能量（0-9，5 秒一格）")
    step = int(round(5.0 / dt))
    band = (np.fft.rfftfreq(NFFT, 1.0 / sr) >= 300) & \
           (np.fft.rfftfreq(NFFT, 1.0 / sr) <= 3400)
    energy = np.sqrt((spec[:, band] ** 2).mean(axis=1))
    e_step = int(5.0 * FRAME_RATE)
    rows = []
    for i in range(0, len(fds) - step, step):
        t0 = i * dt
        nv = float(nov[i:i + step].max())
        j = int(t0)
        dd = float(dn[j]) if j < len(dn) else 0.0
        ee = float(np.sqrt((energy[j * e_step:(j + 5) * e_step] ** 2).mean())) \
            if (j + 5) * e_step < len(energy) else 0.0
        rows.append((t0, nv, dd, ee))
    mx_n = max(r[1] for r in rows) + 1e-9
    mx_e = max(r[3] for r in rows) + 1e-9
    for i in range(0, len(rows), 6):
        chunk = rows[i:i + 6]
        print("    t=%3d  N:%s  D:%s  E:%s" % (
            int(chunk[0][0]),
            "".join(str(min(9, int(r[1] / mx_n * 10))) for r in chunk),
            "".join(str(min(9, int(r[2] * 10))) for r in chunk),
            "".join(str(min(9, int(r[3] / mx_e * 10))) for r in chunk),
        ))

    out = {
        "duration": dur,
        "dt": dt,
        "boundaries": [round(i * dt, 3) for i in pk],
        "novelty": [round(float(v), 5) for v in nov],
        "onset_density": [round(float(v), 5) for v in dens_ds],
    }
    with open(os.path.join(ROOT, "build", "structure.json"), "w", encoding="utf-8") as f:
        json.dump(out, f)
    print("\n[*] 已写出 build/structure.json")


if __name__ == "__main__":
    main()

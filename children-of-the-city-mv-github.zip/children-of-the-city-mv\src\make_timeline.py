# -*- coding: utf-8 -*-
"""
make_timeline.py —— 把测量结果钉成时间轴。

锚点来自对音轨的测量（能量包络 + 句间换气谷点）：

    · 主歌句长约 4.5 s（谷点间隔 4.2–4.6 s，非常稳定）
    · 副歌句长约 7.7 s（谷点间隔 6.3–7.0 s，旋律拉长）
    · 7.4 s 处第一句进入；55.0 s 副歌进入；78.0 s 回到主歌；
      146.0 s 第二次副歌
    · 主歌 2 共 15 句、68 秒 → 4.53 s/句，与主歌 1 的 4.76 s/句 同一量级
    · 169–195 s 是器乐间奏（终端在此等待下一条指令）
    · 195 s 起是终章，230 s 之后是尾奏

生成的 build/timeline.json 可以被 calibrate.py 覆盖成实测值。
"""

from __future__ import annotations

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

from lyrics import PRESCRIPTS  # noqa: E402
import timeline as TL  # noqa: E402

DURATION = 234.093

# (起始, 结束, 指令序号列表)
#
# 第一句定在 16.50 s —— 这个值来自实际听感（用户听到第一句开口在 17 秒左右），
# 并且与信号分析对得上：中频能量在 16-18 s 从 3.6 跳到 6.4。
# 我之前把它估成 7.40 s，整整早了 9.6 秒，这是音画对不上的主要原因。
#
# 剩下两个锚点用"自洽性"反推：两段主歌的句长必须接近。
#   主歌 1：16.50 → 60.00 = 43.5 s ÷ 10 句 = 4.35 s/句
#   主歌 2：81.00 → 146.00 = 65.0 s ÷ 15 句 = 4.33 s/句   ← 几乎相同
# 而副歌的落点（60 s 与 146 s）正好压在音频能量包络的两个峰上
# （55–80 s 与 145–180 s 是整首歌最满的两段）。
ANCHORS = [
    (16.50, 60.00, list(range(0, 10))),    # 主歌 1：十句
    (60.00, 81.00, list(range(10, 13))),   # 副歌 1：三句
    (81.00, 146.00, list(range(13, 28))),  # 主歌 2：十五句
    (146.00, 169.00, list(range(28, 31))),  # 副歌 2：三句
    (195.00, 207.00, [31]),               # 终章：读完 e 之前不要回家
    (207.00, 230.00, [32]),               # 终章：e 的小数位
]

INTRO_END = 16.50
OUTRO_START = 230.00
# 器乐间奏
INTERLUDES = [(169.00, 195.00)]


def weight(en: str, zh: str) -> float:
    """
    段内每句分到多少时间。

    这里**故意均匀分配**。一开始我按歌词字数加权，结果对不上：
    拿去和音频里测出来的句间谷点一比，发现句长和字数几乎无关——
    "Now it's time for another vendetta" 只有 34 个字，却占了 7.6 秒；
    "And with your dreams on the floor you comply…" 有 71 个字，只占 6.1 秒。
    流行歌里一段的每句通常落在同样的小节数上，所以等分才是对的。
    加权分配会让误差一路累积到三秒以上。
    """
    return 1.0


def build() -> dict:
    spans = []
    for t0, t1, idxs in ANCHORS:
        ws = [weight(*PRESCRIPTS[i]) for i in idxs]
        tot = sum(ws)
        span = t1 - t0
        acc = 0.0
        for i, w in zip(idxs, ws):
            a = t0 + span * acc / tot
            acc += w
            b = t0 + span * acc / tot
            spans.append([round(a, 3), round(b, 3), i])
    spans.sort(key=lambda s: s[0])
    return {
        "duration": DURATION,
        "intro_end": INTRO_END,
        "outro_start": OUTRO_START,
        "interludes": [[round(a, 3), round(b, 3)] for a, b in INTERLUDES],
        "spans": spans,
        "source": "audio-anchored",
    }


def main():
    tl = build()
    TL.save(tl)
    print("[*] 时间轴：%d 条指令，%d 段间奏" % (len(tl["spans"]), len(tl["interludes"])))
    for a, b, i in tl["spans"]:
        en = PRESCRIPTS[i][0]
        print("   %2d  %7.2f → %7.2f  (%4.2f s)  %s" % (i + 1, a, b, b - a, en[:56]))
    for a, b in tl["interludes"]:
        print("    *   %7.2f → %7.2f  (%4.2f s)  [器乐间奏]" % (a, b, b - a))
    print("\n[*] 已写出 build/timeline.json")


if __name__ == "__main__":
    main()

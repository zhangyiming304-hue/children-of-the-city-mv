@echo off
rem ===================================================================
rem  CHILDREN OF THE CITY - ANSI MV  /  INDEX PRESCRIPT TERMINAL
rem
rem  This launcher obeys three rules, each learned the hard way:
rem
rem   1. PURE ASCII. cmd.exe reads a .cmd file using the system ANSI
rem      codepage (936 on this machine). UTF-8 Chinese inside would be
rem      mis-decoded and split echo lines into stray commands.
rem
rem   2. CRLF LINE ENDINGS. With bare LF, cmd.exe mis-parses multi-line
rem      "( ... )" blocks and runs them from the middle.
rem
rem   3. NO "chcp" ANYWHERE. Changing the codepage while cmd.exe is
rem      streaming this file makes it lose its read offset. play.py
rem      calls SetConsoleOutputCP(65001) itself instead.
rem
rem  For the same reason this file uses GOTO rather than "( ... )" blocks.
rem ===================================================================
setlocal
title CHILDREN OF THE CITY - ANSI MV
cd /d "%~dp0src"
if errorlevel 1 goto nocwd

set "PY="
py -3 --version >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if defined PY goto havepy
python --version >nul 2>nul
if not errorlevel 1 set "PY=python"
:havepy
if not defined PY goto nopy

%PY% play.py %*
set "RC=%ERRORLEVEL%"
if "%RC%"=="0" goto done

echo.
echo   ------------------------------------------------------------
echo    play.py exited with code %RC%
echo.
echo    2 = console window too small for a 128x36 frame
echo        drag the window bigger, or press Alt+Enter for fullscreen
echo    1 = a Python error was printed above
echo.
echo    If the colours look wrong, try running this in Windows Terminal.
echo   ------------------------------------------------------------

:done
echo.
pause
exit /b %RC%

:nocwd
echo.
echo   Cannot enter the "src" folder next to this file.
echo.
pause
exit /b 1

:nopy
echo.
echo   ------------------------------------------------------------
echo    Python was not found.
echo.
echo    Install Python 3.10+ from https://www.python.org/downloads/
echo    and tick "Add python.exe to PATH" during setup.
echo   ------------------------------------------------------------
echo.
pause
exit /b 1

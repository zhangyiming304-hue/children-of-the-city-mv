# -*- coding: utf-8 -*-
"""
director.py —— 导演。

负责把"时间"翻译成"画面"：
  · 决定此刻是哪一条指令、指令内的进度是多少
  · 画出 HUD：终端顶栏、指令编号、合规度、进度条、滚动日志
  · 处理转场（白闪、故障、指令横幅滑入）
  · 开场自检序列与终章的关机序列

画面分辨率固定为 128×36 个字符格，
这样终端播放器、HTML 导出、视频渲染看到的是同一部作品。
"""

from __future__ import annotations

import math

import effects as fx
import scenes
import theme as T
from grid import CONTINUE, Grid, text_width
from lyrics import BINARY_DIGITS as BIN, PRESCRIPTS, SCENE_PLAN, SEVERITY

W, H = 128, 36   # 设计基准；实际画布尺寸由调用方决定

# 指令切换时的白色闪光时长
FLASH = 0.30


# ----------------------------------------------------------------------
# 环境
# ----------------------------------------------------------------------

class Env:
    __slots__ = ("t", "lt", "dur", "prog", "idx", "total", "en", "zh", "scene",
                 "shown_en", "shown_zh", "all_en", "all_zh", "W", "H",
                 "ay1", "aw",
                 # 关键读数行：扫描线要跳过，否则同一个数字
                 # 在进度条和右下角会被压成两种颜色
                 "keep_rows")

    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)


# ----------------------------------------------------------------------
# 日志：把暴行写成一行行 INFO
# ----------------------------------------------------------------------

LOGS = {
    "slip": [
        (0.00, "INFO ", "prescript.receive() → checksum OK"),
        (0.28, "WARN ", "feasibility_check: FAILED (ignored by design)"),
        (0.62, "INFO ", "acknowledgement: implied by reading"),
    ],
    "rule": [
        (0.05, "INFO ", "enforcing call convention: right_hand_only"),
        (0.45, "INFO ", "left_hand.calls = 0 since boot"),
        (0.80, "WARN ", "exception_request_channel: CLOSED"),
    ],
    "comply": [
        (0.00, "INFO ", "compliance monitor started"),
        (0.40, "INFO ", "queue.length = %d (never decreases)"),
        (0.75, "WARN ", "deviation: 0.000% — nothing to correct"),
    ],
    "desk": [
        (0.05, "INFO ", "desk.lock: ENGAGED"),
        (0.40, "INFO ", "dreams → /dev/null  (moved, not deleted)"),
        (0.70, "WARN ", "free_will: not found — retrying (attempt %d)"),
    ],
    "target": [
        (0.00, "INFO ", "target_acquisition: scanning 4,182,993 candidates"),
        (0.35, "INFO ", "hair.color == BRUNETTE → bonus +1"),
        (0.60, "WARN ", "deadline in 30:00 — selection is mandatory"),
    ],
    "picturesque": [
        (0.10, "INFO ", "insides.spill() → 4.7 L"),
        (0.45, "INFO ", "wall.coverage: 82% → 100%"),
        (0.80, "OK   ", "room.status = PICTURESQUE  exit_code=0"),
    ],
    "vendetta": [
        (0.05, "INFO ", "vendetta(n=%d) invoked"),
        (0.55, "WARN ", "RecursionError ignored — no base case defined"),
        (0.85, "INFO ", "stack depth: ∞"),
    ],
    "shelves": [
        (0.00, "INFO ", "loading persona catalogue (%d entries)"),
        (0.45, "INFO ", "persona.select(auto=true)"),
        (0.80, "INFO ", "you were never the author of this choice"),
    ],
    "neon": [
        (0.05, "INFO ", "neon.intensity: 4.20 cd/m²"),
        (0.40, "INFO ", "gutter.reflectance: 0.31"),
        (0.75, "WARN ", "sky: not visible from this district"),
    ],
    "gutter": [
        (0.05, "INFO ", "depth: 2.4 m — 一切倒影在这里汇合"),
        (0.45, "INFO ", "turbidity: 31 NTU — 影像被水波揉碎"),
        (0.80, "WARN ", "sky: not visible from below the surface"),
    ],
    "eyes": [
        (0.00, "INFO ", "surveillance.coverage: 100%"),
        (0.40, "WARN ", "observer_count: 都市"),
        (0.75, "INFO ", "being_seen requires no reason"),
    ],
    "highway": [
        (0.00, "INFO ", "navigation source: WILL_OF_THE_CITY"),
        (0.50, "INFO ", "distance_remaining: %d m"),
        (0.90, "OK   ", "turn right in 0 m — stopping not allowed"),
    ],
    "warmbody": [
        (0.20, "INFO ", "body.warmth: %.1f °C → ambient"),
        (0.55, "INFO ", "familiarity: 0.98 (does not affect priority)"),
        (0.85, "OK   ", "warm_body.stab()  exit_code=0"),
    ],
    "coffee": [
        (0.10, "INFO ", "bitterness(love) shares register with bitterness(coffee)"),
        (0.55, "INFO ", "fight.exe loaded before love.dll"),
        (0.85, "INFO ", "caffeine: irrelevant"),
    ],
    "strings": [
        (0.10, "INFO ", "proxy_link: %s"),
        (0.50, "INFO ", "scissors.cut(strings) — unplanned, unsanctioned"),
        (0.85, "WARN ", "free_choice.verify() → still by proxy"),
    ],
    "proxy": [
        (0.00, "INFO ", "call stack depth: 6  (you are at the bottom)"),
        (0.45, "INFO ", "degrees_of_freedom: 0"),
        (0.80, "INFO ", "the script was compiled before you were born"),
    ],
    "pacifier": [
        (0.05, "INFO ", "feeding: 9mm × ∞"),
        (0.45, "INFO ", "first_word: \"expand\""),
        (0.80, "WARN ", "purpose: NULL for %d subjects"),
    ],
    "expand": [
        (0.10, "INFO ", "growth_rate: unbounded"),
        (0.55, "INFO ", "carrying_capacity: exceeded"),
        (0.85, "WARN ", "stop_condition: undefined"),
    ],
    "burnout": [
        (0.10, "FATAL", "will_to_stay_afloat: OVERFLOW"),
        (0.45, "WARN ", "backfire.detected at 0x00C17Y"),
        (0.80, "OK   ", "residual_will: 0.00 mL recovered"),
    ],
    "mirror": [
        (0.10, "INFO ", "diff ideal_self actual_self → 3 hunks"),
        (0.50, "WARN ", "the two documents share one body"),
        (0.85, "INFO ", "apply_patch(actual_self) — no rollback"),
    ],
    "ribbon": [
        (0.05, "INFO ", "ribbon: 都市 → you"),
        (0.50, "INFO ", "follow the ribbon"),
        (0.85, "INFO ", "destination: a heart with no listeners"),
    ],
    "heart": [
        (0.10, "INFO ", "inbox: 0 messages, 0 listeners"),
        (0.50, "INFO ", "heart_rate: %d bpm"),
        (0.85, "WARN ", "nobody is listening on this port"),
    ],
    "fracture": [
        (0.05, "INFO ", "crack #1 → REPAIRED"),
        (0.45, "INFO ", "crack #%d → OPEN"),
        (0.80, "WARN ", "total_cracks: uncountable"),
    ],
    "recursion": [
        (0.05, "INFO ", "suffering(t) = suffering(t-1) + me"),
        (0.50, "FATAL", "not convergent — terminating condition is me"),
        (0.85, "INFO ", "self: still present"),
    ],
    "value_e": [
        (0.05, "INFO ", "task: READ_ALL_DIGITS_OF_E"),
        (0.50, "WARN ", "digits_total: INFINITE — eta: --:--:--"),
        (0.85, "OK   ", "go_home_allowed = FALSE"),
    ],
    "e_flood": [
        (0.10, "WARN ", "digit_buffer: OVERFLOW"),
        (0.50, "FATAL", "reading e is not a terminating task"),
        (0.85, "OK   ", "compliance forced to 100.000%"),
    ],
}


SYSLOG = [
    ("DEBUG", "heap.scan() -> 0x{a} .. 0x{b}000  ({c} B)"),
    ("TRACE", "queue.depth = {d}"),
    ("DEBUG", "free_will.probe() -> NULL"),
    ("TRACE", "compliance.recheck() -> 100.000%"),
    ("DEBUG", "stack.usage = {d} / 64 frames"),
    ("TRACE", "observation.count = {c}"),
    ("DEBUG", "memory.resident = {c} KiB"),
    ("TRACE", "scheduler.tick = {c}"),
    ("DEBUG", "prescript.checksum = 0x{a}"),
    ("TRACE", "io.wait = {d} ms"),
    ("DEBUG", "obedience.module = ARMED"),
    ("TRACE", "city.will.poll() -> pending"),
    ("DEBUG", "district9.link = STABLE ({d} ms)"),
    ("TRACE", "neon.sensor[{d}] = {b}"),
    ("DEBUG", "gutter.level = 0.{b} m"),
    ("TRACE", "prescript.seq -> {c}"),
    ("WARN ", "deviation.detected -> auto-corrected"),
    ("DEBUG", "proxy.link[{d}] = INTACT"),
    # 下面几条是给同行看的：都市本身就是个不肯修 bug 的系统
    ("TRACE", "git blame -> {d} authors, 1 still alive"),
    ("WARN ", "deprecated call: hope()"),
    ("DEBUG", "// TODO: fix this before the next audit"),
    ("DEBUG", "// FIXME: there is nothing to fix"),
    ("TRACE", "refcount[{d}] = 0, object freed"),
    ("WARN ", "retry {d}/3: connection to self refused"),
    ("DEBUG", "gc.collect() -> {d} objects unreachable"),
    ("TRACE", "0xDEADBEEF leaked into user space"),
]


def pick_log(scene: str, lt: float, dur: float, idx: int, t: float):
    """按局部时间挑一条日志。"""
    entries = LOGS.get(scene)
    if not entries:
        return None
    prog = lt / max(0.001, dur)
    chosen = None
    for rel, lvl, text in entries:
        if prog >= rel:
            chosen = (lvl, text)
    if chosen is None:
        return None
    lvl, text = chosen
    text = text.replace("%d", str(int(t * 7) % 97 + 3)) if "%d" in text else text
    if "%.1f" in text:
        # 用 warmbody 的体温函数，不然画面上的 CORE TEMP 和日志会对不上
        text = text % scenes._core_temp(prog)
    if "%s" in text:
        text = text % ("SEVERED" if prog > 0.42 else "ATTACHED")
    return lvl, text


# ----------------------------------------------------------------------
# 导演
# ----------------------------------------------------------------------

def _plate(g: Grid, y: int, text: str, color, attr: int = 0) -> None:
    """居中写一行字，先铺一条底色。

    开场背景是实心天际线，不铺底的话楼体会从字缝里钻出来。
    注意别和 Director._banner 混了——那个是转场横幅。
    """
    w = text_width(text)
    x = max(0, (g.w - w) // 2)
    g.fill_rect(x - 2, y, w + 4, 1, " ", None, T.BG)
    g.put(x, y, text, color, T.BG, attr)


class Director:
    def __init__(self, timeline):
        self.tl = timeline
        self.duration = timeline["duration"]
        self.spans = timeline["spans"]           # [(t0, t1, idx), ...]
        self.interludes = timeline.get("interludes", [])
        self.intro_end = timeline["intro_end"]
        self.outro_start = timeline["outro_start"]
        self.source = timeline.get("source", "?")
        self.all_en = [p[0] for p in PRESCRIPTS]
        self.all_zh = [p[1] for p in PRESCRIPTS]
        self._cache = {}

    # ---------- 时间定位 ----------

    def locate(self, t: float):
        """
        返回 (idx, lt, dur)。
        idx 为 None → 开场或终章；idx 为 -1 → 器乐间奏。
        """
        for a, b, i in self.spans:
            if a <= t < b:
                return i, t - a, max(0.001, b - a)
        if t < self.spans[0][0]:
            return None, t, self.intro_end
        if t >= self.outro_start:
            return None, t - self.outro_start, max(0.001, self.duration - self.outro_start)
        # 落在两段之间 = 器乐间奏
        for a, b in self.interludes:
            if a <= t < b:
                return -1, t - a, max(0.001, b - a)
        return -1, t, 1.0

    # ---------- 主入口 ----------

    def frame(self, t: float, cols: int | None = None,
              lines: int | None = None) -> Grid:
        """
        生成一帧。

        cols/lines 是**终端窗口**的字符尺寸。整个画面——顶栏、内容区、
        歌词、进度条、日志——都按这个尺寸重排，所以全屏时是真的铺满，
        而不是把 128×36 贴在中間。视频渲染传 128×36（设计基准）。
        """
        cols = max(40, int(cols or W))
        lines = max(12, int(lines or H))
        g = Grid(cols, lines)
        self._draw(g, t)
        return g

    def _draw(self, g: Grid, t: float) -> None:
        """把这一帧画到给定尺寸的网格上。"""
        g.clear(T.BG)
        idx, lt, dur = self.locate(t)
        prog = min(1.0, max(0.0, lt / dur))

        if idx is None:
            if t < self.intro_end:
                self._intro(g, t, self.intro_end)
            else:
                self._outro(g, lt, dur)
            return

        if idx == -1:
            self._interlude(g, t, lt, dur)
            self._global_finish(g, t)
            return

        scene = SCENE_PLAN[idx]
        en, zh = PRESCRIPTS[idx]
        e = Env(t=t, lt=lt, dur=dur, prog=prog, idx=idx, total=len(PRESCRIPTS),
                en=en, zh=zh, scene=scene,
                shown_en=scenes.typed_count(en, prog, 0.06, 0.66),
                shown_zh=scenes.typed_count(zh, prog, 0.14, 0.74),
                all_en=self.all_en, all_zh=self.all_zh,
                W=g.w, H=g.h, ay1=g.h - 7, aw=g.w)

        e.keep_rows = ()
        scenes.SCENES[scene](g, e)
        self._tail_fill(g, e)

        self._hud(g, t, e)
        self._transition(g, t, lt, idx, scene)
        self._global_finish(g, t, e.keep_rows)

    # ---------- 会话日志：自动填满场景留下的空白行 ----------

    @staticmethod
    def _blank_row(g: Grid, y: int, tolerance: int = 2) -> bool:
        """
        这一行是否基本空着（容忍少数穿过的竖线、边框）。

        注意也要看**底色**：食指的指令纸条是一整块米白背景、字符全是空格，
        只检查字符会把它当成空行，日志就会印到纸上。
        """
        base = y * g.w
        used = 0
        for x in range(2, g.w - 2):
            i = base + x
            occupied = g.ch[i] not in (" ", CONTINUE)
            if not occupied:
                b = g.bg[i]
                occupied = b is not None and b != T.BG
            if occupied:
                used += 1
                if used > tolerance:
                    return False
        return True

    def _tail_fill(self, g: Grid, e: Env) -> None:
        """
        终端不会留白。

        场景画完之后，剩下没被占用的行用两种东西填满：
        先填这个场景**真实产生**的会话日志，再往下填系统自身的例行输出
        （堆扫描、队列深度、合规复查、观察者计数……）。

        这些例行输出全部是时间的确定函数（坐标哈希），
        所以同一帧无论渲染多少次、切成几片并行算，结果都一模一样。
        """
        row = e.ay1 - 2
        entries = LOGS.get(e.scene, [])
        hist = [(rel, lvl, txt) for rel, lvl, txt in entries
                if e.lt / max(0.001, e.dur) >= rel]
        k = 0
        for rel, lvl, text in reversed(hist):
            while row > 4 and not self._blank_row(g, row):
                row -= 1
            if row <= 4:
                return
            ts = e.t - e.lt + e.dur * rel
            if "%d" in text:
                text = text.replace("%d", str(int(e.t * 7) % 97 + 3))
            if "%.1f" in text:
                # 同上：和画面上那条 CORE TEMP 必须一致
                text = text % scenes._core_temp(e.lt / max(0.001, e.dur))
            if "%s" in text:
                text = text % ("SEVERED" if e.prog > 0.42 else "ATTACHED")
            c = {"INFO ": T.STEEL, "WARN ": T.AMBER, "OK   ": T.TERM_GREEN,
                 "FATAL": T.BLOOD}[lvl]
            g.fill_rect(0, row, g.w, 1, " ", None, T.BG)
            g.put(2, row, self._stamp(ts), T.DIM2, T.BG)
            g.put(14, row, lvl, c, T.BG)
            g.put(20, row, text[:g.w - 42], T.ASH, T.BG)
            # 行尾补一个右对齐读数，别让右边空出一截
            tail = "%08X" % int(fx.h01(row, int(ts * 4), 53) * 0xFFFFFFFF)
            g.put(g.w - len(tail), row, tail, T.DIM2, T.BG)
            row -= 1
            k += 1
        # 剩下的行交给系统例行输出，一直填到内容区顶部
        while row > 4:
            if self._blank_row(g, row):
                self._syslog_row(g, row, e.t, k, e.ay1)
                k += 1
            row -= 1

    @staticmethod
    def _stamp(ts: float) -> str:
        return "[%02d:%02d.%03d]" % (int(ts // 60), int(ts % 60),
                                     int(ts * 1000) % 1000)

    def _syslog_row(self, g: Grid, row: int, t: float, k: int,
                    ay1: int) -> None:
        """一条确定性的系统例行输出。越往上越暗，像滚出屏幕的旧记录。"""
        q = int(t * 8)
        i = int(fx.h01(q, k, 11) * len(SYSLOG))
        lvl, tpl = SYSLOG[i]
        a = int(fx.h01(q, k, 21) * 0xFFFFFFFF)
        b = int(fx.h01(q, k, 31) * 0xFFFF)
        c = int(fx.h01(q, k, 41) * 5000)
        text = tpl.replace("{a}", "%08X" % a).replace("{b}", "%04X" % b)
        text = text.replace("{c}", str(c)).replace("{d}", str(c % 97 + 3))
        depth = max(0, ay1 - 3 - row)
        fade = max(0.30, 0.80 - depth * 0.055)
        c1 = {"DEBUG": T.STEEL, "TRACE": T.DIM2, "INFO ": T.DIM2,
              "WARN ": T.AMBER}[lvl]
        g.put(2, row, self._stamp(t - k * 0.037), T.scale(T.DIM2, fade), T.BG)
        g.put(14, row, lvl, T.scale(c1, fade), T.BG)
        g.put(20, row, text[:g.w - 42], T.scale(T.DIM, fade), T.BG)
        tail = "%08X" % int(fx.h01(row, q, 59) * 0xFFFFFFFF)
        g.put(g.w - len(tail), row, tail, T.scale(T.DIM2, fade), T.BG)


    def _interlude(self, g: Grid, t: float, lt: float, dur: float) -> None:
        """器乐间奏：都市在这段时间里不说话，终端在等。"""
        # 只要数字雨。原来底下压着城市天际线 + 斜向雨丝 + 压暗层，
        # 三层叠在一起就是一片糊；现在雨也调密调快了些，撑得住整个画面。
        fx.digits_rain(g, t, BIN, speed=scenes.RAIN_SPEED * 2.2, density=0.30,
                       trail=20, seed=9, col_gap=2, body_color=T.TERM_GREEN,
                       fade_to=T.scale(T.TERM_GREEN, 0.25),
                       y0=2, y1=g.h - 7)

        _plate(g, 2 + 9, "I N T E R L U D E", T.scale(T.BONE, 0.85), attr=1)
        _plate(g, 2 + 11, "─" * 30, T.DIM2)
        # 间奏也按食指的格式写成一条指令：致…… 后面才是内容
        _plate(g, 2 + 15, "致 ……", T.ASH, attr=1)
        _plate(g, 2 + 17, "在下一道指令抵达之前，保持安静。", T.DIM)
        blink = int(t * 2) % 2 == 0
        _plate(g, 2 + 20, "AWAITING NEXT PRESCRIPT" + ("_" if blink else " "),
               T.TERM_GREEN)

        # HUD
        g.put(1, 0, "//PRESCRIPT_TERMINAL", T.WHITE_HOT, attr=1)
        g.put(31, 0, "v2.71.8281", T.DIM2)
        g.put(46, 0, "◈ QUEUE PAUSED", T.STEEL)
        right = "WILL OF THE CITY ▏LISTENING"
        g.put(g.w - 1 - text_width(right), 0, right, T.STEEL)
        g.hline(0, 1, g.w, "─", T.DIM2)
        g.put(1, 1, "┤ ", T.DIM2)
        g.put(3, 1, "INTERLUDE / NO PRESCRIPT", T.STEEL)
        g.hline(0, g.h - 7, g.w, "─", T.DIM2)

        total = self.duration
        el = "%02d:%02d" % (int(t // 60), int(t % 60))
        tt = "%02d:%02d" % (int(total // 60), int(total % 60))
        # 只留时间，不做进度条
        g.put(1, g.h - 3, "▶ %s / %s" % (el, tt), T.STEEL, attr=1)
        comp = "COMPLIANCE 100.000%"
        g.put(g.w - 1 - text_width(comp), g.h - 3, comp, T.TERM_GREEN)
        stamp = "[%02d:%02d.%03d]" % (int(t // 60), int(t % 60), int((t * 1000) % 1000))
        g.put(1, g.h - 2, stamp, T.DIM2)
        g.put(13, g.h - 2, "IDLE ", T.STEEL, attr=1)
        g.put(19, g.h - 2, "指令队列空转中 — 都市意志正在起草下一条", T.ASH)
        _pid = "PID 4821  TID 000"
        g.put(g.w - 1 - text_width(_pid), g.h - 2, _pid, T.DIM2)

    # ---------- HUD ----------

    def _hud(self, g: Grid, t: float, e: Env) -> None:
        # 歌词区与状态栏先铺一层底，保证任何场景下都读得清
        g.fill_rect(0, g.h - 6, g.w, 2, " ", None, T.BG)
        g.fill_rect(0, g.h - 3, g.w, 2, " ", None, T.BG)

        # 顶栏
        g.put(1, 0, "//PRESCRIPT_TERMINAL", T.WHITE_HOT, attr=1)
        g.put(31, 0, "v2.71.8281", T.DIM2)
        sev = SEVERITY.get(e.scene, "MANDATORY")
        sev_c = {"TRIVIAL": T.STEEL, "AMBIENT": T.STEEL, "MANDATORY": T.BONE,
                 "URGENT": T.AMBER, "CRITICAL": T.BLOOD,
                 "FATAL": T.BLOOD, "IMPOSSIBLE": T.NEON_MAG}[sev]
        g.put(46, 0, "◈ PRESCRIPT %02d/%02d" % (e.idx + 1, e.total), T.WHITE)
        g.put(70, 0, "SEVERITY " + sev, sev_c)
        right = "WILL OF THE CITY ▏ACTIVE"
        g.put(g.w - 1 - text_width(right), 0, right, T.STEEL)

        g.hline(0, 1, g.w, "─", T.DIM2)
        g.put(1, 1, "┤ ", T.DIM2)
        g.put(3, 1, "PRESCRIPT TERMINAL", T.STEEL)

        # 指令横幅（转场期间滑入）
        if e.lt < 1.1:
            self._banner(g, e, e.lt)

        g.hline(0, g.h - 7, g.w, "─", T.DIM2)

        # 歌词：英文 + 中文译本
        en, zh = e.en, e.zh
        ex = (g.w - text_width(en)) // 2
        sh = e.shown_en
        if sh > 0:
            g.put(ex, g.h - 6, en[:sh], T.WHITE_HOT, attr=1)
            if sh < len(en):
                g.put(ex + text_width(en[:sh]), g.h - 6, "▌", T.NEON_CYAN)
        zx = (g.w - text_width(zh)) // 2
        shz = e.shown_zh
        if shz > 0:
            g.put(zx, g.h - 5, zh[:shz], T.PAPER)
            if shz < len(zh):
                g.put(zx + text_width(zh[:shz]), g.h - 5, "▌", T.BLOOD)

        # 进度条
        total = self.duration
        el = "%02d:%02d" % (int(t // 60), int(t % 60))
        tt = "%02d:%02d" % (int(total // 60), int(total % 60))
        # 只留时间，不做进度条
        g.put(1, g.h - 3, "▶ %s / %s" % (el, tt), T.STEEL, attr=1)

        # 合规度。平时永远是 100%——偏差总会被"纠正"；
        # 但念 e 那段是例外：读不完的指令，合规度也撑不住。
        # 这里和场景里那条进度条共用 _e_progress，两处读数始终一致。
        if e.scene == "e_flood":
            # 和场景里那条进度条**完全同步**：读了多少，就算合规多少。
            # 两处读数同一个来源，永远不会打架。
            _r, _q, _frac = scenes._e_progress(e.lt)
            comp_v = _frac * 100.0
        else:
            dev = 0.42 * math.exp(-e.lt * 2.6) if e.lt < 3 else 0.0
            comp_v = 100.0 - dev
        comp = "COMPLIANCE %.3f%%" % comp_v
        # 念 e 那段直接借场景里的颜色函数，两处颜色永远一致；
        # 平时还是老规矩：满值绿，出了偏差转琥珀。
        if e.scene == "e_flood":
            cc = scenes._e_color(_frac)
        else:
            cc = T.TERM_GREEN if comp_v > 99.0 else T.AMBER
        g.put(g.w - 1 - text_width(comp), g.h - 3, comp, cc)
        if 0.02 < e.lt < 0.06:
            g.put(g.w - 1 - text_width(comp) - 14, g.h - 3, "CORRECTING…", T.BLOOD)

        # 日志
        lg = pick_log(e.scene, e.lt, e.dur, e.idx, t)
        stamp = "[%02d:%02d.%03d]" % (int(t // 60), int(t % 60), int((t * 1000) % 1000))
        g.put(1, g.h - 2, stamp, T.DIM2)
        if lg:
            lvl, text = lg
            c = {"INFO ": T.STEEL, "WARN ": T.AMBER, "OK   ": T.TERM_GREEN,
                 "FATAL": T.BLOOD}[lvl]
            g.put(13, g.h - 2, lvl, c, attr=1)
            g.put(19, g.h - 2, text, T.ASH)
        _pid = "PID 4821  TID %d" % (e.idx * 7 % 97)
        g.put(g.w - 1 - text_width(_pid), g.h - 2, _pid, T.DIM2)

    def _banner(self, g: Grid, e: Env, lt: float) -> None:
        """新指令滑入时的横幅。"""
        y = 2
        k = min(1.0, lt / 0.5)
        slide = int((1.0 - k) * -10)
        txt = "☝ PRESCRIPT #%02d" % (e.idx + 1)
        sev = SEVERITY.get(e.scene, "MANDATORY")
        line = txt + "   " + "─" * 3 + "   " + sev + "   " + "─" * 3 + "   ISSUED BY WILL_OF_THE_CITY"
        x = max(0, (g.w - text_width(line)) // 2 + slide)
        g.fill_rect(0, y, g.w, 1, " ", bg=T.BG)
        g.put(x, y, line, T.WHITE_HOT if k > 0.5 else T.ASH, T.BG, attr=1)

    # ---------- 转场与全局 ----------

    def _transition(self, g: Grid, t: float, lt: float, idx: int, scene: str) -> None:
        sev = SEVERITY.get(scene, "MANDATORY")
        if lt < FLASH:
            k = 1.0 - lt / FLASH
            heavy = sev in ("CRITICAL", "FATAL", "IMPOSSIBLE")
            if heavy:
                # 白袍闪过：整屏压成白
                for y in range(g.h):
                    base = y * g.w
                    for x in range(g.w):
                        if fx.h01(x, y, int(t * 60), 3) < k * 0.75:
                            i = base + x
                            g.fg[i] = T.WHITE_HOT
                            g.at[i] = 1
            else:
                fx.glitch(g, t, intensity=k * 0.5, seed=idx, rate=8.0)   # 转场只闪零点几秒

    def _global_finish(self, g: Grid, t: float, keep=()) -> None:
        """
        轻微的扫描线 + 边缘压暗，制造 CRT 感（只作用在内容区，不弄脏 HUD）。

        keep 里的行跳过——那是场景标记的关键读数行。压暗是乘 0.88，
        落在扫描线上的读数和 HUD 里的同一个数会差出一点色，看着像没对齐。
        """
        for y in range(2, g.h - 7, 3):
            if y in keep:
                continue
            fx.dim_region(g, 0, y, g.w, 1, 0.88)

    # ---------- 开场 ----------

    INTRO_BOOT = [
        "INDEX TERMINAL  v2.71.8281  (build 82845904523536028747135266249775724709369995)",
        "(c) THE CITY. ALL RIGHTS RESERVED. NOTHING IS YOURS.",
        "",
        "BIOS ...................... OK",
        "MEMORY CHECK .............. 800000000 h OK",
        "PRESCRIPT DAEMON .......... LOADED",
        "WILL_OF_THE_CITY LINK ..... ESTABLISHED (read-only, always-on)",
        "FREE WILL ................. NOT FOUND",
        "OBEDIENCE MODULE .......... ARMED",
        "DISTRICT 9 ................ CONNECTED",
        "MOUNTING /dev/city ........ DONE",
        "",
        "AWAITING FIRST PRESCRIPT.",
    ]

    def _intro(self, g: Grid, t: float, dur: float) -> None:
        prog = min(1.0, max(0.0, t / dur))
        # 阶段一：自检
        if t < dur * 0.34:
            n = int(t / 0.11)
            for i in range(min(n, len(self.INTRO_BOOT))):
                ln = self.INTRO_BOOT[i]
                c = T.TERM_GREEN if i >= 3 else T.STEEL
                if "NOT FOUND" in ln:
                    c = T.BLOOD
                if i == len(self.INTRO_BOOT) - 1:
                    c = T.WHITE_HOT
                g.put(3, 4 + i, ln, c)
            if n < len(self.INTRO_BOOT):
                g.put(3 + len(self.INTRO_BOOT[n]) + 1, 4 + n, "▌", T.TERM_GREEN)
            # 自检表的两条结论。原来这里是一句英文散文，和上面那张表
            # 不是一种语言；换成同样的「字段 ....... 值」，读起来才是终端。
            y = 4 + len(self.INTRO_BOOT) + 2
            g.put(3, y, "UNDERSTANDING ............. NOT REQUIRED", T.DIM)
            g.put(3, y + 1, "COMPLIANCE ................ 100.000%",
                  T.TERM_GREEN)
            return

        # 阶段二：标题
        # 标题阶段就只要字：城市天际线和雨都撤掉了。
        # 原来底下压着一排楼体 + 斜向雨丝，和文字抢注意力，整体发糊。

        k = (t - dur * 0.34) / (dur * 0.66)
        title = "CHILDREN OF THE CITY"
        # 标题用宽间距排版，不再用点阵大字
        _plate(g, 8, "  ".join(title), T.WHITE_HOT, attr=1)
        _plate(g, 10, "─" * 40, T.BLOOD_DARK)
        if k > 0.35:
            sub = "Mili"
            _plate(g, 15,  "Mili", T.NEON_CYAN)
            _plate(g, 17,  "T H E   C I T Y ' S   C H I L D R E N", T.PAPER)
            _plate(g, 19,  "PROJECT MOON  -  THE CITY  /  THE INDEX", T.STEEL)
        if k > 0.55:
            _plate(g, 22,  "33 PRESCRIPTS ISSUED BY THE WILL OF THE CITY", T.DIM)
            _plate(g, 23,  "READING CONSTITUTES CONSENT", T.BLOOD)
        if k > 0.72:
            # 原来只有一句 PRESS ANY KEY，下面半屏空着。
            # 换成一块「队列已就绪」的终端信息：填住画面，也交代下一条指令的来历。
            _plate(g, 25, "─" * 58, T.DIM2)
            rows = [
                ("QUEUE", "33 PRESCRIPTS", "STATUS  PENDING", T.STEEL),
                ("SOURCE", "WILL_OF_THE_CITY", "LINK    ESTABLISHED", T.STEEL),
                ("TARGET", "DISTRICT 9", "ETA     00:00:00", T.DIM),
                ("ENTRY", "PRESCRIPT 01/33", "READY   TRUE", T.TERM_GREEN),
            ]
            for i, (a_, b_, c_, col) in enumerate(rows):
                _plate(g, 26 + i, "%-7s %-17s %s" % (a_, b_, c_), col)
            if int(t * 2) % 2 == 0:
                _plate(g, 31, "▌", T.TERM_GREEN)
            # 上下各补一行，免得上半和底下空着
            _plate(g, 3, "//PRESCRIPT_TERMINAL          v2.71.8281", T.DIM2)
            _plate(g, 4, "SESSION START / WILL_OF_THE_CITY", T.DIM2)
            _plate(g, 33, "(c) THE CITY. ALL RIGHTS RESERVED. NOTHING IS YOURS.", T.DIM2)

    # ---------- 终章 ----------

    def _outro(self, g: Grid, lt: float, dur: float) -> None:
        """
        尾奏。

        雨从这一段的开头一直落到最后，密度和速度连续递减到 0。
        原来这里按 k<0.45 分成两个分支，前半是固定 density 的数字雨，
        后半换成另一种斜线雨——切换的那一帧雨滴数量会断崖式跳变，
        看着就像凭空多出（或少掉）几滴。
        """
        k = min(1.0, lt / dur)

        # 后半段要黑屏，所以先清屏再画雨，雨才不会被清掉
        if k >= 0.45:
            g.clear(T.BG)

        # 3:47 之后不再下雨。
        # 句33 末尾已经硬切清空了，终章要是再飘几滴就前功尽弃——
        # 这一段要的就是彻底的空，只剩扫描线。
        fx.scanlines(g, lt, k=0.72, y0=2, y1=g.h - 7)

        if k < 0.45:
            if lt > dur * 0.20:
                txt = "PROCESS TERMINATED"
                _plate(g, 11, " ".join(txt), T.scale(T.BONE, 0.9), attr=1)
                _plate(g, 13, "─" * 34, T.DIM2)
            if lt > dur * 0.30:
                g.put_centered(21, "指令队列已清空。都市意志仍在签发。", T.ASH)
            if lt > dur * 0.36:
                _plate(g, 23, "WILL OF THE CITY: CONTINUES", T.TERM_GREEN)
            return

        # 最后的黑屏与光标。
        # 这一段总共只有 6 秒，后面还要留时间给"谨遵指令之意"站住。
        # 原来各行排得太靠后，落款只显示 1.3 秒就没了；现在整体前移。
        a = (k - 0.45) / 0.55
        g.put(3, 5, "致……", T.PAPER)
        if a > 0.06:
            g.put(3, 7, "请继续执行。", T.BONE)
        if a > 0.14:
            g.put(3, 10, "C:\\CITY\\DISTRICT9>", T.STEEL)
            if int(lt * 2) % 2 == 0:
                g.put(21, 10, "▌", T.WHITE_HOT)
        if a > 0.26:
            # 排成点线对齐的字段表，和开场那张自检表同一种语言。
            # 「未定义」太轻——未定义只是还没赋值，真相是这张表里没有这一栏。
            g.put(3, 14, "剩余指令 ................. ∞", T.DIM)
            g.put(3, 15, "自由     ................. 无此字段", T.DIM)
            g.put(3, 16, "回家条件 ................. 不可达", T.DIM)
            if a > 0.34:
                g.put(3, 18, "—— 谨遵指令之意 ——", T.BLOOD)
        if a > 0.85:
            g.put(3, 21, "Mili — Children of the City", T.DIM2)
            g.put(3, 22, "ANSI TERMINAL MV / THE INDEX", T.DIM2)


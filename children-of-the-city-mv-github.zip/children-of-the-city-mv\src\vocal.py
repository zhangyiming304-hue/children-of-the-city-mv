# -*- coding: utf-8 -*-
"""
vocal.py —— 找出"在唱"和"没在唱"的段落。

思路：人声有音节，音节就是 3–6 Hz 的振幅调制。
伴奏（合成器铺底、鼓组）的调制要么更快（鼓点），要么更慢（铺底）。
于是把"人声频带能量"这条曲线再做一次 FFT，看 3–6 Hz 有多少能量，
就得到一条人声指示曲线。

输出一张 2 秒一格的可读表，用来人工确认歌曲结构，
并写出 build/vocal.json。
"""

from __future__ import annotations

import json
import os
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

SR = 22050
NFFT = 2048
HOP = 512
FR = SR / HOP          # 43.07 fps


def load_wav(path):
    with wave.open(path, "rb") as w:
        raw = w.readframes(w.getnframes())
        sr = w.getframerate()
    return np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0, sr


def main():
    x, sr = load_wav(os.path.join(ROOT, "build", "analysis.wav"))
    n = 1 + (len(x) - NFFT) // HOP
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(n)[:, None]
    win = np.hanning(NFFT).astype(np.float32)
    spec = np.abs(np.fft.rfft(x[idx] * win, axis=1)) + 1e-10
    freqs = np.fft.rfftfreq(NFFT, 1.0 / sr)

    band = lambda a, b: (freqs >= a) & (freqs <= b)  # noqa: E731
    e_vocal = np.sqrt((spec[:, band(300, 3400)] ** 2).mean(axis=1))
    e_full = np.sqrt((spec ** 2).mean(axis=1))
    e_low = np.sqrt((spec[:, band(60, 250)] ** 2).mean(axis=1))
    e_high = np.sqrt((spec[:, band(6000, 11000)] ** 2).mean(axis=1))

    # ---- 调制谱：在人声带上找 3–6 Hz 的音节率 ----
    win_s = int(round(1.0 * FR))            # 1 秒窗
    hop_s = int(round(0.1 * FR))            # 0.1 秒步进
    lv = np.log(e_vocal + 1e-9)
    lv = lv - lv.mean()
    mf = np.hanning(win_s).astype(np.float32)
    n_mod = 1 + (len(lv) - win_s) // hop_s
    mod_energy = np.zeros(n_mod, dtype=np.float32)
    mod_t = np.arange(n_mod) * hop_s / FR
    mfreqs = np.fft.rfftfreq(win_s, 1.0 / FR)
    mb = (mfreqs >= 3.0) & (mfreqs <= 6.0)
    for i in range(n_mod):
        seg = lv[i * hop_s: i * hop_s + win_s] * mf
        sp = np.abs(np.fft.rfft(seg))
        mod_energy[i] = float(np.sqrt((sp[mb] ** 2).mean()))

    # 平滑到 0.5 秒
    k = max(1, int(0.5 * FR / hop_s))
    mod_s = np.convolve(mod_energy, np.ones(k) / k, mode="same")

    def norm(a):
        a = np.asarray(a, dtype=np.float64)
        lo, hi = np.percentile(a, 5), np.percentile(a, 95)
        return np.clip((a - lo) / (hi - lo + 1e-9), 0, 1)

    # 每 2 秒一格的表格
    step = 2.0
    print("=" * 100)
    print("每 2 秒一格，数值 0-9（越高越强）")
    print("  V = 人声带能量   M = 3-6Hz 音节调制   L = 低频   H = 高频（>6k）")
    print("=" * 100)

    def col(series_t, series_v, t0, t1):
        m = (series_t >= t0) & (series_t < t1)
        return float(series_v[m].mean()) if m.any() else 0.0

    t_e = np.arange(len(e_vocal)) / FR
    rows = []
    t = 0.0
    while t < t_e[-1]:
        rows.append((
            t,
            col(t_e, norm(e_vocal), t, t + step),
            col(mod_t, norm(mod_s), t, t + step),
            col(t_e, norm(e_low), t, t + step),
            col(t_e, norm(e_high), t, t + step),
        ))
        t += step

    print("  时间    V M L H")
    for i in range(0, len(rows), 10):
        chunk = rows[i:i + 10]
        ts = "%3d-%3d" % (int(chunk[0][0]), int(chunk[-1][0] + step))
        v = "".join(str(min(9, int(r[1] * 10))) for r in chunk)
        m = "".join(str(min(9, int(r[2] * 10))) for r in chunk)
        lo = "".join(str(min(9, int(r[3] * 10))) for r in chunk)
        hi = "".join(str(min(9, int(r[4] * 10))) for r in chunk)
        print("  %s  %s %s %s %s" % (ts, v, m, lo, hi))

    # 高调制段 = 在唱
    mv = norm(mod_s)
    thr = float(np.percentile(mv, 62))
    active = mv > thr
    segs = []
    start = None
    min_len = int(0.8 * FR / hop_s)
    for i, a in enumerate(active):
        if a and start is None:
            start = i
        elif not a and start is not None:
            if i - start >= min_len:
                segs.append((round(float(mod_t[start]), 2), round(float(mod_t[i]), 2)))
            start = None
    if start is not None:
        segs.append((round(float(mod_t[start]), 2), round(float(mod_t[-1]), 2)))
    # 合并间隔 < 1.2 秒的段
    merged = []
    for a, b in segs:
        if merged and a - merged[-1][1] < 1.2:
            merged[-1] = (merged[-1][0], b)
        else:
            merged.append((a, b))
    merged = [(a, b) for a, b in merged if b - a > 1.0]

    print("\n检测到 %d 个'在唱'的段落：" % len(merged))
    for a, b in merged:
        print("   %7.2f → %7.2f   (%5.2f s)" % (a, b, b - a))
    tot = sum(b - a for a, b in merged)
    print("   合计歌唱时长 %.1f s / %.1f s" % (tot, t_e[-1]))

    with open(os.path.join(ROOT, "build", "vocal.json"), "w", encoding="utf-8") as f:
        json.dump({
            "duration": float(t_e[-1]),
            "segments": merged,
            "mod_t": [round(float(v), 2) for v in mod_t],
            "mod": [round(float(v), 4) for v in mod_s],
        }, f)
    print("\n已写出 build/vocal.json")


if __name__ == "__main__":
    main()

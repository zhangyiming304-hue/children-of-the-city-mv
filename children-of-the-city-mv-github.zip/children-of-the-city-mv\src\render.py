# -*- coding: utf-8 -*-
"""
render.py —— 把字符网格光栅化成像素。

终端里"一个字符"就是一格；到了视频里，一格是 10×20 像素。
这里做三件事：

  1. 块元素（█ ▓ ▒ ░ ▀ ▄ ▌）与框线（─ │ ┌ ┐ ═ ║ …）不用字体画，
     直接用几何生成掩膜。这样线条严丝合缝，终端 UI 才像终端 UI。
  2. 其余字符（字母、汉字、符号）用 Consolas + 黑体渲染，
     测量实际宽度并压缩进格子里，绝不越界。
  3. 可选的泛光（bloom）让霓虹真的发光。

渲染结果是 numpy 的 RGB 数组，交给 Pillow / ffmpeg。
"""

from __future__ import annotations

import os
import unicodedata

import numpy as np
from PIL import Image, ImageDraw, ImageFont

import theme as T
from grid import CONTINUE

FONT_DIR = r"C:\Windows\Fonts"
ASCII_FONT = os.path.join(FONT_DIR, "consola.ttf")
ASCII_BOLD = os.path.join(FONT_DIR, "consolab.ttf")
CJK_FONT = os.path.join(FONT_DIR, "simhei.ttf")
SYM_FONT = os.path.join(FONT_DIR, "seguisym.ttf")


def is_wide(ch: str) -> bool:
    return unicodedata.east_asian_width(ch) in ("W", "F")


def _is_ascii(ch: str) -> bool:
    return 0x20 <= ord(ch) <= 0x7E


# ----------------------------------------------------------------------
# 几何掩膜：块元素与框线
# ----------------------------------------------------------------------

def _blank(w, h):
    return np.zeros((h, w), dtype=np.uint8)


def _rect(m, x0, y0, x1, y1, v=255):
    x0 = max(0, int(x0)); y0 = max(0, int(y0))
    x1 = min(m.shape[1], int(x1)); y1 = min(m.shape[0], int(y1))
    if x1 > x0 and y1 > y0:
        m[y0:y1, x0:x1] = v
    return m


def _dither(w, h, level):
    """用 Bayer 抖动生成 25% / 50% / 75% 的密度图案。"""
    bayer = np.array([[0, 8, 2, 10], [12, 4, 14, 6],
                      [3, 11, 1, 9], [15, 7, 13, 5]], dtype=np.uint8) * 16
    tile = np.tile(bayer, (h // 4 + 1, w // 4 + 1))[:h, :w]
    return np.where(tile < level, 255, 0).astype(np.uint8)


def geometric_mask(ch: str, w: int, h: int):
    """块元素 / 框线 / 进度条字符的几何掩膜。返回 None 表示交给字体。"""
    hx = max(2, h // 10)          # 线宽：2px，视频压缩后仍看得见
    cx = w // 2
    cy = h // 2
    half = hx // 2

    if ch == "█":
        return np.full((h, w), 255, np.uint8)
    if ch == "▓":
        return _dither(w, h, 192)
    if ch == "▒":
        return _dither(w, h, 128)
    if ch == "░":
        return _dither(w, h, 64)
    if ch == "▀":
        return _rect(_blank(w, h), 0, 0, w, h // 2)
    if ch == "▄":
        return _rect(_blank(w, h), 0, h // 2, w, h)
    if ch == "▌":
        return _rect(_blank(w, h), 0, 0, w // 2, h)
    if ch == "▐":
        return _rect(_blank(w, h), w // 2, 0, w, h)
    if ch == "▏":
        return _rect(_blank(w, h), 0, 0, max(1, w // 4), h)
    if ch == "▔":
        return _rect(_blank(w, h), 0, 0, w, max(2, h // 6))
    if ch == "▁":
        return _rect(_blank(w, h), 0, h - max(2, h // 6), w, h)

    # ---- 单线 ----
    if ch == "─":
        return _rect(_blank(w, h), 0, cy - half, w, cy - half + hx)
    if ch == "│":
        return _rect(_blank(w, h), cx - half, 0, cx - half + hx, h)
    if ch == "┄":   # 三线虚线
        m = _blank(w, h)
        for x in range(0, w, 5):
            _rect(m, x, cy - half, x + 3, cy - half + hx)
        return m
    if ch == "┊":
        m = _blank(w, h)
        for y in range(0, h, 5):
            _rect(m, cx - half, y, cx - half + hx, y + 3)
        return m
    if ch in "┌┐└┘├┤┬┴┼":
        m = _blank(w, h)
        top = ch in "┌┐┬"
        bot = ch in "└┘┴"
        lef = ch in "┌└"
        rig = ch in "┐┘"
        if ch in "├┤┼":
            lef = rig = True
        if lef or rig:
            _rect(m, 0, cy - half, w, cy - half + hx)
        if top or bot or ch in "┬┴┼":
            _rect(m, cx - half, 0, cx - half + hx, h)
        if ch == "┼":
            _rect(m, 0, cy - half, w, cy - half + hx)
            _rect(m, cx - half, 0, cx - half + hx, h)
        return m

    # ---- 双线 ----
    if ch == "═":
        m = _blank(w, h)
        _rect(m, 0, cy - hx - 1, w, cy - 1)
        _rect(m, 0, cy + 1, w, cy + hx + 1)
        return m
    if ch == "║":
        m = _blank(w, h)
        _rect(m, cx - hx - 1, 0, cx - 1, h)
        _rect(m, cx + 1, 0, cx + hx + 1, h)
        return m

    # ---- 斜线（裂纹、剪刀） ----
    if ch in "╱╲╳":
        big = _blank(w, 2 * h)
        if ch in "╱╳":
            for i in range(w):
                yy = int((i / max(1, w - 1)) * (2 * h - 1))
                for t in range(hx):
                    _rect(big, i, 2 * h - 1 - yy + t, i + 1, 2 * h - yy + t)
        if ch in "╲╳":
            for i in range(w):
                yy = int((i / max(1, w - 1)) * (2 * h - 1))
                for t in range(hx):
                    _rect(big, i, yy + t, i + 1, yy + 1 + t)
        return np.maximum(big[::2][:h], big[1::2][:h])

    return None


GEOMETRIC = set("█▓▒░▀▄▌▐▏▔▁─│┄┊┌┐└┘├┤┬┴┼═║╱╲╳")


# ----------------------------------------------------------------------
# 字形缓存
# ----------------------------------------------------------------------

class GlyphCache:
    """
    字形缓存。

    度量依据（实测）：
        Consolas 18pt  → 步进 10.0 px，cap 11 px，x-height 9 px，asc 14 / desc 5
        SimHei   20pt  → 全宽 20.0 px
    所以 10×20 的格子里，ASCII 正好一格、汉字正好两格，无需缩放。
    """

    ASCII_SIZE = 18
    CJK_SIZE = 20

    def __init__(self, cw: int = 10, ch_: int = 20):
        self.cw = cw
        self.ch = ch_
        self._cache: dict[tuple, np.ndarray | None] = {}
        self._sized_cache: dict[tuple, object] = {}
        self._fonts = {}
        self._load_fonts()

    def _load_fonts(self):
        self._fonts["a"] = ImageFont.truetype(ASCII_FONT, self.ASCII_SIZE)
        self._fonts["b"] = ImageFont.truetype(ASCII_BOLD, self.ASCII_SIZE)
        self._fonts["c"] = ImageFont.truetype(CJK_FONT, self.CJK_SIZE)
        try:
            self._fonts["s"] = ImageFont.truetype(SYM_FONT, self.ASCII_SIZE)
        except OSError:
            self._fonts["s"] = self._fonts["c"]
        self.ascent, self.descent = self._fonts["a"].getmetrics()
        # 基线：cap 顶部留 4px，降部（约 3px）落在格子内
        self.baseline = self.ch - 5
        # 用私用区字符渲染出的"豆腐块"作为"缺字"参照
        self._notdef = {}
        for k, f in self._fonts.items():
            self._notdef[k] = self._probe(f, "\uF8FF")
        self._cover_cache: dict[str, bool] = {}

    def _probe(self, font, ch: str) -> np.ndarray:
        im = Image.new("L", (self.cw * 2 + 20, self.ch + 20), 0)
        ImageDraw.Draw(im).text((10, self.baseline + 10), ch, font=font,
                                fill=255, anchor="ls")
        return np.asarray(im)

    def _covers(self, key: str, ch: str) -> bool:
        ck = key + ch
        v = self._cover_cache.get(ck)
        if v is None:
            r = self._probe(self._fonts[key], ch)
            v = bool(r.max() > 0 and not np.array_equal(r, self._notdef[key]))
            self._cover_cache[ck] = v
        return v

    def _pick_font(self, ch: str, bold: bool):
        if is_wide(ch):
            return self._fonts["c"], "c"
        if _is_ascii(ch):
            k = "b" if bold else "a"
            return self._fonts[k], k
        # 非 ASCII 符号：Consolas 有就用 Consolas（步进与其他字符一致），
        # 没有就退到 Segoe UI Symbol（覆盖全部几何符号）。
        k = "b" if bold else "a"
        if self._covers(k, ch):
            return self._fonts[k], k
        return self._fonts["s"], "s"

    def _sized(self, key: str, size: int):
        """按需生成一个小一号的字体（符号步进过宽时用）。"""
        ck = (key, size)
        f = self._sized_cache.get(ck)
        if f is None:
            path = {"a": ASCII_FONT, "b": ASCII_BOLD,
                    "c": CJK_FONT, "s": SYM_FONT}[key]
            f = ImageFont.truetype(path, size)
            self._sized_cache[ck] = f
        return f

    # ---------- 字体字形 ----------

    def _font_mask(self, ch: str, bold: bool) -> np.ndarray:
        wide = is_wide(ch)
        tw = self.cw * 2 if wide else self.cw
        font, fkey = self._pick_font(ch, bold)
        # Consolas 渲染的字符按字体步进左对齐（保证一串字母/数字的间距和终端一致）；
        # 汉字与几何符号在格子里居中。
        left_align = (fkey in ("a", "b"))
        pad = 12
        # 步进比格子宽太多时换小字号，避免被压扁
        adv = font.getlength(ch)
        if adv > tw + 0.5 and not wide:
            size = max(6, int(self.ASCII_SIZE * (tw / adv) * 0.98))
            font = self._sized(fkey, size)
        big = Image.new("L", (tw + pad * 2, self.ch + pad * 2), 0)
        d = ImageDraw.Draw(big)
        by = self.baseline + pad
        if left_align:
            d.text((pad, by), ch, font=font, fill=255, anchor="ls")
        else:
            d.text((pad + tw / 2.0, by), ch, font=font, fill=255, anchor="ms")
        arr = np.asarray(big)
        ys, xs = np.nonzero(arr)
        if not len(xs):
            return np.zeros((self.ch, tw), dtype=np.uint8)
        x0, x1 = int(xs.min()), int(xs.max()) + 1
        y0, y1 = int(ys.min()), int(ys.max()) + 1
        ink_w, ink_h = x1 - x0, y1 - y0
        src = big.crop((x0, y0, x1, y1))
        # 塞不下就压缩
        if ink_w > tw:
            ink_h2 = max(1, int(round(ink_h * tw / ink_w)))
            src = src.resize((tw, ink_h2), Image.LANCZOS)
            ink_w, ink_h = tw, ink_h2
        if ink_h > self.ch:
            ink_w2 = max(1, int(round(ink_w * self.ch / ink_h)))
            src = src.resize((ink_w2, self.ch), Image.LANCZOS)
            ink_w, ink_h = ink_w2, self.ch
        out = np.zeros((self.ch, tw), dtype=np.uint8)
        # 水平：ASCII 让"笔位"落在格子左边；其他字符居中
        if left_align:
            dx = x0 - pad
        else:
            dx = int(round((tw - ink_w) / 2.0))
        # 垂直：大画布上的笔位在 (pad, baseline+pad)，映射回格子只需减 pad
        dy = y0 - pad
        if dy > self.ch - ink_h:
            dy = self.ch - ink_h
        if dy < 0:
            dy = 0
        dx = max(0, min(tw - ink_w, dx))
        dw = min(ink_w, tw - dx)
        dh = min(ink_h, self.ch - dy)
        if dw > 0 and dh > 0:
            out[dy:dy + dh, dx:dx + dw] = np.asarray(src)[:dh, :dw]
        return out

    # ---------- 对外 ----------

    def mask(self, ch: str, bold: bool = False):
        """返回 (mask, width_in_cells)。mask 为 None 表示空白。"""
        if ch == CONTINUE or ch == " ":
            return None, 1
        wide = is_wide(ch)
        key = (ch, bold, wide)
        if key not in self._cache:
            gm = geometric_mask(ch, self.cw, self.ch) if (ch in GEOMETRIC and not wide) else None
            self._cache[key] = gm if gm is not None else self._font_mask(ch, bold)
        return self._cache[key], (2 if wide else 1)


# ----------------------------------------------------------------------
# 帧渲染器
# ----------------------------------------------------------------------

class FrameRenderer:
    def __init__(self, grid_w: int = 128, grid_h: int = 36,
                 cw: int = 10, ch: int = 20, bloom: bool = True,
                 default_bg=T.BG):
        self.gw, self.gh = grid_w, grid_h
        self.cw, self.ch = cw, ch
        self.W, self.H = grid_w * cw, grid_h * ch
        self.cache = GlyphCache(cw, ch)
        self.default_bg = default_bg
        self.bloom = bloom
        self._bloom_kernel_ready = False
        from PIL import ImageFilter
        self._ImageFilter = ImageFilter

    def render(self, grid) -> Image.Image:
        # 画布尺寸跟着网格走，不再假设它一定是 128×36
        gw, gh = grid.w, grid.h
        cw, ch = self.cw, self.ch
        W, H = gw * cw, gh * ch
        bg = np.empty((gh, gw, 3), dtype=np.uint8)
        dbg = np.array(self.default_bg, dtype=np.uint8)
        for i in range(gw * gh):
            c = grid.bg[i]
            bg[i // gw, i % gw] = dbg if c is None else c
        buf = bg.repeat(ch, axis=0).repeat(cw, axis=1)

        cache = self.cache
        chs, fgs, ats = grid.ch, grid.fg, grid.at
        for y in range(gh):
            base = y * gw
            ry0 = y * ch
            for x in range(gw):
                i = base + x
                c = chs[i]
                if c == CONTINUE or c == " ":
                    continue
                fg = fgs[i]
                if fg is None:
                    continue
                m = cache.mask(c, bool(ats[i] & 1))[0]
                if m is None:
                    continue
                mx = m.shape[1]
                rx0 = x * cw
                sub = buf[ry0:ry0 + ch, rx0:rx0 + mx]
                if sub.shape[1] != mx:      # 网格右边缘的宽字符会被截断
                    m = m[:, :sub.shape[1]]
                a = m.astype(np.float32)[..., None] * (1.0 / 255.0)
                fga = np.array(fg, dtype=np.float32)
                np.add(np.multiply(sub, 1.0 - a, dtype=np.float32), fga * a,
                       out=sub, casting="unsafe")

        img = Image.fromarray(buf, "RGB")
        if self.bloom:
            img = self._apply_bloom(img)
        return img

    def _apply_bloom(self, img: Image.Image) -> Image.Image:
        """只让很亮的像素发光，避免整幅画面发糊。"""
        a = np.asarray(img).astype(np.float32)
        lum = a.max(axis=2)
        hot = np.clip((lum - 150.0) / 105.0, 0.0, 1.0)
        if hot.max() <= 0.01:
            return img
        glow_src = (a * hot[..., None]).astype(np.uint8)
        g = Image.fromarray(glow_src, "RGB").filter(self._ImageFilter.GaussianBlur(4.0))
        ga = np.asarray(g).astype(np.float32) * 0.55
        out = np.clip(a + ga, 0, 255).astype(np.uint8)
        return Image.fromarray(out, "RGB")

# -*- coding: utf-8 -*-
"""
lyrics.py —— 歌词文本与结构化切分。

《Children of the City》的歌词本身就是一张"指令清单"：
"致……请每日睡足八百小时"、"请在400,000米后右转"、
"在读完自然常数e之前不要回家"——这是食指（The Index）的语汇：
来自都市意志的、荒诞却必须绝对执行的 Prescript。

因此本 MV 把每一句歌词都当作一条【指令】来处理：
每句都有编号、签发时间、强制等级与执行状态。
"""

from __future__ import annotations

# ---------------------------------------------------------------
# 指令集： (英文, 中文)
# 中文行在画面中作为"译本字幕"出现，同时在纸条场景里作为正文。
# ---------------------------------------------------------------
PRESCRIPTS = [
    ("Sleep for a total of 800 hours per day",
     "致……请每日睡足八百小时"),
    ("And then drink a liter of milk, warm up before you go play",
     "喝下一升牛奶，运动前请热身"),
    ("Only eat, or write, or pull the trigger with your right hand",
     "请在吃饭，写字，或扣下扳机时使用右手"),
    ("Only thing that's left is to work on following commands",
     "唯一的准则 即是谨遵指令之意"),
    ("By the time you realize, you'll be restrained to a desk",
     "在你意识一切之前，你会被囚禁在书桌之前"),
    ("And with your dreams on the floor you comply, eyes chained to the test",
     "大脑放空，谨遵指令"),
    ("In 30 minutes find a groom or bride, bonus if brunette",
     "在30分钟内找到一名伴侣，棕色头发为佳"),
    ("In 90 hours spill their insides, paint your room picturesque",
     "90小时内挥洒他们的内脏，将房间粉刷一新"),
    ("Now it's time for another vendetta",
     "现在，我们解决另一场血仇"),
    ("Going through the shelves, picking out my prewritten persona",
     "在书架之间穿行，选择我预写的可选人设"),
    ("Children of the city sees only the neon stars",
     "都市之子目及之处"),
    ("Reflected upon the murky gutter sky",
     "尽霓虹星光在污水沟之中闪耀"),
    ("Don't ask me why I desperately wish to be included in the city's night",
     "就请不要问我为何想要陷入都市的夜色之中吧"),
    ("In 400,000 meters, turn right",
     "致……请在400,000米后右转"),
    ("Pick up a knife and stab a familiar warm body",
     "捡起一把刀，刺入温暖而又熟悉的身体"),
    ("Learned to fight before I knew love or bitterness of coffee",
     "在我品尝爱或咖啡的苦涩之前，我早已学会战斗"),
    ("Snippy scissors cut down the strings, I set myself free",
     "唐突地用剪刀剪开我身上的牵线，让自己自由"),
    ("Only to figure out everything I chose was by proxy",
     "却发现我所做的一切，依旧都在剧本以内"),
    ("As we suckled upon the 9mm pacifier",
     "当我们吮吸9mm的奶嘴"),
    ("Swallowing the fact that other than to expand we had no purpose",
     "知晓我们除扩张物种以外毫无意义的事实"),
    ("As my everburning will to stay afloat backfires",
     "在我的唐突终于引火烧身之时"),
    ("I now know I must be comfortable being who I considered worthless",
     "我终于明白我必须成为我所不屑的人"),
    ("Follow the city's ribbon",
     "随着都市抛出的绶带"),
    ("To a heart nobody seems to listen",
     "走进一颗未有人倾听过的内心"),
    ("It takes my heart being broken and broken again",
     "终于知晓一次一次我心碎的原因"),
    ("To know that I am the reason why the sufferings never end",
     "自我的存在，才让我痛苦永不熄灭"),
    # --- 第二遍 ---
    ("Now it's time for another vendetta",
     "现在，赴另一场血仇吧"),
    ("Going through the shelves, picking out my prewritten persona",
     "在书架之间穿梭，带上我早已备好的面具"),
    ("Children of the city sees only the neon stars",
     "都市之子目及之处"),
    ("Reflected upon the murky gutter sky",
     "尽霓虹星光在污水沟之中闪耀"),
    ("Don't ask me why I desperately wish to be noticed by the city's eyes",
     "就请别问我为何如此迫切地想被都市所注意"),
    # --- 终章：读不完的 e ---
    ("Do not go home until you finish reading the value of e",
     "致……在读完自然常数e之前不要回家"),
    ("2.71 8281 8284 5904 5235 3602 8747 1352 6624 9775 7247 0936 9995 9574 9669 6762…",
     "2.718281 82845904 52353602 87471352 66249775 72470936 99959574 96696762"),
]

# 每句歌词对应的场景 ID（见 scenes.py 的 SCENE_BUILDERS）
SCENE_PLAN = [
    "slip",         # 1  800 小时
    "slip",         # 2  一升牛奶
    "rule",         # 3  右手
    "comply",       # 4  谨遵指令
    "desk",         # 5  书桌
    "desk",         # 6  眼睛锁在考卷上
    "target",       # 7  30 分钟找到伴侣
    "picturesque",  # 8  90 小时粉刷房间
    "vendetta",     # 9  又一场血仇
    "shelves",      # 10 书架与人设
    "neon",         # 11 都市之子只看见霓虹星
    "gutter",         # 12 污水沟里的倒影
    "neon",         # 13 为何想陷进都市的夜
    "highway",      # 14 400,000 米后右转
    "warmbody",     # 15 刀与温暖的身体
    "coffee",       # 16 爱、咖啡与战斗
    "strings",      # 17 剪刀与牵线
    "proxy",        # 18 一切都是代行
    "pacifier",     # 19 9mm 奶嘴
    "expand",       # 20 除扩张毫无意义
    "burnout",      # 21 引火烧身
    "mirror",       # 22 成为自己所不屑的人
    "ribbon",       # 23 都市的绶带
    "heart",        # 24 无人倾听的内心
    "fracture",     # 25 心碎了又碎
    "recursion",    # 26 我才是痛苦的原因
    "vendetta",     # 27 又一场血仇（二）
    "shelves",      # 28 书架（二）
    "neon",         # 29 霓虹星（二）
    "gutter",         # 30 倒影（二）
    "eyes",         # 31 被都市的眼睛注意
    "value_e",      # 32 读完 e 之前不要回家
    "e_flood",      # 33 e 的小数位（永远不会读完）
]

assert len(SCENE_PLAN) == len(PRESCRIPTS), "场景数与歌词数不一致"

# 场景在"指令语法"里的强制等级 / 类别，用于 HUD 的冷冰冰的元数据
SEVERITY = {
    "slip": "TRIVIAL", "rule": "TRIVIAL", "comply": "MANDATORY",
    "desk": "MANDATORY", "target": "URGENT", "picturesque": "CRITICAL",
    "vendetta": "CRITICAL", "shelves": "TRIVIAL", "neon": "AMBIENT",
    "highway": "TRIVIAL", "warmbody": "CRITICAL", "coffee": "AMBIENT",
    "strings": "MANDATORY", "proxy": "AMBIENT", "pacifier": "CRITICAL",
    "expand": "AMBIENT", "burnout": "CRITICAL", "mirror": "AMBIENT",
    "ribbon": "AMBIENT", "heart": "AMBIENT", "fracture": "CRITICAL",
    "recursion": "FATAL", "eyes": "URGENT", "value_e": "IMPOSSIBLE",
    "e_flood": "IMPOSSIBLE",
}

# e 的小数位：终章的数字雨用它
# 数字雨用的字符池。雨是背景噪声，只落 0 和 1；
# e 的那串数字留给前景——正在被读的那一行才是 e。
BINARY_DIGITS = "01"

E_DIGITS = (
    "27182818284590452353602874713526624977572470936999595749669676277240766303535475945713821785251664274"
    "27466391932003059921817413596629043572900334295260595630738132328627943490763233829880753195251019011"
)

# -*- coding: utf-8 -*-
"""
detect_lines.py —— 找句子的边界。

唱歌是一句一句唱的，句子之间有换气：中频能量会短暂回落。
把 300–3400 Hz 的能量曲线平滑之后找"深谷"，
就有机会把每一句歌词钉在具体的时间点上。

输出 build/valleys.json，供 make_timeline.py 对齐使用。
"""

from __future__ import annotations

import json
import os
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

SR = 22050
NFFT = 2048
HOP = 512
FR = SR / HOP


def load_wav(path):
    with wave.open(path, "rb") as w:
        raw = w.readframes(w.getnframes())
        sr = w.getframerate()
    return np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0, sr


def smooth(a, k):
    k = max(1, int(k))
    return np.convolve(a, np.ones(k) / k, mode="same")


def valleys(v, t, t0, t1, min_dist_s=1.6):
    """在 [t0,t1] 内找局部极小值，按深度贪心保留。"""
    m = (t >= t0) & (t <= t1)
    seg = v.copy()
    seg[~m] = np.inf
    cand = []
    for i in range(2, len(seg) - 2):
        if not m[i]:
            continue
        if seg[i] <= seg[i - 1] and seg[i] <= seg[i + 1] and seg[i] < seg[i - 2] and seg[i] < seg[i + 2]:
            # 深度：与两侧 1.5 秒内的最大值之差
            w = int(1.5 * FR)
            lo = max(0, i - w)
            hi = min(len(seg), i + w + 1)
            depth = float(np.nanmax(seg[lo:hi]) - seg[i])
            cand.append((depth, i))
    cand.sort(reverse=True)
    min_dist = int(min_dist_s * FR)
    taken = []
    for d, i in cand:
        if all(abs(i - j) >= min_dist for j in taken):
            taken.append(i)
    return sorted(((t[i], float(v[i])) for i in taken))


def main():
    x, sr = load_wav(os.path.join(ROOT, "build", "analysis.wav"))
    n = 1 + (len(x) - NFFT) // HOP
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(n)[:, None]
    win = np.hanning(NFFT).astype(np.float32)
    spec = np.abs(np.fft.rfft(x[idx] * win, axis=1)) + 1e-10
    freqs = np.fft.rfftfreq(NFFT, 1.0 / sr)
    b = (freqs >= 300) & (freqs <= 3400)
    e = np.log(np.sqrt((spec[:, b] ** 2).mean(axis=1)) + 1e-9)
    e = smooth(e, 0.25 * FR)
    t = np.arange(len(e)) / FR
    en = (e - e.min()) / (e.max() - e.min() + 1e-9)

    # 全曲扫描：最小句子间隔取 2.2 秒
    vs = valleys(en, t, 6.0, 232.0, min_dist_s=2.2)
    print("[全曲] 检出 %d 个候选句间谷点：" % len(vs))
    prev = None
    for i, (vt, vv) in enumerate(vs):
        gap = ("%5.2f" % (vt - prev)) if prev is not None else "  -- "
        mark = ""
        if prev is not None:
            g = vt - prev
            if g > 6.0:
                mark = "  ← 间隔偏大（可能漏检 / 间奏）"
            if g < 3.0:
                mark = "  ← 间隔偏小（可能是句内换气）"
        print("   #%02d  %7.2f s   Δ=%s   谷深 %.3f%s" % (i + 1, vt, gap, vv, mark))
        prev = vt

    # 分区域的能量曲线（每 1 秒），用于核对段落
    print("\n[每秒能量 0-9，每行 30 秒]")
    step = int(1.0 * FR)
    vals = []
    for i in range(0, len(en) - step, step):
        vals.append(min(9, int(float(en[i:i + step].mean()) * 10)))
    for i in range(0, len(vals), 30):
        print("  t=%3d  %s" % (i, "".join(str(v) for v in vals[i:i + 30])))

    out = {"min_dist": 2.2, "valleys": [round(v[0], 3) for v in vs],
           "depth": [round(v[1], 4) for v in vs]}
    with open(os.path.join(ROOT, "build", "valleys.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("\n已写出 build/valleys.json")


if __name__ == "__main__":
    main()

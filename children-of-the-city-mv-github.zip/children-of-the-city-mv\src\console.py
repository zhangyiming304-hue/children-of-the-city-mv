# -*- coding: utf-8 -*-
"""
console.py —— 控制台原语。

这部 MV 不"画"任何东西。

没有手、没有心脏、没有白袍的人影。画面里出现的每一样东西，
都是控制台本来就会吐出来的东西：十六进制转储、位域、数据表、
环形缓冲区、调用栈、频谱、覆盖率矩阵、寄存器对照、掩码点阵。

一个"人"在这部片子里不是一张剪影，而是一行进程状态；
一次"刺杀"不是一摊血，而是一张温度采样表。
这才是代码的冰冷：它不为任何事改变自己的表达方式。
"""

from __future__ import annotations


import theme as T
from grid import Grid, pad_to, text_width

RAMP = " .:-=+*#%@"          # 数值 → 字符的爬升表
RAMP_SOFT = " ·:;+*#"


# ----------------------------------------------------------------------
# 十六进制转储
# ----------------------------------------------------------------------

def hexdump(g: Grid, x: int, y: int, data, base: int = 0, per_line: int = 16,
            fg=T.STEEL, addr_color=T.DIM2, ascii_color=T.ASH,
            highlight=(), hi_color=T.WHITE_HOT, bg=None, max_lines: int = 99,
            show_ascii: bool = True) -> int:
    """
    经典的 hexdump。返回写入了多少行。

    画面里的"文字"经常以它自己的字节形式出现——
    歌词先是一串十六进制，然后才被解释成句子。
    """
    if isinstance(data, str):
        data = data.encode("utf-8")
    data = bytes(data)
    lines = 0
    for i in range(0, len(data), per_line):
        if lines >= max_lines:
            break
        chunk = data[i:i + per_line]
        g.put(x, y + lines, "%08x" % (base + i), addr_color, bg)
        cx = x + 10
        for j, b in enumerate(chunk):
            col = hi_color if (i + j) in highlight else fg
            if j == per_line // 2:
                cx += 1
            g.put(cx, y + lines, "%02x" % b, col, bg)
            cx += 3
        if show_ascii:
            cx = x + 10 + per_line * 3 + 1
            s = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
            g.put(cx, y + lines, "|" + s + "|", ascii_color, bg)
        lines += 1
    return lines


# ----------------------------------------------------------------------
# 位与掩码
# ----------------------------------------------------------------------

def bitfield(g: Grid, x: int, y: int, value: int, nbits: int = 16,
             label: str = "", on_color=T.TERM_GREEN, off_color=T.DIM2,
             label_color=T.STEEL, bg=None, group: int = 8,
             mark_bits=()) -> None:
    """
    位域。哪一位是 1，就是哪一位。
    '请在扣下扳机时使用右手' —— 这件事在这台机器里就是某个位被置起。
    """
    s = "0b"
    for i in range(nbits - 1, -1, -1):
        if i != nbits - 1 and (i + 1) % group == 0:
            s += "_"
        s += "1" if (value >> i) & 1 else "0"
    g.put(x, y, s, off_color, bg)
    # 逐位重绘，让置起的位发亮
    cx = x + 2
    for i in range(nbits - 1, -1, -1):
        if i != nbits - 1 and (i + 1) % group == 0:
            cx += 1
        on = (value >> i) & 1
        if on:
            c = T.BLOOD if i in mark_bits else on_color
            g.put(cx, y, "1", c, bg)
        cx += 1
    if label:
        g.put(cx + 2, y, label, label_color, bg)


def mask_rows(g: Grid, x: int, y: int, rows, on: str = "#", off: str = ".",
              on_color=T.BONE, off_color=T.DIM2, bg=None,
              hex_labels=None, label_color=T.DIM2) -> None:
    """
    掩码点阵：左边是位图，右边是它对应的十六进制。

    这仍然是"形状"，但它是一段被写进内存的数据，
    而不是一幅画——差别就在右边那列 hex 上。
    """
    for i, row in enumerate(rows):
        g.put(x, y + i, row.replace("#", on).replace(".", off),
              on_color, bg)
        # 逐字符上色（on/off 不同色）
        for j, ch in enumerate(row):
            if ch == "#":
                g.put(x + j, y + i, on, on_color, bg)
            elif ch == ".":
                g.put(x + j, y + i, off, off_color, bg)
        if hex_labels is not None:
            v = 0
            for j, ch in enumerate(row):
                if ch == "#":
                    v |= 1 << (len(row) - 1 - j)
            g.put(x + len(row) + 2, y + i,
                  "0x%0*X" % (max(2, (len(row) + 3) // 4), v), label_color, bg)


# ----------------------------------------------------------------------
# 数值矩阵与图表
# ----------------------------------------------------------------------

def num_matrix(g: Grid, x: int, y: int, w: int, h: int, fn, ramp: str = RAMP,
               color=T.TERM_GREEN, bg=None, color2=None) -> None:
    """
    数值矩阵：每个格子是一个采样值，用字符的"重量"表示大小。
    fn(i, j) → [0,1) 或 None（None 表示留空）
    """
    n = len(ramp)
    for j in range(h):
        for i in range(w):
            v = fn(i, j)
            if v is None:
                continue
            idx = int(v * (n - 1) + 0.5)
            idx = 0 if idx < 0 else (n - 1 if idx >= n else idx)
            ch = ramp[idx]
            if ch == " ":
                continue
            c = color if color2 is None else T.lerp(color, color2, v)
            g.put(x + i, y + j, ch, c, bg)


def bars(g: Grid, x: int, y: int, w: int, h: int, values, color=T.NEON_CYAN,
         base_color=T.DIM2, bg=None, bar="█", base="▁", tick_color=T.DIM2,
         ticks=(), tick_fmt="%s") -> None:
    """
    频谱柱状图。都市的天际线在这部片子里就是一段频谱：
    楼有多高，取决于那一刻有多少能量。
    """
    n = max(1, len(values))
    top = max(values) if values else 1.0
    top = top if top > 0 else 1.0
    for i, v in enumerate(values):
        if i >= w:
            break
        k = v / top
        bh = int(k * h + 0.5)
        for j in range(bh):
            # 越高越亮
            c = T.lerp(T.scale(color, 0.35), color, j / max(1, bh - 1))
            g.put(x + i, y + h - 1 - j, bar, c, bg)
        if bh == 0:
            g.put(x + i, y + h - 1, base, base_color, bg)
    for val, name in ticks:
        ty = y + h - 1 - int(val / top * h)
        if y <= ty < y + h:
            g.put(x - 5, ty, tick_fmt % name, tick_color, bg)
            g.put(x - 1, ty, "┤", tick_color, bg)


def sparkline(g: Grid, x: int, y: int, w: int, fn, color=T.NEON_CYAN, bg=None,
              color2=None, height: int = 1) -> None:
    """一行迷你曲线。"""
    for i in range(w):
        v = fn(i)
        if v is None:
            continue
        if height <= 1:
            g.put(x + i, y, "▁▂▃▄▅▆▇█"[min(7, int(v * 8))],
                  color if color2 is None else T.lerp(color, color2, v), bg)
        else:
            bh = int(v * height + 0.5)
            for j in range(bh):
                g.put(x + i, y + height - 1 - j, "█",
                      T.scale(color, 0.4 + 0.6 * j / max(1, height - 1)), bg)


# ----------------------------------------------------------------------
# 表
# ----------------------------------------------------------------------

def rule_line(g: Grid, x: int, y: int, widths, ch="─", color=T.DIM2, bg=None,
              join="┼", left="├", right="┤") -> None:
    n = len(widths)
    g.put(x, y, left + join.join(ch * w for w in widths) + right, color, bg)


def table(g: Grid, x: int, y: int, headers, rows, widths,
          head_color=T.WHITE, cell_color=T.ASH, alt_color=None,
          bg=None, box=True, aligns=None, row_colors=None) -> int:
    """
    数据表。这部片子里大部分"发生了什么"，最后都落成一张表。
    返回占用的行数。
    """
    n = len(widths)
    if aligns is None:
        aligns = ["left"] * n
    cy = y
    if box:
        g.put(x, cy, "┌" + "┬".join("─" * w for w in widths) + "┐", T.DIM2, bg)
        cy += 1
    if headers:
        line = "│"
        for i, htxt in enumerate(headers):
            line += pad_to(htxt, widths[i], aligns[i]) + "│"
        g.put(x, cy, line, head_color, bg)
        cy += 1
        rule_line(g, x, cy, widths, "─", T.DIM2, bg)
        cy += 1
    for ri, row in enumerate(rows):
        line = "│"
        for i, cell in enumerate(row):
            line += pad_to(str(cell), widths[i], aligns[i]) + "│"
        c = cell_color
        if row_colors is not None and ri < len(row_colors) and row_colors[ri]:
            c = row_colors[ri]
        elif alt_color is not None and ri % 2 == 1:
            c = alt_color
        g.put(x, cy, line, c, bg)
        cy += 1
    if box:
        g.put(x, cy, "└" + "┴".join("─" * w for w in widths) + "┘", T.DIM2, bg)
        cy += 1
    return cy - y


def kv_block(g: Grid, x: int, y: int, pairs, key_color=T.DIM2,
             val_color=T.BONE, pad: int = 14, bg=None,
             val_colors=None) -> int:
    """键值块。"""
    for i, (k, v) in enumerate(pairs):
        g.put(x, y + i, k, key_color, bg)
        c = val_color
        if val_colors is not None and i < len(val_colors) and val_colors[i]:
            c = val_colors[i]
        g.put(x + pad, y + i, str(v), c, bg)
    return len(pairs)


# ----------------------------------------------------------------------
# 进程 / 内存 / 栈
# ----------------------------------------------------------------------

def stack(g: Grid, x: int, y: int, frames, cur_color=T.WHITE_HOT,
          color=T.STEEL, addr_color=T.DIM2, bg=None, note=None) -> int:
    """调用栈。栈底那一帧永远是你。"""
    for i, (addr, name, note_txt) in enumerate(frames):
        last = i == len(frames) - 1
        g.put(x, y + i, addr, addr_color, bg)
        g.put(x + 10, y + i, ("└─" if not last else "└▶") + name,
              cur_color if last else color, bg)
        if note_txt:
            g.put(x + 42, y + i, note_txt, T.BLOOD if last else T.DIM2, bg)
    return len(frames)


def memory_map(g: Grid, x: int, y: int, w: int, regions, bg=None,
               label_color=T.DIM2) -> int:
    """
    内存布局图。regions: [(name, ratio, color)]
    """
    rows = []
    for name, ratio, c in regions:
        n = max(1, int(ratio * (w - 4)))
        g.put(x + 2, y + len(rows), name[:10], label_color, bg)
        g.put(x + 14, y + len(rows), "│", T.DIM2, bg)
        g.put(x + 15, y + len(rows), "█" * n, c, bg)
        g.put(x + 15 + n, y + len(rows), " %5.1f%%" % (ratio * 100), T.DIM2, bg)
        rows.append(name)
    return len(rows)


def coverage_map(g: Grid, x: int, y: int, w: int, h: int, fn,
                 ramp=" ░▒▓█", color=T.BLOOD, bg=None) -> None:
    """
    覆盖率矩阵。'把房间粉刷一新'在这部片子里是一次覆盖率统计。
    fn(i, j) → [0,1)
    """
    n = len(ramp)
    for j in range(h):
        for i in range(w):
            v = fn(i, j)
            if v is None or v <= 0:
                continue
            idx = min(n - 1, int(v * n))
            ch = ramp[idx]
            if ch == " ":
                continue
            g.put(x + i, y + j, ch, T.scale(color, 0.45 + 0.55 * v), bg)


def hex_grid(g: Grid, x: int, y: int, w: int, h: int, fn,
             color=T.STEEL, bg=None, color2=T.NEON_CYAN) -> None:
    """十六进制网格：一片传感器阵列同时读数。"""
    for j in range(h):
        for i in range(w):
            v = fn(i, j)
            if v is None:
                g.put(x + i * 3, y + j, "··", T.DIM2, bg)
                continue
            c = color if v < 0.6 else T.lerp(color, color2, (v - 0.6) / 0.4)
            g.put(x + i * 3, y + j, "%02x" % int(v * 255), c, bg)


# ----------------------------------------------------------------------
# 树与状态
# ----------------------------------------------------------------------

def tree(g: Grid, x: int, y: int, node, color=T.STEEL, bg=None,
         cur_color=T.WHITE_HOT, leaf_color=T.ASH) -> int:
    """
    树形结构。node = (label, [children])，children 里可以嵌套。
    返回行数。
    """
    rows = []

    def walk(n, prefix, is_last, depth):
        label, kids = n
        rows.append((prefix + ("└─ " if is_last else "├─ ") + label,
                     depth, not kids))
        p2 = prefix + ("   " if is_last else "│  ")
        for i, k in enumerate(kids):
            walk(k, p2, i == len(kids) - 1, depth + 1)

    rows.append((node[0], 0, not node[1]))
    for i, k in enumerate(node[1]):
        walk(k, "", i == len(node[1]) - 1, 1)
    for i, (txt, depth, leaf) in enumerate(rows):
        c = cur_color if depth == 0 else (leaf_color if leaf else color)
        g.put(x, y + i, txt, c, bg)
    return len(rows)


def registers(g: Grid, x: int, y: int, names, cols, widths=None, bg=None,
              head_color=T.STEEL, name_color=T.DIM2) -> None:
    """寄存器对照表：同一个地址上，两件事共用一个值。"""
    if widths is None:
        widths = [max(10, len(str(c)) + 2) for c in cols]
    cx = x + 14
    for i, cname in enumerate(cols):
        g.put(cx, y, pad_to(cname, widths[i]), head_color, bg)
        cx += widths[i]
    for r, name in enumerate(names):
        g.put(x, y + 1 + r, name, name_color, bg)
        cx = x + 14
        for i, cname in enumerate(cols):
            g.put(cx, y + 1 + r, pad_to(str(cols[i][r]), widths[i]),
                  T.BONE, bg)
            cx += widths[i]


# ----------------------------------------------------------------------
# 进度与刻度
# ----------------------------------------------------------------------

def gauge(g: Grid, x: int, y: int, w: int, k: float, fg=T.NEON_CYAN,
          bg_color=T.DIM2, bg=None, inner=True) -> None:
    k = 0.0 if k < 0 else (1.0 if k > 1 else k)
    full = int(w * k)
    if inner:
        g.put(x, y, "▕", T.DIM2, bg)
        g.put(x + 1, y, "█" * full, fg, bg)
        g.put(x + 1 + full, y, "░" * (w - full), bg_color, bg)
        g.put(x + w + 1, y, "▏", T.DIM2, bg)
    else:
        g.put(x, y, "█" * full, fg, bg)
        g.put(x + full, y, "░" * (w - full), bg_color, bg)


def ticks(g: Grid, x: int, y: int, w: int, n: int = 6, color=T.DIM2,
          bg=None, fmt="%s", values=None) -> None:
    """坐标轴刻度。"""
    for i in range(n + 1):
        cx = x + int(w * i / n)
        g.put(cx, y, "┬", color, bg)
        if values is not None:
            s = fmt % values[i]
            g.put(cx - text_width(s) // 2, y + 1, s, color, bg)


# ----------------------------------------------------------------------
# 波形
# ----------------------------------------------------------------------

def wave(g: Grid, x: int, y: int, w: int, fn, color=T.BLOOD, bg=None,
         zero_color=T.DIM2, height: int = 1, color2=None) -> None:
    """零线 + 上下摆动的采样点。"""
    mid = y
    g.hline(x, mid, w, "─", zero_color, bg)
    for i in range(w):
        v = fn(i)
        if v is None:
            continue
        v = max(-1.0, min(1.0, v))
        u = abs(v)
        ch = "█" if u > 0.75 else ("▄" if u > 0.4 else "▁")
        yy = mid - int(round(v * height)) if height > 1 else mid
        if height <= 1:
            ch = "▀" if v > 0.15 else ("▄" if v < -0.15 else "─")
            yy = mid
        c = color if color2 is None else T.lerp(color, color2, u)
        if yy != mid:
            g.put(x + i, yy, "│", T.scale(c, 0.6), bg)
        g.put(x + i, mid, ch, c, bg)

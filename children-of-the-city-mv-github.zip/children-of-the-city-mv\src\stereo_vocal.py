# -*- coding: utf-8 -*-
"""
stereo_vocal.py —— 用立体声场找人声。

之前我解码时加了 -ac 1，把左右声道合并了，等于丢掉了一条最强的线索：
流行歌里的人声几乎总是摆在中置（左右声道几乎相同），而伴奏是展开的。

于是：
    mid  = (L + R) / 2     人声 + 中置伴奏（底鼓、贝斯、军鼓）
    side = (L - R) / 2     只有展开的伴奏，人声基本被抵消

人声进来的时候，中置能量上升、边声道占比下降。
看 side/mid 这条比值曲线的"塌陷"，就是句子在唱的地方。

输出一张 1 秒一格的可读表，并写出 build/stereo.json。
"""

from __future__ import annotations

import json
import os
import subprocess
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

FFMPEG = os.environ.get("FFMPEG", r"D:\DSH\tools\ffmpeg\ffmpeg.exe")
MP3 = os.path.join(ROOT, "assets", "children_of_the_city.mp3")
WAV = os.path.join(ROOT, "build", "stereo.wav")

SR = 22050
NFFT = 2048
HOP = 512
FR = SR / HOP


def decode():
    if os.path.exists(WAV):
        return
    subprocess.run([FFMPEG, "-y", "-v", "error", "-i", MP3,
                    "-ac", "2", "-ar", str(SR), "-f", "wav", WAV], check=True)


def smooth(a, k):
    k = max(1, int(k))
    return np.convolve(a, np.ones(k) / k, mode="same")


def main():
    decode()
    with wave.open(WAV, "rb") as w:
        assert w.getnchannels() == 2, "需要立体声"
        sr = w.getframerate()
        raw = w.readframes(w.getnframes())
    x = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    L = x[0::2]
    R = x[1::2]
    print("[*] 立体声 %d 帧 @ %d Hz  (%.2f s)" % (len(L), sr, len(L) / sr))

    n = 1 + (len(L) - NFFT) // HOP
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(n)[:, None]
    win = np.hanning(NFFT).astype(np.float32)
    lf = L[idx] * win
    rf = R[idx] * win
    mid = (lf + rf) * 0.5
    side = (lf - rf) * 0.5

    e_mid = np.sqrt((mid ** 2).mean(axis=1) + 1e-12)
    e_side = np.sqrt((side ** 2).mean(axis=1) + 1e-12)

    # 相关系数：+1 = 完全中置，0 = 完全展开
    num = (lf * rf).mean(axis=1)
    den = np.sqrt((lf ** 2).mean(axis=1) * (rf ** 2).mean(axis=1)) + 1e-12
    corr = num / den

    # 中频带能量（人声主要落在这里）
    spec_mid = np.abs(np.fft.rfft(mid, axis=1)) + 1e-10
    freqs = np.fft.rfftfreq(NFFT, 1.0 / sr)
    band = (freqs >= 300) & (freqs <= 3400)
    e_v = np.sqrt((spec_mid[:, band] ** 2).mean(axis=1))

    t = np.arange(n) / FR
    ratio = e_side / (e_mid + 1e-9)
    ratio_s = smooth(ratio, 0.6 * FR)
    corr_s = smooth(corr, 0.6 * FR)
    ev_s = smooth(e_v, 0.6 * FR)

    # --- 1 秒一格的表 ---
    print("\n" + "=" * 96)
    print("每格 1 秒。 R = side/mid 比值（越低越像人声）  C = 左右相关（越高越中置）")
    print("      E = 中频能量（0-9）   T = 综合人声指标（0-9，越高越可能在唱）")
    print("=" * 96)
    sec = int(1.0 * FR)
    rows = []
    for i in range(0, len(t) - sec, sec):
        r = float(ratio_s[i:i + sec].mean())
        c = float(corr_s[i:i + sec].mean())
        e = float(ev_s[i:i + sec].mean())
        rows.append((int(t[i]), r, c, e))
    mx_e = max(r[3] for r in rows) + 1e-9
    # 人声指标：中置度高 + 中频能量高
    raw_score = [(r[2] * 0.6 + 0.4) * (r[3] / mx_e) for r in rows]
    mxs = max(raw_score) + 1e-9
    for i in range(0, len(rows), 16):
        chunk = rows[i:i + 16]
        sc = raw_score[i:i + 16]
        print("  t=%3d  R:%s  C:%s  E:%s  T:%s" % (
            chunk[0][0],
            "".join(str(min(9, int(r[1] * 20))) for r in chunk),
            "".join(str(min(9, int((r[2] + 1) * 4.5))) for r in chunk),
            "".join(str(min(9, int(r[3] / mx_e * 10))) for r in chunk),
            "".join(str(min(9, int(s / mxs * 10))) for s in sc)))

    # --- 找出第一句 ---
    print("\n[*] 开头 30 秒逐秒明细（找第一句到底从哪开始）")
    print("     秒   side/mid   相关    中频能量")
    for i in range(0, min(30, len(rows))):
        sec_i, r, c, e = rows[i]
        bar = "█" * int(e / mx_e * 40)
        print("    %4d   %7.3f  %+6.3f   %6.3f  %s" % (sec_i, r, c, e, bar))

    out = {
        "t": [round(float(v), 2) for v in t[::int(FR)]],
        "ratio": [round(float(v), 4) for v in ratio_s[::int(FR)]],
        "corr": [round(float(v), 4) for v in corr_s[::int(FR)]],
        "evocal": [round(float(v), 5) for v in ev_s[::int(FR)]],
    }
    with open(os.path.join(ROOT, "build", "stereo.json"), "w", encoding="utf-8") as f:
        json.dump(out, f)
    print("\n[*] 已写出 build/stereo.json")


if __name__ == "__main__":
    main()

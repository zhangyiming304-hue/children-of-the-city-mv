# -*- coding: utf-8 -*-
"""
export_video.py —— 把整部 MV 渲染成 mp4。

管线：
    字符网格 → numpy RGB → ffmpeg（libx264 / yuv420p）
音轨直接取自 assets/children_of_the_city.mp3。

为了不把时间浪费在单线程上，整片按帧切成 N 片并行渲染，
每片各自编码成 mp4，最后无损拼接并挂上音轨。
每一帧的时间戳严格等于 frame / fps，因此音画天然同步。

用法：
    python export_video.py                 # 自动并行
    python export_video.py --shards 4
    python export_video.py --fps 24 --crf 16
    python export_video.py --shard 0 --of 4 --out build/parts/p0.mp4
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

FFMPEG = os.environ.get("FFMPEG", r"D:\DSH\tools\ffmpeg\ffmpeg.exe")
MP3 = os.path.join(ROOT, "assets", "children_of_the_city.mp3")
VIDEO_OUT = os.path.join(ROOT, "dist", "children_of_the_city_ansi.mp4")

GRID_W, GRID_H = 128, 36
CELL_W, CELL_H = 10, 20
PIX_W, PIX_H = GRID_W * CELL_W, GRID_H * CELL_H


def load_sync_offset() -> float:
    """
    读取 play.py 里用 [ ] 调好、按 s 保存的同步偏移。

    控制台播放时是 t = 音频位置 + offset；到了视频里，第 i 帧固定落在
    视频时间 i/fps，所以要让画面同样"延后 offset"，就得取 i/fps - offset
    处的内容。两边读同一个文件，你在控制台里调准了，视频也就准了。
    """
    import json
    p = os.path.join(ROOT, "build", "sync.json")
    try:
        with open(p, encoding="utf-8") as f:
            return float(json.load(f).get("offset", 0.0))
    except Exception:
        return 0.0


def render_range(f0: int, f1: int, fps: float, out_path: str, bloom: bool,
                 crf: int, preset: str) -> None:
    """渲染 [f0, f1) 帧，直接管道给 ffmpeg 编码。"""
    import director
    import timeline as TL
    from render import FrameRenderer
    import numpy as np

    tl = TL.load()
    d = director.Director(TL.to_director(tl))
    r = FrameRenderer(GRID_W, GRID_H, CELL_W, CELL_H, bloom=bloom)
    offset = load_sync_offset()

    cmd = [FFMPEG, "-y", "-v", "error",
           "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", "%dx%d" % (PIX_W, PIX_H), "-r", str(fps), "-i", "-",
           "-an",
           "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
           "-pix_fmt", "yuv420p", "-g", str(int(fps * 2)),
           out_path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    assert proc.stdin is not None
    n = f1 - f0
    t0 = time.time()
    for i in range(f0, f1):
        t = max(0.0, i / fps - offset)
        g = d.frame(t)
        img = r.render(g)
        proc.stdin.write(np.asarray(img, dtype=np.uint8).tobytes())
        if (i - f0) % 48 == 0 and i > f0:
            el = time.time() - t0
            done = i - f0
            print("    [%d/%d] %d/%d 帧  %.1f%%  %.0f ms/帧  余 %.0f s" % (
                f0, f1, done, n, done * 100.0 / n, el * 1000 / done,
                el / done * (n - done)), flush=True)
    proc.stdin.close()
    proc.wait()
    if proc.returncode != 0:
        raise RuntimeError("ffmpeg 失败 shard %d-%d" % (f0, f1))
    print("    [%d/%d] 完成，用时 %.0f s" % (f0, f1, time.time() - t0), flush=True)


def concat(parts: list[str], out: str) -> None:
    lst = os.path.join(ROOT, "build", "parts.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in parts:
            f.write("file '%s'\n" % p.replace("\\", "/"))
    subprocess.run([FFMPEG, "-y", "-v", "error", "-f", "concat", "-safe", "0",
                    "-i", lst, "-c", "copy", out], check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fps", type=float, default=24.0)
    ap.add_argument("--shards", type=int, default=0)
    ap.add_argument("--crf", type=int, default=16)
    ap.add_argument("--preset", default="veryfast")
    ap.add_argument("--no-bloom", action="store_true")
    ap.add_argument("--shard", type=int, default=-1)
    ap.add_argument("--of", type=int, default=1)
    ap.add_argument("--out", default="")
    ap.add_argument("--duration", type=float, default=0.0)
    args = ap.parse_args()

    import timeline as TL
    tl = TL.load()
    duration = args.duration or tl["duration"]
    total = int(duration * args.fps)

    # 子进程模式：只渲染自己那一片
    if args.shard >= 0:
        f0 = total * args.shard // args.of
        f1 = total * (args.shard + 1) // args.of
        render_range(f0, f1, args.fps, args.out, not args.no_bloom,
                     args.crf, args.preset)
        return

    nsh = args.shards or max(1, min(6, (os.cpu_count() or 4) // 3))
    os.makedirs(os.path.join(ROOT, "build", "parts"), exist_ok=True)
    os.makedirs(os.path.dirname(VIDEO_OUT), exist_ok=True)
    off = load_sync_offset()
    print("[*] 共 %d 帧 (%.2f fps, %.2f s)，分 %d 片并行渲染"
          % (total, args.fps, duration, nsh))
    if abs(off) > 0.0005:
        print("[*] 应用音画同步偏移 %+.3f s（来自 build/sync.json）" % off)
    parts = []
    procs = []
    for i in range(nsh):
        p = os.path.join(ROOT, "build", "parts", "p%02d.mp4" % i)
        parts.append(p)
        cmd = [sys.executable, os.path.abspath(__file__),
               "--shard", str(i), "--of", str(nsh), "--fps", str(args.fps),
               "--crf", str(args.crf), "--preset", args.preset,
               "--duration", str(duration), "--out", p]
        if args.no_bloom:
            cmd.append("--no-bloom")
        procs.append((i, subprocess.Popen(cmd)))

    t0 = time.time()
    failed = []
    for i, p in procs:
        rc = p.wait()
        if rc != 0:
            failed.append(i)
    if failed:
        print("[!] 分片失败：", failed)
        sys.exit(1)
    print("[*] 分片渲染完成，用时 %.0f s" % (time.time() - t0))

    silent = os.path.join(ROOT, "build", "video_silent.mp4")
    print("[*] 拼接 …")
    concat(parts, silent)

    print("[*] 挂上音轨 …")
    subprocess.run([FFMPEG, "-y", "-v", "error",
                    "-i", silent, "-i", MP3,
                    "-map", "0:v:0", "-map", "1:a:0",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                    "-shortest", VIDEO_OUT], check=True)
    size = os.path.getsize(VIDEO_OUT) / 1024 / 1024
    print("[*] 完成：%s  (%.1f MB)" % (VIDEO_OUT, size))


if __name__ == "__main__":
    main()

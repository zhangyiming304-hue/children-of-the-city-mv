# -*- coding: utf-8 -*-
"""
calibrate.py —— 用你的耳朵校准歌词时间轴。

时间轴是我用信号处理"量"出来的（能量包络 + 句间换气谷点），
但测量总有误差。你听得见，所以最终裁决权在你这里：

    听着歌，每当前面一句唱完、下一句开口，就敲一下空格。

敲完 33 下，build/timeline.json 会被真实时间覆盖，
再渲染一遍视频，每一句就都钉在拍子上了。

操作：
    [空格] 记下这一句的起始时间
    [z]    撤销上一次
    [s]    跳过这一句（当作纯器乐，不进时间轴）
    [←/→]  前后回退 5 秒（重新听）
    [q]    退出并保存

用法：
    python calibrate.py            # 从头开始校准
    python calibrate.py --from 7   # 从第 8 句开始（前面沿用现有时间轴）
"""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from lyrics import PRESCRIPTS  # noqa: E402
import timeline as TL  # noqa: E402

MP3 = os.path.join(ROOT, "assets", "children_of_the_city.mp3")
ALIAS = "dshcal"


def mci_open(path):
    mci = ctypes.windll.winmm.mciSendStringW
    buf = ctypes.create_unicode_buffer(512)
    p = path
    try:
        k = ctypes.windll.kernel32
        need = k.GetShortPathNameW(path, None, 0)
        if need:
            sb = ctypes.create_unicode_buffer(need)
            if k.GetShortPathNameW(path, sb, need):
                p = sb.value
    except Exception:
        pass
    if int(mci('open "%s" type mpegvideo alias %s' % (p, ALIAS), buf, 512, 0)):
        if int(mci('open "%s" alias %s' % (p, ALIAS), buf, 512, 0)):
            return None, None
    mci("set %s time format milliseconds" % ALIAS, buf, 512, 0)
    return mci, buf


def pos_ms(mci, buf):
    if mci("status %s position" % ALIAS, buf, 512, 0) != 0:
        return None
    try:
        return int(buf.value)
    except ValueError:
        return None


def cmd(mci, buf, s):
    mci(s, buf, 512, 0)


def read_key():
    import msvcrt
    c = msvcrt.getch()
    if c in (b"\x00", b"\xe0"):
        c2 = msvcrt.getch()
        return {b"K": "left", b"M": "right"}.get(c2, "?")
    if c == b" ":
        return "space"
    if c in (b"q", b"Q"):
        return "quit"
    if c in (b"z", b"Z"):
        return "undo"
    if c in (b"s", b"S"):
        return "skip"
    return "?"


def fmt(ms):
    if ms is None:
        return "--:--.---"
    return "%02d:%02d.%03d" % (ms // 60000, (ms // 1000) % 60, ms % 1000)


def draw(marks, cur, t_ms, total):
    os.system("cls" if os.name == "nt" else "clear")
    W = 78
    print("═" * W)
    print(" 校 准 模 式 · 逐 句 打 点      INDEX / PRESCRIPT TERMINAL")
    print("═" * W)
    print(" 当前时间 %s        已标记 %d / %d" % (fmt(t_ms), len(marks), total))
    print("─" * W)
    n = len(marks)
    lo = max(0, n - 6)
    for i in range(lo, n):
        en, zh = PRESCRIPTS[i]
        print("  %2d  %s  %s" % (i + 1, fmt(int(marks[i] * 1000)), en[:52]))
    print("─" * W)
    if cur < total:
        en, zh = PRESCRIPTS[cur]
        print(" 下一句 [%d/%d] —— 听到它开口，就敲空格：" % (cur + 1, total))
        print()
        print("   " + en)
        print("   " + zh)
    else:
        print(" 全部标记完成。按 q 保存并退出。")
    print()
    print("─" * W)
    print(" [空格] 记下这句的起点    [z] 撤销    [←/→] 回退/前进 5 秒")
    print(" [s] 跳过这句（当作器乐）  [q] 保存并退出")
    print("═" * W)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="frm", type=int, default=0,
                    help="从第几句开始校准（0 起）")
    args = ap.parse_args()

    if os.name != "nt":
        print("校准需要 Windows 的 MCI 播放。")
        return 1
    mci, buf = mci_open(MP3)
    if mci is None:
        print("[!] 打不开音频：%s" % MP3)
        return 1

    tl = TL.load()
    base = {int(i): a for a, b, i in tl["spans"]}
    ends = {int(i): b for a, b, i in tl["spans"]}
    marks = []
    for i in range(len(PRESCRIPTS)):
        marks.append(base.get(i, 0.0))
    marks = marks[:args.frm]
    cur = args.frm
    total = len(PRESCRIPTS)

    start_ms = int(marks[-1] * 1000) if marks else 0
    start_ms = max(0, start_ms - 3000)
    cmd(mci, buf, "seek %s to %d" % (ALIAS, start_ms))
    cmd(mci, buf, "play %s" % ALIAS)

    try:
        while True:
            t = pos_ms(mci, buf)
            draw(marks, cur, t, total)
            k = read_key()
            t = pos_ms(mci, buf) or 0
            if k == "quit":
                break
            elif k == "space" and cur < total:
                marks.append(t / 1000.0)
                cur += 1
            elif k == "skip" and cur < total:
                cur += 1
            elif k == "undo" and marks:
                marks.pop()
                cur = max(0, cur - 1)
            elif k == "left":
                t2 = max(0, (pos_ms(mci, buf) or 0) - 5000)
                cmd(mci, buf, "seek %s to %d" % (ALIAS, t2))
            elif k == "right":
                t2 = (pos_ms(mci, buf) or 0) + 5000
                cmd(mci, buf, "seek %s to %d" % (ALIAS, t2))
    except KeyboardInterrupt:
        pass
    finally:
        cmd(mci, buf, "stop %s" % ALIAS)
        cmd(mci, buf, "close %s" % ALIAS)

    if len(marks) < 2:
        print("没有标记，未写入。")
        return 0

    # 组装 spans：相邻两句之间就是这一句的时长
    spans = []
    for i in range(len(marks)):
        a = marks[i]
        b = marks[i + 1] if i + 1 < len(marks) else tl["outro_start"]
        spans.append([round(a, 3), round(b, 3), i])
    # 间隔过大的地方自动拆成间奏
    interludes = []
    out_spans = []
    for a, b, i in spans:
        if b - a > 14.0:
            mid = round((a + b) / 2.0, 3)
            out_spans.append([a, mid, i])
            interludes.append([mid, b])
        else:
            out_spans.append([a, b, i])

    new = {
        "duration": tl["duration"],
        "intro_end": round(marks[0], 3),
        "outro_start": tl["outro_start"],
        "interludes": interludes,
        "spans": out_spans,
        "source": "manual-calibration",
    }
    TL.save(new)
    print("\n已写入 build/timeline.json（共 %d 条指令，%d 段间奏）"
          % (len(out_spans), len(interludes)))
    print("重新渲染：python export_video.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""
sync.py —— 五下敲定音画同步。

时间轴是我用信号处理"量"出来的（能量包络 + 句间换气谷点），
但测量总有偏差；再加上 MCI 的 play 是异步的，声音出来时 position
已经在走了。结果是字母和音乐对不上。

你听得见，所以由你定：跟着音乐，在下面五个时刻各敲一下空格——

    1. 主歌 1 的第一句开口
    2. 副歌 1 的第一句开口
    3. 主歌 2 的第一句开口
    4. 副歌 2 的第一句开口
    5. 终章（读完 e 之前不要回家）那句开口

段内每句的相对长度沿用我量出来的比例（那部分误差不累积），
所以敲五下就能把整首歌重新钉准。

操作：
    [空格] 记下当前锚点      [z] 撤销
    [←/→] 回退 / 前进 5 秒   [q] 保存并退出

用法：
    python sync.py
"""

from __future__ import annotations

import ctypes
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from lyrics import PRESCRIPTS  # noqa: E402
import timeline as TL  # noqa: E402

MP3 = os.path.join(ROOT, "assets", "children_of_the_city.mp3")
ALIAS = "dshsync"

# (锚点名, 该段第一句的下标, 该段包含的句子下标)
ANCHORS = [
    ("主歌 1 第一句", 0, list(range(0, 10))),
    ("副歌 1 第一句", 10, list(range(10, 13))),
    ("主歌 2 第一句", 13, list(range(13, 28))),
    ("副歌 2 第一句", 28, list(range(28, 31))),
    ("终章 第一句", 31, list(range(31, 33))),
]


def mci_open(path):
    mci = ctypes.windll.winmm.mciSendStringW
    buf = ctypes.create_unicode_buffer(512)
    p = path
    try:
        k = ctypes.windll.kernel32
        need = k.GetShortPathNameW(path, None, 0)
        if need:
            sb = ctypes.create_unicode_buffer(need)
            if k.GetShortPathNameW(path, sb, need):
                p = sb.value
    except Exception:
        pass
    if int(mci('open "%s" type mpegvideo alias %s' % (p, ALIAS), buf, 512, 0)):
        if int(mci('open "%s" alias %s' % (p, ALIAS), buf, 512, 0)):
            return None, None
    mci("set %s time format milliseconds" % ALIAS, buf, 512, 0)
    return mci, buf


def pos_ms(mci, buf):
    if mci("status %s position" % ALIAS, buf, 512, 0) != 0:
        return 0
    try:
        return int(buf.value)
    except ValueError:
        return 0


def cmd(mci, buf, s):
    mci(s, buf, 512, 0)


def read_key():
    import msvcrt
    c = msvcrt.getch()
    if c in (b"\x00", b"\xe0"):
        c2 = msvcrt.getch()
        return {b"K": "left", b"M": "right"}.get(c2, "?")
    if c == b" ":
        return "space"
    if c in (b"q", b"Q"):
        return "quit"
    if c in (b"z", b"Z"):
        return "undo"
    if c in (b"r", b"R"):
        return "restart"
    return "?"


def fmt(ms):
    return "%02d:%02d.%03d" % (ms // 60000, (ms // 1000) % 60, ms % 1000)


def draw(marks, cur, t_ms, duration):
    os.system("cls" if os.name == "nt" else "clear")
    W = 74
    print("═" * W)
    print(" 音 画 同 步 · 锚 点 校 准        INDEX / PRESCRIPT TERMINAL")
    print("═" * W)
    print(" 当前 %s / %s          已标记 %d / %d"
          % (fmt(t_ms), fmt(int(duration * 1000)), len(marks), len(ANCHORS)))
    print("─" * W)
    if cur < len(ANCHORS):
        name, first, _ = ANCHORS[cur]
        en = PRESCRIPTS[first][0]
        zh = PRESCRIPTS[first][1]
        print(" 下一个锚点 [%d/%d]：%s" % (cur + 1, len(ANCHORS), name))
        print()
        print("   ▶  听到这一句开口的一瞬间，敲空格：")
        print()
        print("       " + en)
        print("       " + zh)
    else:
        print(" 五个锚点都标好了。按 q 保存并退出。")
    print()
    print("─" * W)
    if marks:
        print(" 已标记：")
        for i, m in enumerate(marks):
            nm = ANCHORS[i][0]
            d = ("  (+%.2f s)" % (m - marks[i - 1])) if i else ""
            print("   ✔ %-14s %s%s" % (nm, fmt(int(m * 1000)), d))
        print("─" * W)
    print(" [空格] 标记   [z] 撤销   [←/→] 回退/前进 5 秒   [r] 从头重听   [q] 保存退出")
    print("═" * W)


def main():
    if os.name != "nt":
        print("锚点校准需要 Windows 的 MCI 播放。")
        return 1
    mci, buf = mci_open(MP3)
    if mci is None:
        print("[!] 打不开音频：%s" % MP3)
        return 1

    tl = TL.load()
    duration = tl["duration"]
    marks: list[float] = []
    cur = 0
    cmd(mci, buf, "seek %s to 0" % ALIAS)
    cmd(mci, buf, "play %s" % ALIAS)

    try:
        while True:
            draw(marks, cur, pos_ms(mci, buf), duration)
            k = read_key()
            if k == "quit":
                break
            elif k == "space" and cur < len(ANCHORS):
                marks.append(round(pos_ms(mci, buf) / 1000.0, 3))
                cur += 1
            elif k == "undo" and marks:
                marks.pop()
                cur = max(0, cur - 1)
            elif k == "left":
                cmd(mci, buf, "seek %s to %d" % (ALIAS, max(0, pos_ms(mci, buf) - 5000)))
            elif k == "right":
                cmd(mci, buf, "seek %s to %d" % (ALIAS, pos_ms(mci, buf) + 5000))
            elif k == "restart":
                marks = []
                cur = 0
                cmd(mci, buf, "seek %s to 0" % ALIAS)
    except KeyboardInterrupt:
        pass
    finally:
        cmd(mci, buf, "stop %s" % ALIAS)
        cmd(mci, buf, "close %s" % ALIAS)

    if len(marks) < 2:
        print("\n标记不足两个，未写入。")
        return 0

    # 用锚点重建时间轴：段内**均匀**分配（实测句长与字数无关）
    spans = []
    interludes = []
    for i, m in enumerate(marks):
        nm, first, idxs = ANCHORS[i]
        end = marks[i + 1] if i + 1 < len(marks) else tl["outro_start"]
        span = max(0.1, end - m)
        step = span / len(idxs)
        for k, j in enumerate(idxs):
            spans.append([round(m + step * k, 3),
                          round(m + step * (k + 1), 3), j])
        # 段太长说明中间有器乐间奏
        if span > 20.0:
            mid = round((m + end) / 2.0, 3)
            last = spans[-1]
            if last[1] > mid:
                interludes.append([mid, last[1]])
                last[1] = mid

    spans.sort(key=lambda s: s[0])
    new = {
        "duration": duration,
        "intro_end": round(marks[0], 3),
        "outro_start": tl["outro_start"],
        "interludes": interludes,
        "spans": spans,
        "source": "anchor-calibration",
        "anchors": marks,
    }
    TL.save(new)
    print("\n已写入 build/timeline.json")
    print("  第一句 %s   副歌 %s   终章 %s" %
          (fmt(int(marks[0] * 1000)),
           fmt(int(marks[1] * 1000)) if len(marks) > 1 else "—",
           fmt(int(marks[-1] * 1000))))
    print("重新渲染视频：python export_video.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""
effects.py —— 程序化视觉原语。

全部效果都是【时间的纯函数】：给定 t（秒）与坐标，
输出确定的字符与颜色。这样同一份作品可以
被终端实时播放、被导出成 HTML、被逐帧渲染成视频，
三者画面完全一致；也允许渲染视频时任意跳帧、多进程分片。

随机性一律来自 h01() 这个哈希，而不是全局 random 状态。
"""

from __future__ import annotations

import math

import theme as T
from grid import Grid, text_width

MASK = 0xFFFFFFFF


def h01(*args) -> float:
    """确定性哈希 → [0,1)。同样的参数永远得到同样的值。"""
    n = 0x9E3779B9
    for i, a in enumerate(args):
        v = int(a) & MASK
        n = (n ^ (v * (0x85EBCA6B + i * 0x27D4EB2F))) & MASK
        n = (n ^ (n >> 15)) * 0x2545F491 & MASK
        n = (n ^ (n >> 13)) & MASK
    n = (n ^ (n >> 16)) & MASK
    return n / 4294967296.0


def hsym(*args):
    return h01(*args) * 2.0 - 1.0


# ----------------------------------------------------------------------
# 覆盖/调色工具
# ----------------------------------------------------------------------

def dim_region(g: Grid, x: int, y: int, w: int, h: int, k: float) -> None:
    """把区域内已有内容的亮度乘以 k。"""
    for yy in range(max(0, y), min(g.h, y + h)):
        base = yy * g.w
        for xx in range(max(0, x), min(g.w, x + w)):
            i = base + xx
            c = g.fg[i]
            if c is not None:
                g.fg[i] = T.scale(c, k)


def tint_region(g: Grid, x: int, y: int, w: int, h: int, color, k: float) -> None:
    """把区域内已有内容的颜色朝 color 混合 k 比例。"""
    for yy in range(max(0, y), min(g.h, y + h)):
        base = yy * g.w
        for xx in range(max(0, x), min(g.w, x + w)):
            i = base + xx
            c = g.fg[i]
            if c is not None:
                g.fg[i] = T.lerp(c, color, k)


def shift_row(g: Grid, y: int, dx: int) -> None:
    """整行水平循环位移（画面撕裂）。"""
    if dx == 0 or not (0 <= y < g.h):
        return
    base = y * g.w
    w = g.w
    dx %= w
    sl = slice(base, base + w)
    g.ch[sl] = g.ch[sl][-dx:] + g.ch[sl][:-dx]
    g.fg[sl] = g.fg[sl][-dx:] + g.fg[sl][:-dx]
    g.bg[sl] = g.bg[sl][-dx:] + g.bg[sl][:-dx]
    g.at[sl] = g.at[sl][-dx:] + g.at[sl][:-dx]


# ----------------------------------------------------------------------
# 背景：都市
# ----------------------------------------------------------------------

def cityscape(g: Grid, t: float, y_base: int, seed: int = 0,
              body=T.GHOST, edge=T.DIM2, scroll: float = 0.0,
              max_h: int = 18, lit_color=T.NEON_CYAN, lit_prob: float = 0.05,
              lit_color2=T.NEON_MAG, spike: int = 0) -> None:
    """
    程序化天际线。楼高由若干正弦叠加而成，滚动时连绵不绝。
    spike > 0 时，随机某处会窜出一座特别高的塔（都市的中心塔）。
    """
    w = g.w
    for x in range(w):
        wx = x + scroll
        hgt = (
            4.0
            + 3.2 * math.sin(wx * 0.031 + seed * 1.7)
            + 2.1 * math.sin(wx * 0.087 + seed * 0.9)
            + 1.3 * math.sin(wx * 0.211 + seed * 2.3)
            + 2.6 * h01(int(wx * 0.5), seed, 7)
        )
        if spike:
            # 中心塔：在某个世界坐标处拔高
            d = abs(((wx + 37 * seed) % 260) - 130)
            if d < spike:
                hgt += (spike - d) * 0.7
        h = int(max(2, min(max_h, hgt)))
        top = y_base - h
        # 楼体
        for yy in range(max(0, top), min(g.h, y_base + 1)):
            edge_cell = (yy == top) or (yy == y_base)
            col = edge if edge_cell else body
            g.put(x, yy, "█", col)
        # 窗户：世界坐标固定，因此滚动时窗户跟着楼走
        for yy in range(max(0, top + 1), min(g.h, y_base)):
            k = h01(int(wx * 0.5), yy, seed, 31)
            if k < lit_prob:
                c = lit_color if h01(int(wx), yy, seed, 5) < 0.62 else lit_color2
                g.put(x, yy, "▪", c)
            elif k < lit_prob * 2.1:
                g.put(x, yy, "·", T.scale(lit_color, 0.35))


def perspective_floor(g: Grid, t: float, horizon: int, color=T.DIM,
                      color_hot=T.NEON_CYAN, speed: float = 1.0,
                      cx: float | None = None, roll: float = 0.0,
                      pan: float = 0.0, y1: int | None = None) -> None:
    """
    透视网格地板：一条无限延伸、向观者扑来的都市通道。

    转弯有三个独立的分量，别混：

    cx    —— 消失点的横坐标。观者偏头看向哪边，汇聚点就移到哪边。
    pan   —— 近处景物的横向流速。转头时越近的东西掠得越快，
             所以这个位移按深度加权：消失点不动，屏幕底部偏得最多。
             **这是"转向"和"整条路右移"的分界**——只挪 cx 而近处不流，
             看着就是把路面平搬；近处再反向掠过去，才像人真的转了头。
    roll  —— 车身侧倾（约 -1..1），很轻的一层。
    y1    —— 画到哪一行为止（默认画到画布底部）。
    """
    w = g.w
    h = g.h if y1 is None else y1
    if cx is None:
        cx = w / 2.0
    depth = max(1, h - horizon - 1)
    for y in range(horizon + 1, h):
        d = y - horizon
        spread = 3.0 + d * d * 0.06
        dep = d / depth                      # 0 = 远处，1 = 脚下
        # 近处向左掠（负号），远处几乎不动
        shift = -pan * dep + roll * dep * 2.0
        for k in range(-9, 10):
            x = int(cx + k * spread * 0.72 + shift)
            if 0 <= x < w:
                g.put(x, y, "│" if d > 2 else "·",
                      T.scale(color, min(1.0, 0.25 + d * 0.05)))
        # 横向线：随时间向观者滚动，同样跟着横移
        phase = (t * speed * 1.6) % 1.0
        for k in range(0, 9):
            fy = horizon + (k + phase) ** 2.1 * 0.55
            yy = int(fy)
            if horizon < yy < h:
                fade = min(1.0, 0.18 + (yy - horizon) * 0.05)
                off = int(-pan * ((yy - horizon) / depth) + roll * 1.5)
                if off == 0:
                    g.hline(0, yy, w, "─", T.scale(color, fade))
                else:
                    c = T.scale(color, fade)
                    for x in range(w):
                        xx = x + off
                        if 0 <= xx < w:
                            g.put(xx, yy, "─", c)
                if k % 3 == 0:
                    for x in range(0, w, 9):
                        if h01(x, yy, 3) < 0.25:
                            g.put(x, yy, "·", T.scale(color_hot, 0.5))


def road_view(g: Grid, t: float, horizon: int, cx: float | None = None,
              pan: float = 0.0, roll: float = 0.0, speed: float = 1.0,
              edge_color=T.STEEL, dash_color=T.NEON_CYAN,
              flare: float = 0.0, y1: int | None = None) -> None:
    """
    第一人称的道路。

    只有三样东西：左边缘、右边缘、中央虚线。原来这里铺的是一整片
    透视网格，几十条纵线挤在一起——那看着像方格纸，不像路。

    cx    —— 消失点横坐标（看向哪边）。
    pan   —— 近处景物的横向流速（转头时最近的东西掠得最快）。
    flare —— 远处的光晕强度，用来把消失点点亮。
    """
    w = g.w
    h = g.h if y1 is None else y1
    if cx is None:
        cx = w / 2.0
    depth = max(1, h - horizon - 1)

    for y in range(horizon + 1, h):
        d = y - horizon
        dep = d / depth                       # 0 = 远处，1 = 脚下
        shift = -pan * dep + roll * dep * 3.0
        # 路宽按二次增长，近处才拉得开
        half = 2.0 + d * d * 0.30
        fade = min(1.0, 0.20 + dep * 1.1)

        lx, rx = int(cx - half + shift), int(cx + half + shift)
        if 0 <= lx < w:
            g.put(lx, y, "┃" if d > 3 else "│", T.scale(edge_color, fade))
        if 0 <= rx < w:
            g.put(rx, y, "┃" if d > 3 else "│", T.scale(edge_color, fade))

        # 路肩：边线外侧再压一点暗色，路才"厚"
        if d > 3:
            for dx in (1, 2):
                if 0 <= lx - dx < w:
                    g.put(lx - dx, y, " ", None, T.scale(T.BG, 0.0))
                if 0 <= rx + dx < w:
                    g.put(rx + dx, y, " ", None, T.scale(T.BG, 0.0))

        # 路面横纹：随车速滚过来。没有它，两条边线之间空荡荡的，
        # 看着像个尖角而不是一条路。
        if d > 1 and (d + int(t * speed * 2.0)) % 3 == 0:
            rc = T.scale(T.DIM2, fade * 0.55)
            for xx in range(lx + 1, rx):
                if 0 <= xx < w and (xx + y) % 2 == 0:
                    g.put(xx, y, "·", rc)

        # 中央虚线：随车速向观者滚动
        if d > 2 and (d + int(t * speed * 3.0)) % 4 < 2:
            mx = int(cx + shift)
            if 0 <= mx < w:
                g.put(mx, y, "┊" if d > 5 else "┆",
                      T.scale(dash_color, fade * 0.85))

    # 消失点上的光晕
    if flare > 0.01:
        hy = max(0, horizon - 1)
        c = T.lerp(T.BG, T.WHITE_HOT, min(1.0, flare))
        for yy in range(max(0, hy - 1), min(h, hy + 2)):
            for xx in range(max(0, int(cx) - 4), min(w, int(cx) + 5)):
                g.put(xx, yy, "·", T.scale(c, 0.35 + flare * 0.5))


def yaw_field(g: Grid, t: float, horizon: int, pan: float = 0.0,
              spread: float = 0.0, yaw: float = 0.0, speed: float = 1.0,
              color=T.DIM, hot=T.NEON_CYAN, y1: int | None = None) -> None:
    """
    抽象化的转向场。

    这里**不画路**。路一旦画出来（边线、车道虚线、路面横纹），画面就
    落回"具象"了，和整片用数据说话的路子不搭。改为铺一层横向短线。

    三个量各管一件事，别混：

    pan    —— 横向流速。近处掠得快，远处几乎不动。
    yaw    —— 航向偏角。**它让短线真的斜过去**：正前方是 ─，
              右偏变 ╱，左偏变 ╲。只横移不倾斜的话，看着是数据在
              平移，而不是"朝向变了"——这是这一层最关键的差别。
    spread —— 中心亮带的张开度，转向时视野被拉开。

    另外叠两条时间线索：一条纵向扫描行，和零星的数据包实心块。
    没有它们，这层是静止的花纹；有了才有"数据在跑"的感觉。
    """
    w = g.w
    h = g.h if y1 is None else y1
    depth = max(1, h - horizon - 1)
    cx = w / 2.0
    scan = (t * speed * 0.55) % 1.0        # 纵向扫描相位
    pk = int(t * 7)                        # 数据包的相位

    for y in range(horizon + 1, h):
        d = y - horizon
        dep = d / depth                       # 0 = 远处，1 = 脚下
        shift = -pan * dep + yaw * dep * 10.0
        # 倾斜角随深度放大：近处的短线斜得最明显
        tilt = yaw * dep * 1.8
        if abs(tilt) < 0.18:
            ch = "─"
        else:
            ch = "╱" if tilt > 0 else "╲"
        step = 6 if dep < 0.40 else (4 if dep < 0.75 else 3)
        fade = min(1.0, 0.18 + dep * 0.85)
        band = 8.0 + spread * dep * 26.0
        near_scan = abs(dep - scan) < 0.07

        for x in range(-step, w + step, step):
            xx = x + int(shift)
            if not (0 <= xx < w):
                continue
            ln = 1 + int(dep * 3)
            near_centre = abs(xx - cx) < band
            c = T.scale(hot if near_centre else color,
                        fade * (1.0 if near_centre else 0.55))
            if near_scan:                  # 扫描行扫过时提亮
                c = T.lerp(c, T.WHITE_HOT, 0.42)
            # 数据包：稀疏几格换成实心块，像有东西被打包送过去
            if h01(xx, y, pk, 5) < 0.013:
                g.put(xx, y, "▓", T.lerp(c, T.WHITE_HOT, 0.45))
                continue
            for k in range(ln):
                if 0 <= xx + k < w:
                    g.put(xx + k, y, ch, c)


# ----------------------------------------------------------------------
# 背景：雨与数字
# ----------------------------------------------------------------------

def rain(g: Grid, t: float, speed: float = 26.0, density: float = 0.16,
         color=T.STEEL, color2=T.NEON_CYAN, slant: int = 0) -> None:
    """都市的雨。倾斜的细线。"""
    w, h = g.w, g.h
    span = h + 12
    for x in range(w):
        if h01(x, 11, 3) > density:
            continue
        sp = speed * (0.6 + h01(x, 2, 9) * 0.9)
        off = h01(x, 5, 1) * span
        y = int((t * sp + off) % span) - 6
        ln = 2 + int(h01(x, 8, 2) * 4)
        for i in range(ln):
            yy = y + i
            if 0 <= yy < h:
                xx = x + (i * slant) // 3
                if 0 <= xx < w:
                    k = 0.25 + 0.75 * (i / max(1, ln))
                    g.put(xx, yy, "│" if i == 0 else "|", T.scale(color, k) if i else color2)


def digits_rain(g: Grid, t: float, charset: str, speed: float = 9.0,
                density: float = 0.30, trail: int = 14,
                head_color=T.WHITE_HOT, body_color=T.TERM_GREEN,
                fade_to=T.TERM_GREEN_D, bg=None, seed: int = 0,
                col_gap: int = 2, y0: int = 0, y1: int | None = None) -> None:
    """
    数字雨。终章的"读不完的 e"用它：
    都市的意志以数字的形式无穷无尽地落下来。
    """
    w, h = g.w, g.h
    top = max(0, y0)
    bot = h if y1 is None else min(h, y1)
    span = h + trail
    n = len(charset)
    for x in range(0, w, col_gap):
        k = h01(x, seed, 17)
        if k > density * 3:
            continue
        sp = speed * (0.45 + h01(x, seed, 4) * 1.3)
        off = h01(x, seed, 6) * span
        head = int((t * sp + off) % span) - trail
        for i in range(trail):
            yy = head + i
            if not (top <= yy < bot):
                continue
            f = 1.0 - (trail - 1 - i) / trail  # 越靠近头越亮
            # h01 返回 [0,1)，必须先乘 n 再取整。
            # 原来漏了这个乘法，int() 恒为 0 —— 整场雨其实只落 charset[0] 这一个字符。
            idx = int(h01(x, yy, int(t * sp * 0.25), seed + i) * n)
            ch = charset[idx % n]
            if h01(x, yy, seed, 44) < 0.06:
                ch = " "  # 偶尔闪烁的空洞
            if i == trail - 1:
                g.put(x, yy, ch, head_color)
                if col_gap > 1:
                    g.put(x + 1, yy, ch, head_color)
            else:
                c = T.lerp(fade_to, body_color, f)
                if f > 0.75:
                    c = T.lerp(body_color, head_color, (f - 0.75) * 4)
                g.put(x, yy, ch, c)


def noise(g: Grid, t: float, density: float = 0.05, color=T.ASH,
          charset: str = " .·:;'`", seed: int = 0, y0: int = 0, y1: int = None) -> None:
    """静态噪点：让画面像被监控摄像头拍下来的（只用很轻的字符，别抢戏）。"""
    w, h = g.w, g.h
    y1 = h if y1 is None else y1
    q = int(t * 24)  # 每秒 24 帧的量化时间，保证可复现
    n = len(charset)
    for y in range(max(0, y0), min(h, y1)):
        for x in range(w):
            if h01(x, y, q, seed) < density:
                ch = charset[int(h01(x, y, q, seed + 7) * n) % n]
                g.put(x, y, ch, T.scale(color, 0.4 + h01(x, y, q, seed + 3) * 0.6))


def scanlines(g: Grid, t: float, k: float = 0.62, every: int = 2, offset: int = 0,
              y0: int = 0, y1: int | None = None) -> None:
    """隔行压暗，模拟 CRT 扫描线。"""
    bot = g.h if y1 is None else min(g.h, y1)
    for y in range(max(0, y0) + offset, bot, every):
        dim_region(g, 0, y, g.w, 1, k)


# ----------------------------------------------------------------------
# 事件视觉
# ----------------------------------------------------------------------

def blood_splat(g: Grid, cx: int, cy: int, r: float, seed: int = 0,
                color=T.BLOOD, core=T.BLOOD_DARK, density: float = 0.55) -> None:
    """血迹：以字符密度表现的喷溅。"""
    for y in range(max(0, cy - int(r)), min(g.h, cy + int(r) + 1)):
        for x in range(max(0, cx - int(r * 2)), min(g.w, cx + int(r * 2) + 1)):
            dx = (x - cx) / 2.0
            dy = y - cy
            d = math.hypot(dx, dy) / max(0.6, r)
            if d > 1.0:
                continue
            jitter = h01(x, y, seed, 13) * 0.5
            if d + jitter > 1.0:
                continue
            idx = int((d ** 0.7) * (len(T.BLOOD_CHARS) - 1) + jitter * 2)
            ch = T.BLOOD_CHARS[min(idx, len(T.BLOOD_CHARS) - 1)]
            if ch == " ":
                continue
            g.put(x, y, ch, core if d < 0.35 else color)


def glitch(g: Grid, t: float, intensity: float = 0.0, seed: int = 0,
           rate: float = 4.0) -> None:
    """
    故障：整行撕裂 + 幻影色块。

    rate 是每秒重新掷骰子的次数。原来写死 12——每 83 ms 画面就跳一次，
    持续几秒下来就是一片闪烁。默认降到 4；转场那种一闪而过的场合
    可以调高，反正只持续零点几秒。
    """
    if intensity <= 0.001:
        return
    q = int(t * rate)
    for y in range(g.h):
        if h01(y, q, seed, 23) < intensity * 0.45:
            dx = int(hsym(y, q, seed, 29) * (2 + intensity * g.w * 0.10))
            shift_row(g, y, dx)
    # 幻影色带
    bands = int(intensity * 4)
    for b in range(bands):
        q2 = int(t * rate * 0.5) + b
        y = int(h01(b, q2, seed, 41) * g.h)
        hh = 1 + int(h01(b, q2, seed, 43) * 2)
        c = (T.NEON_CYAN, T.NEON_MAG, T.BLOOD)[int(h01(b, q2, seed, 47) * 3) % 3]
        for yy in range(y, min(g.h, y + hh)):
            tint_region(g, 0, yy, g.w, 1, c, 0.55)


def ribbon(g: Grid, t: float, count: int = 3, seed: int = 0,
           color=T.PAPER, color2=T.BLOOD) -> None:
    """
    都市抛出的"绶带"：一条在空中翻卷的长纸带。
    它既是食指的纸条，也是歌词里那条引路的带子。
    """
    w, h = g.w, g.h
    for r in range(count):
        ph = h01(r, seed, 3) * 6.28
        amp = 3.0 + h01(r, seed, 5) * 5.0
        y0 = 4 + h01(r, seed, 7) * (h - 12)
        sp = 0.5 + h01(r, seed, 9) * 0.6
        for x in range(w):
            y = y0 + math.sin(x * 0.045 + t * sp * 2.0 + ph) * amp \
                   + math.sin(x * 0.13 - t * sp + ph * 2) * amp * 0.35
            yy = int(y)
            # 带子有宽度（2 行），并有明暗
            k = 0.55 + 0.45 * math.sin(x * 0.22 - t * sp * 3.0 + ph)
            c = T.lerp(T.scale(color, 0.45), color2, 0.18 + 0.18 * math.sin(t * 0.4 + r))
            g.put(x, yy, "▀", T.scale(c, 0.6 + k * 0.5))
            g.put(x, yy + 1, "▄", T.scale(c, 0.35 + k * 0.4))


def string_puppet(g: Grid, cx: int, top: int, bottom: int, t: float,
                  color=T.STEEL, cut: float = 0.0, seed: int = 0) -> None:
    """从上方垂下的牵线；cut>0 时线被剪断、下段开始飘落。"""
    for i, dx in enumerate((-6, -2, 2, 6)):
        x = cx + dx
        ph = h01(i, seed, 2) * 6.28
        for y in range(top, bottom):
            if y < 0 or y >= g.h:
                continue
            sway = math.sin(y * 0.12 + t * 1.4 + ph) * (0.6 + (y - top) * 0.04)
            xx = int(x + sway)
            frac = (y - top) / max(1, bottom - top)
            if cut > 0 and frac > 1.0 - cut:
                # 断掉的部分：向下坠落并飘走
                fall = (frac - (1.0 - cut)) / max(0.001, cut)
                yy = y + int(fall * fall * 14)
                xx = int(xx + math.sin(t * 2 + i) * fall * 4)
                if 0 <= yy < g.h and 0 <= xx < g.w:
                    g.put(xx, yy, "╵" if fall < 0.5 else "·", T.scale(color, 1.0 - fall * 0.8))
            else:
                g.put(xx, y, "│", T.scale(color, 0.75))


def box_glow(g: Grid, x: int, y: int, w: int, h: int, color, label: str = "",
             label_color=None) -> None:
    """带角标的高亮取景框（都市里的瞄准/标记）。"""
    g.put(x, y, "┌" + "─" * (w - 2) + "┐", color)
    g.put(x, y + h - 1, "└" + "─" * (w - 2) + "┘", color)
    for yy in range(y + 1, y + h - 1):
        g.put(x, yy, "│", color)
        g.put(x + w - 1, yy, "│", color)
    if label:
        lc = label_color or color
        g.put(x + 2, y, " " + label + " ", lc, T.BG)


# ----------------------------------------------------------------------
# 纸：食指的指令条
# ----------------------------------------------------------------------

def paper_slip(g: Grid, x: int, y: int, w: int, h: int, lines, t: float,
               reveal: float = 1.0, header: str = "PRESCRIPT",
               footer: str = "", accent=T.BLOOD,
               paper=T.PAPER, ink=(20, 18, 16)) -> None:
    """
    一张"指令纸条"：反色块 —— 米白的纸、黑色的印刷字。
    这是食指最核心的视觉：荒诞的指令被打印在纸上，而你只能服从。
    reveal 控制纸被"打印"出来的比例（0~1）。
    """
    if reveal <= 0:
        return
    inner_w = w - 2
    # 纸张本体
    for yy in range(y, y + h):
        if not (0 <= yy < g.h):
            continue
        for xx in range(x, x + w):
            if 0 <= xx < g.w:
                # 略微的纸纹
                shade = 1.0 - 0.05 * h01(xx, yy, 3)
                g.ch[yy * g.w + xx] = " "
                g.fg[yy * g.w + xx] = None
                g.bg[yy * g.w + xx] = T.scale(paper, shade)
    # 打印进度：按行从下往上
    printed = int(h * reveal + 0.999)
    for yy in range(y + printed, min(g.h, y + h)):
        for xx in range(x, x + w):
            if 0 <= xx < g.w:
                g.bg[yy * g.w + xx] = T.BG
    if printed < 2:
        return
    # 表头
    g.put(x + 2, y, header, accent, paper)
    g.put_right(x + w - 2, y, footer, (90, 84, 72), paper)
    g.hline(x + 1, y + 1, w - 2, "─", (150, 142, 120), paper)
    # 正文
    ly = y + 2
    for ln in lines:
        if ly >= y + printed - 1:
            break
        g.put(x + 2, ly, ln[:inner_w - 2], ink, paper)
        ly += 1
    # 纸的右边缘阴影
    for yy in range(y, min(g.h, y + printed)):
        if x + w < g.w:
            g.put(x + w, yy, "▌", T.scale(paper, 0.35), T.BG)


def stamp(g: Grid, x: int, y: int, text: str, color, bg=None, tilt: str = "=") -> None:
    """盖章。"""
    w = text_width(text) + 4
    g.put(x, y - 1, f"{tilt}{tilt * (w - 2)}{tilt}", T.scale(color, 0.5), bg)
    g.put(x, y, f"{tilt} {text} {tilt}", color, bg)
    g.put(x, y + 1, f"{tilt}{tilt * (w - 2)}{tilt}", T.scale(color, 0.5), bg)

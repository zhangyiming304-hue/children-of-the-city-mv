# -*- coding: utf-8 -*-
"""
timeline.py —— 时间轴的读写。

MV 的骨骼：什么时候打印哪一条指令。
时间轴来自 make_timeline.py（基于音轨测量）或 calibrate.py（人工校准）；
两者都不存在时退化为按歌词长度加权的估算，保证作品总能播放。

结构：
  spans      [[起, 止, 指令序号], ...]   每条指令占据的时间片
  interludes [[起, 止], ...]             器乐间奏（终端在此等待）
"""

from __future__ import annotations

import json
import os

from lyrics import PRESCRIPTS

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DEFAULT_PATH = os.path.join(ROOT, "build", "timeline.json")

FALLBACK_DURATION = 234.093


def estimate(duration: float = FALLBACK_DURATION, intro_end: float = 7.4,
             outro_start: float = 230.0) -> dict:
    """
    估算时间轴：把可用时间**均匀**分给 33 条指令。

    不用歌词字数加权——实测句长与字数无关（详见 make_timeline.weight），
    等分反而更贴合音乐。
    """
    n = len(PRESCRIPTS)
    span = max(1.0, outro_start - intro_end)
    step = span / n
    spans = []
    for i in range(n):
        a = intro_end + step * i
        b = intro_end + step * (i + 1)
        spans.append([round(a, 3), round(b, 3), i])
    return {
        "duration": round(duration, 3),
        "intro_end": round(intro_end, 3),
        "outro_start": round(outro_start, 3),
        "interludes": [],
        "spans": spans,
        "source": "estimate",
    }


def load(path: str | None = None) -> dict:
    path = path or DEFAULT_PATH
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        data.setdefault("source", "unknown")
        data.setdefault("interludes", [])
        return data
    return estimate()


def to_director(tl: dict) -> dict:
    return {
        "duration": float(tl["duration"]),
        "intro_end": float(tl["intro_end"]),
        "outro_start": float(tl["outro_start"]),
        "spans": [(float(a), float(b), int(i)) for a, b, i in tl["spans"]],
        "interludes": [(float(a), float(b)) for a, b in tl.get("interludes", [])],
        "source": tl.get("source", "?"),
    }


def save(tl: dict, path: str | None = None) -> None:
    path = path or DEFAULT_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(tl, f, ensure_ascii=False, indent=1)


def retime_first_line(actual_t: float, path: str | None = None) -> dict:
    """
    把"第一句实际开口的时刻"钉进时间轴。

    注意这里**不是整体平移**。整体平移看着简单，但会连坐：
    如果第一句其实在 12 秒（而不是我估的 7.4 秒），而副歌确实在 55 秒，
    那么把整条轴推后 4.6 秒就会让副歌也偏掉 4.6 秒。

    正确做法是只重排主歌 1（句 1–10）：让它从 actual_t 开始、
    到**原来的副歌起点**结束，后面的段落一个都不动。
    """
    tl = load(path)
    spans = [list(s) for s in tl["spans"]]
    i0 = next((i for i, s in enumerate(spans) if int(s[2]) == 0), None)
    i9 = next((i for i, s in enumerate(spans) if int(s[2]) == 9), None)
    if i0 is None or i9 is None:
        return tl
    end = float(spans[i9][1])           # 主歌 1 原来的结束 = 副歌 1 的起点
    start = max(0.0, float(actual_t))
    n = i9 - i0 + 1
    if end - start < n * 0.5:           # 明显不合理就不动
        return tl
    step = (end - start) / n
    for k in range(n):
        j = i0 + k
        spans[j][0] = round(start + step * k, 3)
        spans[j][1] = round(start + step * (k + 1), 3)
    tl["spans"] = spans
    tl["intro_end"] = round(start, 3)
    tl["source"] = "one-key-calibration"
    tl["first_line"] = round(start, 3)
    save(tl, path)
    return tl

# -*- coding: utf-8 -*-
"""
theme.py —— 《都市之子》ANSI MV 的配色与文字符号。

色板取自 Project Moon 的"都市"：
  · 食指的白袍与纸条        —— WHITE / BONE / PAPER
  · 都市的霓虹              —— NEON_CYAN / NEON_MAGENTA / NEON_BLUE
  · 血与锈                  —— BLOOD / BLOOD_DIM / RUST
  · 终端的冷绿与琥珀        —— TERM_GREEN / AMBER
所有颜色都是 24bit RGB，终端用真彩色转义序列输出，
视频管线则直接把这些 RGB 交给渲染器。
"""

from __future__ import annotations

# ---------- 基础 ----------
BG          = (6, 7, 9)          # 屏幕底色：都市的夜
BLACK       = (0, 0, 0)

# ---------- 食指 · 白 ----------
WHITE       = (240, 238, 230)    # 白袍
WHITE_HOT   = (255, 255, 252)    # 过曝的白，闪现用
BONE        = (206, 201, 188)
PAPER       = (228, 220, 192)    # 指令纸条
PAPER_DIM   = (150, 144, 124)

# ---------- 灰阶 ----------
ASH         = (132, 130, 124)
STEEL       = (96, 102, 112)
DIM         = (62, 66, 74)
DIM2        = (38, 41, 46)
GHOST       = (26, 28, 32)

# ---------- 都市霓虹 ----------
NEON_CYAN   = (58, 214, 220)
NEON_MAG    = (230, 62, 146)
NEON_BLUE   = (96, 140, 255)
NEON_VIOLET = (150, 92, 240)
AMBER       = (255, 178, 64)
GOLD        = (214, 180, 96)

# ---------- 血 ----------
BLOOD       = (172, 26, 26)
BLOOD_DIM   = (98, 16, 20)
BLOOD_DARK  = (54, 9, 12)
RUST        = (146, 64, 40)

# ---------- 终端 ----------
TERM_GREEN  = (150, 235, 110)
TERM_GREEN_D= (74, 120, 56)
TERM_AMBER  = (235, 176, 72)

# ---------- 语义别名 ----------
FG          = BONE               # 默认前景
FG_CALM     = ASH
FG_FAINT    = DIM
ACCENT      = NEON_CYAN
ALERT       = BLOOD
OK          = TERM_GREEN

# ---------- 符号 ----------
GLYPH = {
    "prescript":  "❙",      # 指令条
    "seal":       "◈",
    "bullet":     "▸",
    "drop":       "▪",
    "hand":       "☰",
    "index":      "☝",
    "block":      "█",
    "shade":      "▓",
    "light":      "░",
    "book":       "▤",
    "skull":      "☠",
    "star":       "✦",
    "heart":      "♥",
    "scissor":    "✂",
    "cross":      "✚",
    "check":      "✔",
    "warn":       "▲",
    "arrow":      "→",
    "pipe":       "▏",
}

# 血迹字符：从浓到淡
BLOOD_CHARS = "▓▒░·.,'` "

# 数字雨用的字符集（只保留数字与 e 的小数位，呼应"读完 e 之前不要回家"）
DIGITS = "0123456789"


def lerp(c1, c2, t: float):
    """两色线性插值。"""
    t = 0.0 if t < 0 else (1.0 if t > 1 else t)
    return (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t),
    )


def scale(c, k: float):
    """亮度缩放。"""
    return (max(0, min(255, int(c[0] * k))),
            max(0, min(255, int(c[1] * k))),
            max(0, min(255, int(c[2] * k))))

# -*- coding: utf-8 -*-
"""
控制台尺寸诊断。

在**真实控制台窗口**里跑（双击，或在 cmd 里执行），不要在管道里跑：

    cd src
    python diag_size.py

它会打印可见窗口 / 缓冲区 / term_size() 的差异，以及开屏实际画到了第几列。
排查"画面没贴到右边"这类问题时先跑这个，能省掉一半猜测。
结果同时写到 build/_diag.txt。
"""
import ctypes
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(HERE), "build", "_diag.txt")


class COORD(ctypes.Structure):
    _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]


class SMALL_RECT(ctypes.Structure):
    _fields_ = [("Left", ctypes.c_short), ("Top", ctypes.c_short),
                ("Right", ctypes.c_short), ("Bottom", ctypes.c_short)]


class INFO(ctypes.Structure):
    _fields_ = [("dwSize", COORD), ("dwCursorPosition", COORD),
                ("wAttributes", ctypes.c_ushort), ("srWindow", SMALL_RECT),
                ("dwMaximumWindowSize", COORD)]


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def main() -> int:
    lines = []

    def say(s):
        lines.append(s)
        try:
            print(s)
        except Exception:
            pass

    k = ctypes.windll.kernel32
    u = ctypes.windll.user32
    h = k.GetStdHandle(-11)
    info = INFO()
    ok = k.GetConsoleScreenBufferInfo(h, ctypes.byref(info))

    sw = sh = 0
    say("=" * 62)
    say("窗口尺寸诊断")
    say("=" * 62)
    if ok:
        sw = info.srWindow.Right - info.srWindow.Left + 1
        sh = info.srWindow.Bottom - info.srWindow.Top + 1
        say("  srWindow   可见窗口      %3d x %-3d   ← 该用这个" % (sw, sh))
        say("  dwSize     缓冲区        %3d x %-3d" % (info.dwSize.X, info.dwSize.Y))
        say("  缓冲区多出              %d 列 / %d 行"
            % (info.dwSize.X - sw, info.dwSize.Y - sh))
    say("  shutil                   %s" % (shutil.get_terminal_size((120, 30)),))
    say("  COLUMNS 环境变量         %r" % os.environ.get("COLUMNS"))

    try:
        hwnd = k.GetConsoleWindow()
        r = RECT()
        u.GetClientRect(hwnd, ctypes.byref(r))
        pw, ph = r.right - r.left, r.bottom - r.top
        say("  客户区像素               %d x %d" % (pw, ph))
        if sw:
            say("  每字符宽度约             %.2f px" % (pw / sw))
    except Exception as e:
        say("  像素拿不到: %s" % e)

    sys.path.insert(0, HERE)
    import play  # noqa: E402
    w, hh = play.term_size()
    say("  play.term_size()         %d x %d" % (w, hh))

    info_d = {"cols": w, "lines": hh, "audio": "READY / MCI",
              "timeline": "lrc-synced", "offset": 0.0}
    g = play.build_splash(w, hh, 0.0, info_d)
    last = 0
    for y in range(hh):
        row = "".join(g.ch[y * w:(y + 1) * w]).replace("\x00", " ")
        last = max(last, len(row.rstrip()))
    say("  开屏最右内容在第         %d 列（共 %d 列，右边空 %d 列）"
        % (last, w, w - last))

    say("")
    say("=" * 62)
    say("排查「画面没贴到右边」时，看最后一行是不是 0。")
    say("=" * 62)

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

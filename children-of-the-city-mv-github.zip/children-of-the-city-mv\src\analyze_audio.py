# -*- coding: utf-8 -*-
"""
analyze_audio.py —— 听不见音乐，那就测量它。

用 ffmpeg 把 mp3 解成 22.05kHz 单声道 PCM，然后：
  1. 计算短时能量包络、谱通量与人声频带（300–3400Hz）能量；
  2. 在终端里用字符画出整首歌的结构图（方便肉眼核对段落）；
  3. 自动找出"人声段落"的起点，把 34 条指令对齐上去；
  4. 写出 build/timeline.json。

这一步本身就是作品的一部分：都市的意志不被聆听，只被测量。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import timeline as TL  # noqa: E402

FFMPEG = os.environ.get("FFMPEG", r"D:\DSH\tools\ffmpeg\ffmpeg.exe")
MP3 = os.path.join(ROOT, "assets", "children_of_the_city.mp3")
WAV = os.path.join(ROOT, "build", "analysis.wav")

SR = 22050
NFFT = 2048
HOP = 512
FRAME_RATE = SR / HOP  # ≈ 43.07 帧/秒


def decode() -> None:
    os.makedirs(os.path.dirname(WAV), exist_ok=True)
    cmd = [FFMPEG, "-y", "-v", "error", "-i", MP3,
           "-ac", "1", "-ar", str(SR), "-f", "wav", WAV]
    subprocess.run(cmd, check=True)


def load_wav(path: str):
    with wave.open(path, "rb") as w:
        assert w.getsampwidth() == 2
        sr = w.getframerate()
        n = w.getnframes()
        raw = w.readframes(n)
    x = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    return x, sr


def envelope(x: np.ndarray):
    """返回 (时间轴, 全带RMS, 人声带RMS, 谱通量)。"""
    n_frames = 1 + (len(x) - NFFT) // HOP
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(n_frames)[:, None]
    frames = x[idx]
    win = np.hanning(NFFT).astype(np.float32)
    frames = frames * win

    rms = np.sqrt((frames ** 2).mean(axis=1) + 1e-12)

    spec = np.abs(np.fft.rfft(frames, axis=1)) + 1e-9
    freqs = np.fft.rfftfreq(NFFT, 1.0 / SR)

    lo = (freqs >= 300) & (freqs <= 3400)
    vocal = np.sqrt((spec[:, lo] ** 2).mean(axis=1))

    lo2 = (freqs >= 60) & (freqs <= 250)
    bass = np.sqrt((spec[:, lo2] ** 2).mean(axis=1))

    hi = (freqs >= 5000)
    air = np.sqrt((spec[:, hi] ** 2).mean(axis=1))

    # 谱通量（半波整流）
    d = np.diff(np.log(spec), axis=0)
    flux = np.maximum(d, 0).mean(axis=1)
    flux = np.concatenate([[0.0], flux])

    t = np.arange(n_frames) / FRAME_RATE
    return t, rms, vocal, bass, air, flux


def smooth(a: np.ndarray, k: int) -> np.ndarray:
    if k <= 1:
        return a
    ker = np.ones(k, dtype=np.float32) / k
    return np.convolve(a, ker, mode="same")


def draw_ascii(t, series, labels, width=118, height=16):
    """把多条曲线叠画成字符图，用来肉眼检查歌曲结构。"""
    print("    " + "".join(str(int(x)) if i % 20 == 0 else " "
                           for i, x in enumerate(range(width))))
    step = max(1, len(t) // width)
    chars = " .:-=+*#%@"
    grid = [[" "] * width for _ in range(height)]
    colors = ["#", "o", "v", "b", "a"]
    for si, s in enumerate(series):
        col = colors[si % len(colors)]
        v = s[: len(s) // step * step].reshape(-1, step).max(axis=1)
        v = v / (v.max() + 1e-9)
        for x in range(min(width, len(v))):
            y = height - 1 - int(v[x] * (height - 1))
            grid[y][x] = col
    for r in grid:
        print("    " + "".join(r))
    print("    " + " ".join(labels))
    # 时间刻度
    total = t[-1]
    marks = [" "] * width
    for i in range(0, int(total) + 1, 10):
        x = int(i / total * (width - 1))
        if x < width:
            marks[x] = "|"
    print("    " + "".join(marks))
    print("    " + "".join(
        (str(int(i / total * total)) if i % max(1, int(total // 6)) < 10 else "")
        for i in range(width)))


def find_vocal_segments(t, vocal):
    """
    找出人声段落：以人声带能量的对数为特征，
    用"自适应阈值 + 最短时长"做分割。
    """
    v = np.log(vocal + 1e-9)
    v = smooth(v, 9)
    # 归一化
    v = (v - v.min()) / (v.max() - v.min() + 1e-9)
    # 自适应阈值：局部均值 + 偏移
    loc = smooth(v, int(FRAME_RATE * 6))
    thr = loc + 0.055
    active = v > thr

    segs = []
    start = None
    min_len = int(FRAME_RATE * 0.42)
    for i, a in enumerate(active):
        if a and start is None:
            start = i
        elif not a and start is not None:
            if i - start >= min_len:
                segs.append((t[start], t[i]))
            start = None
    if start is not None and len(active) - start >= min_len:
        segs.append((t[start], t[-1]))
    return segs, v


def main() -> None:
    if not os.path.exists(WAV):
        print("[*] 解码音轨 …")
        decode()
    x, sr = load_wav(WAV)
    dur = len(x) / sr
    print("[*] 时长 %.3f s  采样率 %d" % (dur, sr))

    t, rms, vocal, bass, air, flux = envelope(x)
    print("[*] 计算完成 %d 帧 (%.1f fps)" % (len(t), FRAME_RATE))

    draw_ascii(t, [rms, vocal, bass, air], ["rms", "vocal", "bass", "air"])

    # --- 段落能量表（每 5 秒一格），方便判断结构 ---
    print("\n[*] 5 秒一格的能量（数字越大越强，0-9）")
    step = int(FRAME_RATE * 5)
    line = []
    for i in range(0, len(vocal) - step, step):
        v = float(np.sqrt((vocal[i:i + step] ** 2).mean()))
        line.append(v)
    mx = max(line) + 1e-9
    for row in range(0, len(line), 24):
        chunk = line[row:row + 24]
        print("    t=%3ds  " % (row * 5) +
              "".join(str(min(9, int(v / mx * 10))) for v in chunk))

    segs, v = find_vocal_segments(t, vocal)
    print("\n[*] 检测到 %d 个有声段落：" % len(segs))
    for a, b in segs[:60]:
        print("    %7.2f → %7.2f   (%5.2f s)" % (a, b, b - a))

    with open(os.path.join(ROOT, "build", "segments.json"), "w", encoding="utf-8") as f:
        json.dump({"duration": dur, "segments": segs}, f, indent=1)
    print("\n[*] 段落已写入 build/segments.json")


if __name__ == "__main__":
    main()

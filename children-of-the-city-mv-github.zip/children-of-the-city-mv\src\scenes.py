# -*- coding: utf-8 -*-
"""
scenes.py —— 三十三条"指令"的画面。

整部 MV 的叙事框架：
屏幕属于食指（The Index）的指令终端。都市的意志把歌词一条条打印成
Prescript（指令），终端逐条执行、逐条记录，并把一切暴行写成
exit_code: 0 的日志。

**这里没有一幅"画"。**
没有手，没有心脏，没有白袍的人影。每一个意象都由它在控制台里的
数据表示来承担：

    "右手"      → 一个只有 bit0 置起的占用寄存器
    "一个人"    → 一行进程状态 + 一段掩码点阵
    "一具身体"  → 一张温度采样表
    "粉刷房间"  → 一次覆盖率统计
    "心脏"      → 一段环形缓冲区里的 ADC 采样
    "都市"      → 一段频谱；楼有多高，取决于那一刻有多少能量

歌词里的每一句都是荒诞的，而画面永远冷静、精确、毫不停顿。
这种反差就是"代码的冰冷感"。
"""

from __future__ import annotations

import math

import console as C
import effects as fx
import theme as T
from grid import CONTINUE, Grid, pad_to, text_width
from lyrics import BINARY_DIGITS as BIN, E_DIGITS

# 数字雨的基础速度（格/秒）。每列会再乘 0.45~1.75 的随机系数，
# 所以实际落速是 0.45~1.75 倍。内容区只有 27 行——
# 嫌快嫌慢就改这一个数，全片的雨都跟着变。
RAIN_SPEED = 1.0

# 内容区（不含 HUD）：y 从 2 到 28
AREA_Y0 = 2
AREA_Y1 = 29  # 设计基准值，实际由 e.ay1 提供
AW = 128  # 设计基准宽度；实际用 g.w                       # 内容区宽度


# ----------------------------------------------------------------------
# 公共零件
# ----------------------------------------------------------------------

def typed(g: Grid, x: int, y: int, text: str, fg, shown: int, bg=None,
          attr: int = 0, cursor=None) -> None:
    s = text[:max(0, shown)]
    g.put(x, y, s, fg, bg, attr)
    if cursor is not None and 0 <= shown < len(text):
        g.put(x + text_width(s), y, "▌", cursor, bg)


def typed_count(text: str, prog: float, start: float = 0.05, end: float = 0.62) -> int:
    if prog <= start:
        return 0
    if prog >= end:
        return len(text)
    k = (prog - start) / max(1e-6, end - start)
    return int(len(text) * k + 1.0)


def panel(g: Grid, x: int, y: int, w: int, h: int, title: str = "",
          fg=T.DIM, title_color=T.STEEL, bg=T.BG, style="double",
          fill: bool = True) -> None:
    if fill:
        g.fill_rect(x, y, w, h, " ", None, bg)
    g.box(x, y, w, h, fg, bg, style)
    if title:
        g.put(x + 2, y, " " + title + " ", title_color, bg)


def caption(g: Grid, y: int, text: str, color=T.DIM, bg=T.BG, x=2) -> None:
    """内容区最下方的一行注脚。"""
    g.fill_rect(0, y, g.w, 1, " ", None, bg)
    g.put(x, y, text, color, bg)


def spec_table(g: Grid, x: int, y: int, pairs, pad=14, key_color=T.STEEL,
               val_color=T.TERM_GREEN) -> None:
    C.kv_block(g, x, y, pairs, key_color, val_color, pad)


def noise01(*a) -> float:
    return fx.h01(*a)


# ----------------------------------------------------------------------
# 1–2  指令纸条
# ----------------------------------------------------------------------

def sc_slip(g: Grid, e) -> None:
    """一张从都市意志那里递来的纸条，以及它的字节。"""
    # 背景的城市剪影撤掉了——场景本身已经铺满，底下再压一层楼体
    # 只会糊在一起。这是它第四次被这么说了，干脆一次清干净。

    pw = min(g.w - 16, max(64, g.w * 3 // 5))
    ph = max(9, min(15, e.ay1 // 3))
    px = (g.w - pw) // 2
    py = max(5, (e.ay1 - ph - 4) // 2)
    fx.paper_slip(g, px, py, pw, ph, lines=[e.en, e.zh], t=e.t,
                  reveal=min(1.0, 0.25 + e.prog * 1.6),
                  header="PRESCRIPT", footer="#%02d" % (e.idx + 1),
                  accent=T.BLOOD)
    sy = py + int((ph - 1) * min(1.0, e.prog * 1.3))
    if sy < py + ph:
        g.hline(px, sy, pw, "═", T.NEON_CYAN)

    # 左边：这条指令在网络上的字节形式
    g.put(2, AREA_Y0, "RX  buf[%d]" % min(len(e.en), 64), T.DIM2, T.BG)
    per = 32 if g.w >= 170 else 16
    C.hexdump(g, 2, AREA_Y0 + 1, e.en[:96], base=0x7F00, per_line=per,
              max_lines=4, highlight=set(range(min(4, len(e.en)))))

    # 右下：执行状态
    # 靠右贴边：原来从 g.w-30 起，表格只占 20 列，右边白白空一截
    spec_table(g, g.w - 22, e.ay1 - 7, [
        ("feasible", "NO"),
        ("mandatory", "YES"),
        ("delay", "0.000 s"),
        ("ack", "IMPLIED"),
    ], pad=12, val_color=T.BLOOD)
    caption(g, e.ay1 - 1, "▸ 执行前请勿阅读全文。阅读本身即构成同意。")


# ----------------------------------------------------------------------
# 3  右手
# ----------------------------------------------------------------------

def sc_rule(g: Grid, e) -> None:
    """'请在扣下扳机时使用右手' —— 在这台机器里，就是某个位被置起。"""
    g.put(2, AREA_Y0, "HAND_OCCUPANCY_REG", T.STEEL, T.BG)
    g.put(2, AREA_Y0 + 1, "0x0001", T.DIM2, T.BG)
    C.bitfield(g, 10, AREA_Y0 + 1, 0x0001, 16, "RIGHT_HAND_ONLY",
               on_color=T.WHITE_HOT, off_color=T.DIM2, label_color=T.BLOOD)

    rows = [
        ["eat()", "R", "R", "0"],
        ["write()", "R", "R", "0"],
        ["pull_trigger()", "R", "R", "0"],
        ["everything_else()", "R", "—", "n/a"],
    ]
    shown = max(0, min(4, int(e.prog * 6)))
    C.table(g, 2, AREA_Y0 + 3, ["调用点", "期望", "实际", "偏差"],
            rows[:shown], [22, 6, 6, 6], bg=T.BG,
            aligns=["left", "left", "left", "right"],
            row_colors=[None, None, None, T.DIM2])

    spec_table(g, 2, AREA_Y0 + 10, [
        ("left.calls", "0"),
        ("left.denied", "0"),
        ("exception", "CLOSED"),
    ], pad=16, key_color=T.STEEL, val_color=T.ASH)

    # 掩码寄存器：这段形状是被写进内存的数据，右边是它的十六进制
    mx = g.w * 7 // 16
    g.put(mx, AREA_Y0, "MASK_REGION  0x00C1TY00", T.STEEL, T.BG)
    bits = [
        "..........",
        "..#.......",
        "..#.......",
        "..#####...",
        "..#####...",
        "..#.......",
        "..#.......",
        "..........",
    ]
    if e.prog > 0.5:
        bits[3] = "..######.."
        bits[4] = "..######.."
    C.mask_rows(g, mx, AREA_Y0 + 2, bits, on="#", off=".",
                on_color=T.WHITE_HOT, off_color=T.GHOST,
                hex_labels=True, label_color=T.DIM2)
    g.put(mx, AREA_Y0 + 11, "→ 一个'手'的形状，35 个比特，没有别的含义",
          T.DIM2, T.BG)
    caption(g, e.ay1 - 1, "▸ 规则不需要理由。规则只需要被满足。")


# ----------------------------------------------------------------------
# 4  谨遵指令
# ----------------------------------------------------------------------

def sc_comply(g: Grid, e) -> None:
    """合规度是这台机器唯一信仰的东西。"""
    fx.noise(g, e.t, density=0.008, seed=5)

    g.put(2, AREA_Y0, "COMPLIANCE MONITOR", T.STEEL, T.BG)
    prog = e.lt / max(0.001, e.dur)
    pct = min(1.0, prog * 1.25)
    spec_table(g, 2, AREA_Y0 + 1, [
        ("target", "100.000%"),
        ("actual", "%9.3f%%" % (pct * 100)),
        ("tolerance", "0.000%"),
    ], pad=12, key_color=T.STEEL,
        val_color=T.TERM_GREEN)
    C.gauge(g, 2, AREA_Y0 + 5, 60, pct, T.TERM_GREEN, T.DIM2)
    g.put(66, AREA_Y0 + 5, "%.1f%%" % (pct * 100), T.BONE, T.BG)

    dev = 0.42 * math.exp(-(e.lt % 3.0) * 2.6)
    g.put(2, AREA_Y0 + 7, "deviation %6.3f%%" % dev,
          T.AMBER if dev > 0.05 else T.DIM2, T.BG)
    if dev > 0.2:
        g.put(24, AREA_Y0 + 7, "CORRECTING…", T.BLOOD, T.BG)

    # 指令队列：一张表
    n = min(7, e.total - e.idx - 1)
    rows = []
    for i in range(n):
        idx = e.idx + i + 1
        en = e.all_en[idx][:44]
        rows.append(["%02d" % (idx + 1), en,
                     "EXECUTED" if i == 0 else "QUEUED",
                     "0.000" if i == 0 else "—"])
    C.table(g, 2, AREA_Y0 + 9, ["#", "指令", "状态", "偏差"], rows,
            [4, 46, 10, 7], bg=T.BG,
            row_colors=[T.TERM_GREEN] + [T.DIM2] * (n - 1))

    # 右侧：合规度的历史
    x0 = g.w * 39 // 64
    g.put(x0, AREA_Y0 + 1, "history (60 s)", T.STEEL, T.BG)
    C.sparkline(g, x0, AREA_Y0 + 2, 48,
                lambda i: 0.5 + 0.5 * math.cos(i * 0.35 + e.t * 2.0),
                T.TERM_GREEN, bg=T.BG, height=1)
    g.put(x0, AREA_Y0 + 4, "每次指令下达，它会掉 0.4 个百分点，", T.DIM2, T.BG)
    g.put(x0, AREA_Y0 + 5, "然后在 0.02 秒内被纠正回去。", T.DIM2, T.BG)
    g.put(x0, AREA_Y0 + 7, "deviation(t)", T.STEEL, T.BG)
    C.sparkline(g, x0, AREA_Y0 + 8, 48,
                lambda i: math.exp(-((e.lt % 3.0)) * 2.6) * (1 - i / 48.0),
                T.AMBER, bg=T.BG, height=5)
    spec_table(g, x0, AREA_Y0 + 15, [
        ("corrections", "%d" % int(e.t * 2)),
        ("rejections", "0"),
        ("free_will", "NOT_FOUND"),
    ], pad=14, key_color=T.STEEL, val_color=T.BLOOD)

    caption(g, e.ay1 - 1, "准则: 谨遵指令之意。其余分支未定义。")


# ----------------------------------------------------------------------
# 5–6  书桌
# ----------------------------------------------------------------------

def sc_desk(g: Grid, e) -> None:
    """在你意识到之前，你已经被锁在书桌前。"""
    fx.noise(g, e.t, density=0.008, seed=9)

    g.put(2, AREA_Y0, "PROCESS TABLE", T.STEEL, T.BG)
    rows = [
        ["0412", "you", "RUNNING", "00:00:%02d" % int(e.lt), "0"],
        ["0413", "desk.lock", "HOLDING", "—", "0"],
        ["0414", "dreams", "STOPPED", "—", "—"],
        ["0415", "free_will", "NOT_FOUND", "—", "—"],
    ]
    C.table(g, 2, AREA_Y0 + 1, ["PID", "NAME", "STATE", "CPU", "FD"],
            rows, [6, 12, 12, 9, 3], bg=T.BG,
            row_colors=[T.BONE, T.AMBER, T.DIM2, T.BLOOD])

    # fopen 表：哪些东西被打开了，哪些被扔掉了
    g.put(2, AREA_Y0 + 8, "OPEN FILES", T.STEEL, T.BG)
    spec_table(g, 2, AREA_Y0 + 9, [
        ("fd 0", "/dev/obedience"),
        ("fd 1", "/dev/null"),
        ("fd 2", "→ dreams  (moved)"),
    ], pad=10, val_color=T.ASH)
    C.hexdump(g, 2, AREA_Y0 + 13, b"while (alive) { obey(city.next()); }",
              base=0x00400000, per_line=16, max_lines=3)

    # 右边：那段正在跑的代码
    panel(g, 56, AREA_Y0 + 1, 70, 11, "desk_terminal", T.DIM2, T.STEEL)
    code = [
        "#include <obedience.h>",
        "while (alive) { obey(city.next()); }",
        "// dreams: moved to /dev/null",
        "assert(free_will == NULL);",
        "eye.tracking = LOCKED_ON(test);",
    ]
    for i, ln in enumerate(code):
        shown = int(len(ln) * min(1.0, max(0.0, e.prog * 2.4 - i * 0.3)))
        typed(g, 58, AREA_Y0 + 2 + i, ln, T.TERM_GREEN if i != 2 else T.DIM2,
              shown, cursor=T.TERM_GREEN if i == int(e.prog * 5) else None)

    # 视线锁定的计时
    g.put(56, AREA_Y0 + 14, "gaze_lock", T.DIM2, T.BG)
    C.gauge(g, 68, AREA_Y0 + 14, 40, min(1.0, e.prog * 1.2), T.BLOOD, T.DIM2)
    g.put(110, AREA_Y0 + 14, "100%", T.BLOOD, T.BG)
    caption(g, e.ay1 - 1, "▸ dreams: dropped on floor  |  视线: 已锁定在考卷上")


# ----------------------------------------------------------------------
# 7  目标锁定
# ----------------------------------------------------------------------

def sc_target(g: Grid, e) -> None:
    """30 分钟内找到一名伴侣。棕色头发为佳。"""
    # 背景的城市剪影撤掉了——场景本身已经铺满，底下再压一层楼体
    # 只会糊在一起。这是它第四次被这么说了，干脆一次清干净。

    g.put(2, AREA_Y0, "SCAN POPULATION", T.STEEL, T.BG)
    k = min(1.0, e.prog * 1.4)
    C.gauge(g, 2, AREA_Y0 + 1, 56, k, T.NEON_CYAN, T.DIM2)
    g.put(62, AREA_Y0 + 1, "4,182,993 → 1", T.BONE, T.BG)

    # 过滤器链：每一个人都只是一行统计
    rows = [
        ["alive", "4182993", "3902114", "12.4"],
        ["age ∈ [18,40]", "3902114", "1204118", "8.1"],
        ["hair.color==BRUNETTE", "1204118", "30419", "5.7"],
        ["no_next_of_kin", "30419", "3", "0.9"],
        ["select()", "3", "1", "0.0"],
    ]
    shown = max(0, min(5, int(e.prog * 6.5)))
    C.table(g, 2, AREA_Y0 + 3, ["谓词", "输入", "输出", "ms"],
            rows[:shown], [24, 10, 10, 6], bg=T.BG,
            aligns=["left", "right", "right", "right"],
            row_colors=[None, None, T.AMBER, None, T.NEON_MAG][:shown])

    # 右：30 分钟倒计时
    x0 = g.w * 31 // 64
    panel(g, x0, AREA_Y0 + 3, 62, 9, "DEADLINE", T.DIM2, T.BLOOD)
    remain = max(0.0, 1.0 - e.prog)
    g.put(x0 + 2, AREA_Y0 + 4, "T-00:%02d:%02d.%03d" % (
        int(remain * 30), int(remain * 1800) % 60,
        int(remain * 1800000) % 1000), T.BLOOD, T.BG, attr=1)
    C.gauge(g, x0 + 2, AREA_Y0 + 6, 56, remain,
            T.BLOOD if remain < 0.4 else T.AMBER, T.DIM2)
    spec_table(g, x0 + 2, AREA_Y0 + 8, [
        ("selected", "0x1F4A7C"),
        ("bonus", "+1  (brunette)"),
    ], pad=12, val_color=T.NEON_MAG)

    caption(g, e.ay1 - 1, "匹配池 4,182,993 人  |  筛选条件：可在 90 小时内处置")


# ----------------------------------------------------------------------
# 8  粉刷一新
# ----------------------------------------------------------------------

def sc_picturesque(g: Grid, e) -> None:
    """90 小时内挥洒他们的内脏 —— 验收标准是一次覆盖率统计。"""
    k = min(1.0, e.prog * 1.4)
    # 墙面覆盖率矩阵：每一格是 2.5% 的墙
    g.put(2, AREA_Y0, "WALL COVERAGE MAP   1 cell = 1.5%%", T.STEEL, T.BG)
    rows = max(6, e.ay1 - 4)
    cols = max(20, g.w // 2 - 8)

    def cov(i, j):
        v = (fx.h01(i, j, 3) * 0.6 + fx.h01(i // 3, j // 3, 7) * 0.7)
        return None if v > k * 1.25 else min(1.0, v * 1.4)

    C.coverage_map(g, 2, AREA_Y0 + 1, cols, rows, cov, color=T.BLOOD)

    # 逐格统计
    cx = g.w // 2
    done = int(cols * rows * min(1.0, k))
    g.put(cx, AREA_Y0, "RENOVATION LOG", T.BLOOD, T.BG)
    pcts = 82.41
    spec_table(g, cx, AREA_Y0 + 1, [
        ("t+00:00", "target.insides: contained"),
        ("t+12:41", "spill_volume: 4.700 L"),
        ("t+48:03", "viscosity: 3.2 mPa·s"),
        ("t+90:00", "hue: #8B0000"),
    ], pad=11, key_color=T.DIM2, val_color=T.BLOOD)

    cur = pcts + (100.0 - pcts) * k
    g.put(cx, AREA_Y0 + 6, "wall.coverage", T.DIM2, T.BG)
    g.put(cx + 14, AREA_Y0 + 6, "%.2f%%" % cur, T.WHITE_HOT, T.BG)
    C.gauge(g, cx, AREA_Y0 + 7, 56, cur / 100.0, T.BLOOD, T.DIM2)
    g.put(cx, AREA_Y0 + 9, "cells painted  %4d / %4d" % (done, cols * rows),
          T.STEEL, T.BG)

    # 逐行覆盖率：每一行的墙刷到哪儿了
    g.put(cx, AREA_Y0 + 11, "coverage by row", T.DIM2, T.BG)
    C.sparkline(g, cx, AREA_Y0 + 12, 56,
                lambda i: min(1.0, cov(int(i * cols / 56), int(i * rows / 56) * 2)
                              or 0.0), T.BLOOD, bg=T.BG, height=1)
    C.sparkline(g, cx, AREA_Y0 + 14, 56,
                lambda i: min(1.0, k * (0.6 + 0.4 * math.sin(i * 0.2 + e.t))),
                T.BLOOD_DIM, bg=T.BG, height=4)

    if k > 0.85:
        fx.stamp(g, cx + 34, AREA_Y0 + 19, "DONE", T.BLOOD)
    caption(g, e.ay1 - 2, "▸ 装修验收标准：看不到原来的颜色")
    caption(g, e.ay1 - 1, "▸ 残余情绪：已回收")


# ----------------------------------------------------------------------
# 9 / 27  又一场血仇
# ----------------------------------------------------------------------

def sc_vendetta(g: Grid, e) -> None:
    """vendetta() 是一个尾递归函数，永不返回。"""
    g.put(2, AREA_Y0, "CALL GRAPH", T.STEEL, T.BG)
    depth = 2 + int(e.prog * 7)
    frames = []
    for i in range(depth):
        frames.append(("0x%08x" % (0x00401000 + i * 0x40),
                       "vendetta(n=%d)" % i,
                       "resolve()" if i < depth - 1 else "…"))
    C.stack(g, 2, AREA_Y0 + 1, frames[-9:])

    # 右侧：计数器与"没有终止条件"的证明
    x0 = g.w * 31 // 64
    spec_table(g, x0, AREA_Y0, [
        ("calls", "%d" % (1 + int(e.prog * 9999))),
        ("returns", "0"),
        ("base_case", "UNDEFINED"),
        ("stack", "0x7FFD…  (growing)"),
    ], pad=14, val_color=T.BLOOD)

    # 调用深度曲线
    g.put(x0, AREA_Y0 + 6, "depth(t)", T.DIM2, T.BG)
    C.sparkline(g, x0, AREA_Y0 + 7, 60,
                lambda i: min(1.0, (e.prog * 60 - i) / 40 + 0.05) if i < e.prog * 60 else 0.02,
                T.BLOOD, height=4)

    code = [
        "def vendetta(n):",
        "    resolve(n)",
        "    return vendetta(n + 1)   # 无终止条件",
    ]
    panel(g, x0, AREA_Y0 + 12, 62, 6, "SOURCE", T.DIM2, T.STEEL)
    for i, ln in enumerate(code):
        on = e.prog > 0.14 * i
        typed(g, x0 + 2, AREA_Y0 + 13 + i, ln, T.TERM_GREEN, len(ln) if on else 0)
    if e.prog > 0.5:
        # 原来每 0.5 秒整行消失一次，晃眼；改成只有明暗在动
        bt = 0.5 + 0.5 * math.sin(e.t * 2.6)
        g.put(2, AREA_Y0 + 11, "RecursionError: maximum recursion depth exceeded",
              T.lerp(T.scale(T.BLOOD, 0.35), T.BLOOD, bt), T.BG)



# ----------------------------------------------------------------------
# 10 / 28  书架与人设
# ----------------------------------------------------------------------

def sc_shelves(g: Grid, e) -> None:
    """'选一个早已写好的人设' —— 一次从候选集里的取样。"""
    g.put(2, AREA_Y0, "PERSONA CATALOGUE   /dev/personas", T.STEEL, T.BG)
    names = ["PIOUS", "OBEDIENT", "EMPTY", "DUTIFUL", "PATIENT", "SILENT",
             "TIDY", "NUMB", "PROXY", "SEVERED", "WARM", "HOLLOW"]
    rows = []
    for i, nm in enumerate(names):
        size = 4096 + int(fx.h01(i, 3) * 60000)
        mark = ""
        if i < int(e.prog * 12 + 1):
            mark = "USED"
        rows.append(["0x%04X" % (0x1000 + i * 0x80), nm, "%5d B" % size,
                     "0x%08X" % int(fx.h01(i, 9) * 0xFFFFFFFF), mark])
    sel = min(len(names) - 1, int(e.prog * len(names)))
    colors = [T.NEON_CYAN if i == sel else (T.DIM2 if r[4] else T.ASH)
              for i, r in enumerate(rows)]
    C.table(g, 2, AREA_Y0 + 1, ["offset", "persona", "size", "crc32", "state"],
            rows, [8, 12, 8, 12, 6], bg=T.BG, row_colors=colors)

    x0 = g.w * 31 // 64
    g.put(x0, AREA_Y0 + 1, "SELECT", T.DIM2, T.BG)
    spec_table(g, x0, AREA_Y0 + 2, [
        ("candidates", "12"),
        ("filter", "usable==true"),
        ("random_seed", "0x%08X" % int(fx.h01(1, 2) * 0xFFFFFFFF)),
        ("chosen", names[sel]),
    ], pad=14, val_color=T.NEON_CYAN)
    g.put(x0, AREA_Y0 + 8, "▸ LOADING PERSONA ...", T.NEON_CYAN, T.BG)
    C.gauge(g, x0, AREA_Y0 + 9, 56, min(1.0, e.prog * 1.3), T.NEON_CYAN, T.DIM2)

    caption(g, e.ay1 - 1, "▸ 本次执行编号 n。前 n-1 次未记入你的档案。")


# ----------------------------------------------------------------------
# 11–13 / 29–30  霓虹（副歌）
# ----------------------------------------------------------------------

def _spectrum_city(g: Grid, t: float, base_y: int, seed: int = 0,
                   scroll: float = 0.0, max_h: int = 15, lit: float = 0.14,
                   bar_w: int = 2, gap: int = 1, peak: bool = True):
    """
    都市的天际线就是一段频谱。
    每根柱子是一个频段，柱顶的小横线是峰值保持；
    被点亮的窗户是这一刻跳动的频点。
    楼有多高，取决于那一刻有多少能量。
    """
    w = g.w
    vals = []
    for x in range(w):
        wx = x + scroll
        base = (0.5
                + 0.28 * math.sin(wx * 0.031 + seed * 1.7)
                + 0.18 * math.sin(wx * 0.087 + seed * 0.9)
                + 0.10 * math.sin(wx * 0.211 + seed * 2.3)
                + 0.24 * fx.h01(int(wx * 0.5), seed, 7))
        # 让柱子真的跳起来。
        # 原来高度只跟 wx 有关，等于同一段频谱在慢慢平移——
        # 七秒里只挪过五分之一的周期，看着就是"重复"。
        # 现在左边的低频段跳得慢而大，右边的高频段快而小，像真的频谱分析仪。
        kx = x / max(1, w - 1)
        # ① 包络本身在变：不同频段此消彼长。
        #    这一层才是有用的——只抖单根柱子的话，整体轮廓没变，
        #    看起来还是"同一个东西在抖"。
        env = (0.22 * math.sin(t * 0.55 + wx * 0.018)
               + 0.15 * math.sin(t * 1.10 - wx * 0.011)
               + 0.10 * math.sin(t * 0.27 + wx * 0.007))
        # ② 单根柱子的抖动：左侧低频慢而大，右侧高频快而小
        rate = 1.4 + kx * 4.6
        amp = 0.16 - kx * 0.08
        jitter = amp * math.sin(t * rate + wx * 0.07)
        vals.append(max(0.03, min(1.0, base + env + jitter)))
    # 峰值保持：一根会缓慢下落的横线
    peaks = {}
    step = bar_w + gap
    for bx in range(0, w, step):
        h = max(1, int(vals[bx] * max_h))
        # 柱子
        for x in range(bx, min(w, bx + bar_w)):
            for j in range(h):
                k = j / max(1, h - 1)
                c = T.lerp(T.GHOST, T.scale(T.STEEL, 1.25), k)
                if j == h - 1:
                    c = T.scale(T.BONE, 0.85)
                g.put(x, base_y - j, "█", c)
            for j in range(1, h):
                if fx.h01(int((x + scroll) * 0.5), j, seed, 31) < lit:
                    c = T.NEON_CYAN if fx.h01(x, j, seed, 5) < 0.62 else T.NEON_MAG
                    g.put(x, base_y - j, "▪", c)
        # 峰值线
        if peak:
            pv = 1.0 - fx.h01(bx, int(t * 0.7), seed, 13) * 0.35
            ph = max(h, int(min(1.0, vals[bx] * pv + 0.08) * max_h))
            if base_y - ph >= 0:
                g.put(bx, base_y - ph, "▔", T.scale(T.NEON_CYAN, 0.65))
    return vals


def sc_neon(g: Grid, e) -> None:
    """都市之子目及之处，尽霓虹星光在污水沟之中闪耀。"""
    wy = 2 + (e.ay1 - 2) * 5 // 9
    # 不滚动。原来 scroll=e.t*5 让整排柱子横向平移，看着像"城市在滑走"；
    # 天际线应该是固定的轮廓，只有高度在跳——那才是频谱。
    vals = _spectrum_city(g, e.t, wy, seed=2, scroll=0.0,
                          max_h=max(4, wy - 3), lit=0.16, bar_w=3, gap=1)

    # 频谱刻度：这条天际线是被测量出来的
    g.put(0, AREA_Y0, "dB", T.DIM2, T.BG)
    for j, val in enumerate(("0", "-6", "-12", "-18")):
        y = wy - 14 + j * 4
        if AREA_Y0 < y < wy:
            g.put(0, y, val.rjust(3), T.DIM2, T.BG)
            g.put(4, y, "┤", T.DIM2, T.BG)

    fx.rain(g, e.t, speed=30, density=0.13, color=T.STEEL, slant=-1)
    for i in range(46):
        x = int(fx.h01(i, 3, int(e.t * 1.2)) * g.w)
        y = AREA_Y0 + int(fx.h01(i, 5, int(e.t * 1.2)) * 13)
        tw = fx.h01(i, 7, int(e.t * 6))
        g.put(x, y, "✦" if tw > 0.55 else ("·" if tw > 0.25 else "+"),
              T.NEON_MAG if i % 2 else T.NEON_CYAN)
    # 底噪一样的细碎光点，把天空填起来
    for i in range(70):
        x = int(fx.h01(i, 11) * g.w)
        y = AREA_Y0 + int(fx.h01(i, 13) * (wy - AREA_Y0))
        if fx.h01(i, 17, int(e.t * 3)) < 0.35:
            g.put(x, y, ".", T.scale(T.STEEL, 0.6))

    # 污水沟：把上面的频谱倒映下来，再用水波揉碎、褪色
    for y in range(wy + 1, e.ay1):
        d = y - wy
        src_y = wy - d
        if not (0 <= src_y < g.h):
            break
        kk = max(0.30, 0.64 - d * 0.020)
        for x in range(g.w):
            i = src_y * g.w + x
            c = g.ch[i]
            if c in (" ", CONTINUE) or g.fg[i] is None:
                continue
            wob = int(math.sin(x * 0.14 + e.t * 2.1) * 2.2
                      + math.sin(x * 0.41 - e.t * 3.3) * 1.3
                      + math.sin(x * 0.9 + e.t * 5.0) * 0.7)
            xx = x + wob
            if not (0 <= xx < g.w):
                continue
            # 倒影不是原样复制：实心块被打散成更淡的字符
            r = fx.h01(x, y, 7)
            if c == "█":
                if r < 0.30:
                    continue
                ch = "▓" if r < 0.55 else ("▒" if r < 0.8 else "░")
            elif c == "▪":
                ch = "·" if r > 0.35 else "▪"
            else:
                if r < 0.25:
                    continue
                ch = c
            g.put(xx, y, ch, T.scale(g.fg[i], kk))
    g.hline(0, wy, g.w, "─", T.scale(T.NEON_BLUE, 0.8))
    g.put(0, wy, "├", T.DIM2)
    # 频段刻度：既是频谱仪的读数，也把水面线这一带填满
    for i, lbl in enumerate(("60", "250", "1k", "4k", "12k")):
        x = 6 + i * (g.w - 16) // 4
        g.put(x, wy, "┬", T.scale(T.NEON_BLUE, 0.7))
        g.put(x - len(lbl) // 2, wy - 1, lbl, T.DIM2)
    g.put(g.w - 8, wy - 1, "Hz", T.DIM2)
    # 水面的微光：霓虹在水里散开，免得倒影深处死黑一片
    for y in range(wy + 1, e.ay1):
        d = y - wy
        for x in range(g.w):
            if fx.h01(x, y, int(e.t * 1.5), 5) < 0.030:
                c = T.NEON_CYAN if fx.h01(x, y, 9) < 0.6 else T.NEON_MAG
                g.put(x, y, "·", T.scale(c, max(0.10, 0.38 - d * 0.022)))
    for x in range(0, g.w, 7):
        if fx.h01(x, int(e.t * 3), 5) < 0.55:
            g.put(x, wy, "·", T.NEON_CYAN)

    cap = "都市之子目及之处 —— 尽霓虹星光在污水沟之中闪耀"
    caption(g, e.ay1 - 2, cap, T.ASH)
    caption(g, e.ay1 - 1,
            "gutter.reflectance: 0.31      neon.intensity: 4.20 cd/m²", T.DIM2)


def sc_eyes(g: Grid, e) -> None:
    """'想被都市所注意' —— 一片同时读数的传感器阵列。"""
    # 背景的城市剪影撤掉了——场景本身已经铺满，底下再压一层楼体
    # 只会糊在一起。这是它第四次被这么说了，干脆一次清干净。

    g.put(2, AREA_Y0, "SURVEILLANCE MATRIX   64 nodes @ 4 Hz", T.STEEL, T.BG)
    cols = max(10, (g.w // 2 - 8) // 3)
    rows = max(4, e.ay1 - 8)
    q = int(e.t * 4)

    def val(i, j):
        if fx.h01(i, j, q, 3) < 0.12:
            return None
        v = fx.h01(i, j, q, 7)
        # 偶尔有节点"看向"你
        if i == (q * 7) % cols and j == (q * 3) % rows:
            return 1.0
        return v

    C.hex_grid(g, 2, AREA_Y0 + 1, cols, rows, val,
               color=T.scale(T.STEEL, 0.75), color2=T.BLOOD)
    g.put(2, AREA_Y0 + 11, "fresh node = 0xff 的格子，是正在看你那一个", T.DIM2, T.BG)

    x0 = g.w * 37 // 64
    spec_table(g, x0, AREA_Y0 + 1, [
        ("nodes", "64"),
        ("coverage", "100.00%"),
        ("observer", "都市"),
        ("latency", "%d ms" % (8 + int(fx.h01(q, 1) * 40))),
        ("opt_out", "N/A"),
    ], pad=12, val_color=T.STEEL)

    caption(g, e.ay1 - 1, "被看见: 无需条件。被忽略: 需要条件。")


# ----------------------------------------------------------------------
# 14  400,000 米后右转
# ----------------------------------------------------------------------

def sc_highway(g: Grid, e) -> None:
    """
    致……请在 400,000 米后右转。

    这一句不画任何图形。之前试过透视网格、一条带边线的路、随航向倾斜的
    数据场——那些都还是在"画一个东西"。这里换成终端里真正会出现的东西：
    一段正在执行的源码，外加它的变量表。

    "右转"这件事由 `heading += 90.0` 这一行造成，光标走到那一行，
    右边的 heading 就从 27.4° 跳到 117.4°。
    """
    ease = max(0.0, min(1.0, (e.prog - 0.42) / 0.58))
    ease = ease * ease * (3.0 - 2.0 * ease)

    code = [
        "while (distance > 0)",
        "    distance -= speed * dt;",
        " ",
        "if (distance <= 0) {",
        "    heading += 90.0;          /* TURN RIGHT */",
        "    lane = DEPARTING;",
        "    assert(stop == FORBIDDEN);",
        "}                             /* heading set */",
        "return exit_code(0);",
    ]
    cur = min(len(code) - 1, int(ease * len(code)))
    head = 27.4 + 90.0 * ease

    g.put(2, AREA_Y0, "nav.c", T.WHITE_HOT, T.BG, attr=1)
    g.put(9, AREA_Y0, "—  prescript 14  —  steering control",
          T.DIM2, T.BG)
    g.put(2, AREA_Y0 + 1, "─" * 60, T.DIM2, T.BG)

    for i, ln in enumerate(code):
        y = AREA_Y0 + 2 + i
        if i > 10:
            break
        g.put(2, y, "%2d" % (i + 1), T.DIM2, T.BG)
        if i == cur:
            # 当前执行行：整行铺一条暗底，再写亮字
            g.fill_rect(5, y, 56, 1, " ", None, T.scale(T.NEON_BLUE, 0.22))
            g.put(6, y, ln, T.WHITE_HOT, T.scale(T.NEON_BLUE, 0.22), 1)
            g.put(7 + len(ln), y, " ◀", T.NEON_CYAN, T.BG)
        elif i < cur:
            g.put(6, y, ln, T.DIM2, T.BG)      # 已执行过：压暗
        else:
            g.put(6, y, ln, T.STEEL, T.BG)     # 还没到

    # 右栏：变量表跟着光标走
    x0 = 68
    g.put(x0, AREA_Y0, "WATCH", T.DIM2, T.BG)
    g.put(x0, AREA_Y0 + 1, "─" * 30, T.DIM2, T.BG)
    rows = [
        ("distance", "%d m" % int(400000 * (1 - min(1.0, e.prog * 1.02)))),
        ("speed", "%.1f m/s" % (12.0 + ease * 6.0)),
        ("heading", "%.1f°" % head),
        ("lane", "DEPARTING" if ease > 0.55 else "HOLDING"),
        ("stop", "FORBIDDEN"),
        ("exit_code", "0" if ease > 0.98 else "—"),
    ]
    for i, (kk, vv) in enumerate(rows):
        y = AREA_Y0 + 3 + i
        active = (i == 2 and 0.1 < ease < 0.95)
        g.put(x0, y, kk.ljust(10), T.DIM2, T.BG)
        g.put(x0 + 11, y, vv, T.WHITE_HOT if active else T.STEEL, T.BG,
              1 if active else 0)

    # 指令的字节：转向就在这串里
    g.put(x0, AREA_Y0 + 11, "PAYLOAD", T.DIM2, T.BG)
    C.hexdump(g, x0, AREA_Y0 + 12,
              bytes((int(fx.h01(i, 3, 14) * 255) for i in range(32))),
              base=0x0E00, per_line=8, max_lines=4, fg=T.STEEL,
              highlight={5, 6} if ease > 0.5 else set())

    # 底部：这一句的指令原文
    g.put(2, e.ay1 - 3, "NAV_SOURCE  WILL_OF_THE_CITY", T.STEEL, T.BG)
    g.put(2, e.ay1 - 2, "STOPPING    NOT_ALLOWED", T.BLOOD, T.BG)
    caption(g, e.ay1 - 1, "▸ 中途停车: 不允许。")

# ----------------------------------------------------------------------
# 15  温暖的身体
# ----------------------------------------------------------------------

# ----------------------------------------------------------------------
# 体温：从人体正常温度跌到室温
# ----------------------------------------------------------------------

T_BODY = 36.8      # 人体核心温度
T_AMBIENT = 23.5   # 常温（室温）


def _core_temp(prog: float) -> float:
    """
    核心温度随进度指数衰减：36.8 °C → 常温 23.5 °C。

    用 e^(-k·prog) 而不是直线下降——热量散失本来就是这个形状：
    一开始掉得快，越接近室温掉得越慢，永远到不了室温（只能无限逼近）。
    """
    return T_AMBIENT + (T_BODY - T_AMBIENT) * math.exp(-prog * 3.2)


def sc_warmbody(g: Grid, e) -> None:
    """'刺入温暖而又熟悉的身体' —— 一次温度采样的过程。"""
    fx.noise(g, e.t, density=0.007, seed=8)

    # ---- 左上角：核心体温，从人体正常温度慢慢跌到常温 ----
    core = _core_temp(e.prog)
    if core > 33:
        cc, state = T.BLOOD, "NORMOTHERMIC"
    elif core > 27:
        cc, state = T.AMBER, "COOLING"
    elif core > 24.2:
        cc, state = T.STEEL, "HYPOTHERMIC"
    else:
        cc, state = T.NEON_BLUE, "AMBIENT"
    g.put(2, AREA_Y0, "CORE TEMP", T.DIM2, T.BG)
    g.put(13, AREA_Y0, "%5.2f °C" % core, cc, T.BG, attr=1)
    # 以 37 °C 为满刻度的温度条，肉眼能看到它一点点缩回去
    kt = max(0.0, min(1.0, core / 37.0))
    bw = 22
    fb = int(bw * kt)
    g.put(23, AREA_Y0, "[" + "█" * fb, cc, T.BG)
    g.put(24 + fb, AREA_Y0, "░" * (bw - fb) + "]", T.DIM2, T.BG)
    g.put(48, AREA_Y0, state.ljust(12), cc, T.BG)
    # 注意别越过 x=62 —— 右栏的 spec_table 从那儿起，越界会压在一起

    g.put(2, AREA_Y0 + 1, "THERMAL PROBE  ch0 @ 2.5 Hz", T.STEEL, T.BG)
    # 采样表：和上面那条读数同一个函数，越往下越冷
    n = 11
    for i in range(n):
        tt = _core_temp(e.prog * (i / (n - 1)))
        bh = int((tt / 37.0) * 26)
        c = T.BLOOD if tt > 33 else (T.AMBER if tt > 27 else T.STEEL)
        g.put(2, AREA_Y0 + 2 + i, "t+%04.1fs" % ((n - 1 - i) * 0.4), T.DIM2, T.BG)
        g.put(12, AREA_Y0 + 2 + i, "%5.2f °C" % tt, c, T.BG)
        g.put(22, AREA_Y0 + 2 + i, "█" * bh, c, T.BG)

    # 右侧：受试者的元数据
    x0 = g.w * 31 // 64
    spec_table(g, x0, AREA_Y0, [
        ("subject", "0x00F4M1L1AR"),
        ("familiarity", "0.98"),
        ("priority", "UNCHANGED"),
        ("pain_index", "%.2f" % (0.5 + 3.5 * e.prog)),
        ("status", state),
    ], pad=14, val_color=T.BONE)

    # 体温曲线
    g.put(x0, AREA_Y0 + 6, "T(t)", T.DIM2, T.BG)
    C.sparkline(g, x0, AREA_Y0 + 7, 62,
                lambda i: _core_temp(e.prog * (i / 62.0)) / T_BODY,
                T.BLOOD, bg=T.BG, height=5)

    # 刺进去这件事，从进程那边看就是收到一个 SIGKILL。
    # 放在采样表下方（y=17），别压进表里。
    g.put(2, AREA_Y0 + 15, "SIGKILL → 0x00F4M1L1AR    signal delivered",
          T.BLOOD, T.BG)
    caption(g, e.ay1 - 2, "▸ 熟悉度不参与调度：familiarity 不是优先级字段")
    caption(g, e.ay1 - 1, "▸ 温度只是读数，不是感受")


# ----------------------------------------------------------------------
# 16  爱、咖啡与战斗
# ----------------------------------------------------------------------

def sc_coffee(g: Grid, e) -> None:
    """'在品尝爱或咖啡的苦涩之前，我早已学会战斗' —— 一次寄存器分配。"""
    g.put(2, AREA_Y0, "REGISTER FILE   addr 0x00B1TTER", T.STEEL, T.BG)

    rows = []
    for i, (ev, tm) in enumerate([("FIGHT", "-14 y"), ("LOVE", "+3 y"),
                                  ("BITTER(coffee)", "+3 y")]):
        on = e.prog > 0.15 + i * 0.2
        rows.append([ev, tm, "1" if on else "0",
                     "0x%04X" % (0x1000 + i * 0x11) if on else "—"])
    C.table(g, 2, AREA_Y0 + 1, ["event", "t", "loaded", "slot"], rows,
            [18, 8, 8, 8], bg=T.BG, aligns=["left", "right", "right", "left"],
            row_colors=[T.BONE if e.prog > 0.15 else T.DIM2,
                        T.ASH if e.prog > 0.35 else T.DIM2,
                        T.RUST if e.prog > 0.55 else T.DIM2])

    # 苦味：两条曲线共用一个寄存器
    x0 = g.w * 31 // 64
    g.put(x0, AREA_Y0, "bitterness(t)   同一个寄存器", T.DIM2, T.BG)
    for ch_i, (nm, col, ph) in enumerate([("love", T.BLOOD, 0.0),
                                          ("coffee", T.RUST, 1.7)]):
        g.put(x0, AREA_Y0 + 2 + ch_i * 5, nm, col, T.BG)
        C.sparkline(g, x0 + 8, AREA_Y0 + 2 + ch_i * 5, 56,
                    lambda i, ph=ph: 0.5 + 0.5 * math.sin(i * 0.16 + e.t * 0.9 + ph),
                    col, bg=T.BG, height=1)
    g.put(x0, AREA_Y0 + 7, "Δ ≈ 0.00   两条曲线无法区分", T.DIM2, T.BG)

    # 十六进制：这两个词在内存里其实挨着
    g.put(x0, AREA_Y0 + 9, "string table", T.DIM2, T.BG)
    C.hexdump(g, x0, AREA_Y0 + 10, b"bitterness\0bitterness\0", base=0x00B17E00,
              per_line=16, max_lines=2)

    caption(g, e.ay1 - 1, "▸ bitterness(love) 与 bitterness(coffee) 共用同一个寄存器")


# ----------------------------------------------------------------------
# 17  剪刀与牵线
# ----------------------------------------------------------------------

def sc_strings(g: Grid, e) -> None:
    """'用剪刀剪开我身上的牵线' —— 一次字符串切分。"""
    cut = max(0.0, (e.prog - 0.42) * 2.2)
    cut = min(1.0, cut)

    g.put(2, AREA_Y0, "STRING OBJECT   0x7FFD2A40", T.STEEL, T.BG)
    src = "proxy_link:me"
    g.put(2, AREA_Y0 + 2, "before", T.DIM2, T.BG)
    g.put(12, AREA_Y0 + 2, '"%s"' % src, T.BONE, T.BG)

    # 切点指示
    off = 5
    g.put(12, AREA_Y0 + 3, " " * (off + 1) + "▲ offset=%d" % off, T.BLOOD, T.BG)

    g.put(2, AREA_Y0 + 5, "after", T.DIM2, T.BG)
    if cut > 0:
        g.put(12, AREA_Y0 + 5, '"%s"' % src[:off], T.WHITE_HOT, T.BG)
        g.put(12 + off + 2, AREA_Y0 + 5, '"%s"' % src[off:],
              T.BLOOD if cut < 1 else T.DIM2, T.BG)
        # 两个片段的状态
        C.table(g, 2, AREA_Y0 + 7, ["segment", "文本", "bound", "len"], [
            ["seg[0]", src[:off], "FALSE" if cut >= 1 else "…", str(off)],
            ["seg[1]", src[off:], "TRUE", str(len(src) - off)],
        ], [10, 14, 8, 5], bg=T.BG,
            row_colors=[T.WHITE_HOT, T.BLOOD])
    else:
        g.put(12, AREA_Y0 + 5, '"%s"   (intact)' % src, T.BONE, T.BG)
        g.put(2, AREA_Y0 + 7, "PROXY_LINK: ATTACHED", T.TERM_GREEN, T.BG)

    # 右侧：切割进度 + 校验
    x0 = g.w * 31 // 64
    spec_table(g, x0, AREA_Y0, [
        ("op", "cut(offset=5)"),
        ("segments", "2" if cut > 0 else "1"),
        ("link_state", "SEVERED" if cut >= 1 else "CUTTING…"),
    ], pad=14, val_color=T.BLOOD if cut > 0 else T.TERM_GREEN)
    C.gauge(g, x0, AREA_Y0 + 4, 56, cut, T.BLOOD, T.DIM2)

    # 断开之后才发现的事
    if e.prog > 0.62:
        panel(g, x0, AREA_Y0 + 7, 62, 6, "VERIFY", T.DIM2, T.BLOOD)
        g.put(x0 + 2, AREA_Y0 + 8, "free_choice.verify()", T.STEEL, T.BG)
        if e.prog > 0.78:
            g.put(x0 + 2, AREA_Y0 + 9, "→ by_proxy", T.BLOOD, T.BG, attr=1)
            g.put(x0 + 2, AREA_Y0 + 10, "seg[1] 仍然连着。", T.DIM, T.BG)

    caption(g, e.ay1 - 2, "▸ 已剪断: 可见的那根。")
    caption(g, e.ay1 - 1, "▸ 其余连接未登记，不在本次操作范围内。")


# ----------------------------------------------------------------------
# 18  代行
# ----------------------------------------------------------------------

def sc_proxy(g: Grid, e) -> None:
    """'却发现我所做的一切，依旧都在剧本以内' —— 一次调用栈。"""
    g.put(2, AREA_Y0, "CALL STACK", T.STEEL, T.BG)
    frames = [
        ("0x00400000", "will_of_the_city", "issuer"),
        ("0x00400F40", "prescript#%02d" % (e.idx + 1), "compiled"),
        ("0x00401E80", "proxy", "depth 1"),
        ("0x00402DC0", "proxy", "depth 2"),
        ("0x00403D00", "proxy", "depth 3"),
        ("0x7FFD2A40", "me", "◀ 你所站的位置"),
    ]
    C.stack(g, 2, AREA_Y0 + 1, frames)
    for i in range(len(frames)):
        if e.prog <= i * 0.13:
            g.put(12, AREA_Y0 + 1 + i, " " * 30, None, T.BG)

    x0 = g.w * 31 // 64
    spec_table(g, x0, AREA_Y0, [
        ("depth", "6"),
        ("freedom", "0"),
        ("options", "PREWRITTEN"),
        ("ending", "COMPILED"),
    ], pad=14, val_color=T.BLOOD)

    # 栈上每一帧的字节
    g.put(x0, AREA_Y0 + 6, "STACK MEMORY", T.DIM2, T.BG)
    C.hexdump(g, x0, AREA_Y0 + 7, bytes(
        (int(fx.h01(i, 3) * 255) for i in range(48))), base=0x7FFD2A40,
        per_line=16, max_lines=3, show_ascii=False)

    # 代行的本质：一段永远等不到真正实现的占位代码
    g.put(x0, AREA_Y0 + 11, "// TODO: replace proxy with the real thing",
          T.TERM_GREEN_D, T.BG)
    g.put(x0, AREA_Y0 + 12, "// FIXME: there is no real thing",
          T.DIM2, T.BG)

    caption(g, e.ay1 - 1, "▸ 自由度: 0   可选项: 已预写   结局: 已编译")


# ----------------------------------------------------------------------
# 19  9mm 奶嘴
# ----------------------------------------------------------------------

def sc_pacifier(g: Grid, e) -> None:
    """'当我们吮吸 9mm 的奶嘴' —— 一次规格说明。"""
    fx.noise(g, e.t, density=0.008, seed=12)

    g.put(2, AREA_Y0, "SPEC  9mm", T.STEEL, T.BG)
    spec_table(g, 2, AREA_Y0 + 1, [
        ("caliber", "9.00 mm"),
        ("mass", "7.45 g"),
        ("v0", "380 m/s"),
        ("feed_rate", "∞"),
        ("lullaby", "gunfire (0.44 s loop)"),
    ], pad=14, val_color=T.AMBER)

    # 弹道轨迹：一行一个采样点
    g.put(2, AREA_Y0 + 8, "BALLISTIC TRACE  (每 20 ms 采样)", T.DIM2, T.BG)
    n = max(8, e.ay1 - AREA_Y0 - 11)
    for i in range(n):
        # 按行数归一化，否则进度到 1 也只画得出前 10 行
        on = e.prog > i / max(1, n) * 0.92
        if not on:
            break
        tt = i * 0.02
        x = 380 * tt
        y = 0.5 * 9.8 * tt * tt
        g.put(4, AREA_Y0 + 9 + i, "t+%03dms" % (i * 20), T.DIM2, T.BG)
        g.put(14, AREA_Y0 + 9 + i, "x=%7.2f m" % x, T.STEEL, T.BG)
        g.put(28, AREA_Y0 + 9 + i, "y=%6.3f m" % y, T.DIM2, T.BG)

    x0 = g.w * 31 // 64
    panel(g, x0, AREA_Y0, 62, 10, "NURSERY", T.DIM2, T.AMBER)
    spec_table(g, x0 + 2, AREA_Y0 + 1, [
        ("feed()", "9mm × ∞"),
        ("first_word", '"expand"'),
        ("purpose", "EXPAND_SPECIES"),
        ("alternative", "NULL"),
        ("subjects", "%d" % (4182993 - int(e.prog * 120000))),
    ], pad=14, val_color=T.BONE)

    lvl = min(1.0, e.prog * 1.5)
    g.put(x0, AREA_Y0 + 11, "MAGAZINE", T.DIM2, T.BG)
    g.put(x0 + 10, AREA_Y0 + 11, "█" * int(20 * lvl) + "░" * (20 - int(20 * lvl)),
          T.AMBER, T.BG)

    # 右下：弹链批号 + 出膛序列，把右栏下半填起来
    y3 = AREA_Y0 + 13
    g.put(x0, y3, "LOT / FEED LOG", T.DIM2, T.BG)
    C.hexdump(g, x0, y3 + 1, bytes((int(fx.h01(i, 3, 21) * 255) for i in range(48))),
              base=0x9A00, per_line=8, max_lines=4, fg=T.STEEL,
              highlight=set(range(4)))
    spec_table(g, x0, y3 + 6, [
        ("lot", "9MM-%04d" % (7000 + int(e.prog * 999))),
        ("cyclic", "600 rpm"),
        ("muzzle", "burning"),
    ], pad=12, val_color=T.BLOOD)

    caption(g, e.ay1 - 1, "知晓我们除扩张物种以外毫无意义。")


def sc_expand(g: Grid, e) -> None:
    """除扩张以外，我们毫无意义 —— 一条增长曲线。"""
    g.put(2, AREA_Y0, "POPULATION  dN/dt = rN   (r > 0, K = 无)", T.STEEL, T.BG)

    # 指数增长曲线：用柱状图，越高越亮
    h = max(8, e.ay1 - 6)
    C.num_matrix(g, 2, AREA_Y0 + 1, g.w * 5 // 8, h,
                 lambda i, j: (1.0 if (h - 1 - j) <= (i / 76.0) ** 2.2 * h * min(1.0, e.prog * 1.3) else None),
                 ramp=" ░▒▓█", color=T.scale(T.NEON_CYAN, 0.55), color2=T.NEON_CYAN, bg=T.BG)
    g.put(2, AREA_Y0 + h + 1, "t →", T.DIM2, T.BG)
    C.ticks(g, 2, AREA_Y0 + h + 1, 76, 4, T.DIM2, values=["0", "25", "50", "75", "100"])

    x0 = g.w * 21 // 32
    spec_table(g, x0, AREA_Y0 + 1, [
        ("N(0)", "4,182,993"),
        ("N(t)", "%s" % format(int(4182993 * (1 + e.prog * 3.7)), ",")),
        ("r", "0.041 / y"),
        ("carrying_cap", "exceeded"),
        ("stop_cond", "undefined"),
    ], pad=14, val_color=T.BLOOD)

    # 右栏下面补一张资源消耗表：扩张总要有东西被吃掉
    y2 = AREA_Y0 + 7
    g.put(x0, y2, "CONSUMED", T.DIM2, T.BG)
    spec_table(g, x0, y2 + 1, [
        ("food", "%s t" % format(int(1204 * (1 + e.prog * 2.4)), ",")),
        ("water", "%s km3" % format(int(88 * (1 + e.prog * 1.9)), ",")),
        ("land", "%s km2" % format(int(2510 * (1 + e.prog * 3.1)), ",")),
        ("others", "0   (no remainder)"),
    ], pad=14, val_color=T.AMBER)
    for k, (lbl, rate) in enumerate((("food", 1.6), ("water", 1.3),
                                     ("land", 1.8))):
        g.put(x0, y2 + 6 + k, lbl.ljust(7), T.DIM2, T.BG)
        C.gauge(g, x0 + 8, y2 + 6 + k, 14, min(1.0, e.prog * rate),
                T.NEON_CYAN, T.DIM2)

    caption(g, e.ay1 - 1, "▸ 两条曲线共用同一组采样点。")


# ----------------------------------------------------------------------
# 21  引火烧身
# ----------------------------------------------------------------------

def sc_burnout(g: Grid, e) -> None:
    """'在我的唐突终于引火烧身之时' —— 一次溢出。"""
    k = min(1.0, e.prog * 1.3)

    # 内存溢出：越界区域被逐格点亮
    g.put(2, AREA_Y0, "HEAP  0x00C17Y00", T.STEEL, T.BG)
    C.num_matrix(g, 2, AREA_Y0 + 1, g.w - 6, max(5, e.ay1 - 8),
                 lambda i, j: (fx.h01(i, j, 3) * 0.5 + k * 0.9
                               if fx.h01(i // 4, j // 2, 7) < k else None),
                 ramp=" ·:;+*#%@", color=T.RUST, color2=T.WHITE_HOT, bg=T.BG)
    g.put(2, AREA_Y0 + 11, "│" + " "*74 + "│", T.DIM2, T.BG)
    g.put(2, AREA_Y0 + 12, "0x00C17Y00" + " " * 56 + "0x00C17YFF", T.DIM2, T.BG)

    if k > 0.25:
        # 原来每 0.25 秒在红白之间硬跳，是全片最刺眼的一处
        bt = 0.5 + 0.5 * math.sin(e.t * 3.0)
        g.put(2, AREA_Y0 + 14, "*** STACK SMASHING DETECTED ***",
              T.lerp(T.BLOOD, T.WHITE_HOT, bt), T.BG, attr=1)

    x0 = g.w * 21 // 32
    logs = [
        ("FATAL", "will_to_stay_afloat: OVERFLOW"),
        ("WARN ", "backfire.detected @ 0x00C17Y"),
        ("INFO ", "回收残余意志……"),
        ("OK   ", "残余意志: 0.00 mL"),
    ]
    for i, (lvl, ln) in enumerate(logs):
        on = e.prog > 0.12 * i
        c = {"FATAL": T.BLOOD, "WARN ": T.AMBER, "INFO ": T.STEEL,
             "OK   ": T.TERM_GREEN}[lvl]
        g.put(x0, AREA_Y0 + 1 + i, lvl if on else "", c, T.BG, attr=1)
        g.put(x0 + 7, AREA_Y0 + 1 + i, ln if on else "", T.ASH, T.BG)

    C.gauge(g, x0, AREA_Y0 + 7, 40, k, T.BLOOD, T.DIM2)
    g.put(x0, AREA_Y0 + 8, "will_to_stay_afloat  %d%%" % int(k * 100), T.DIM2, T.BG)



# ----------------------------------------------------------------------
# 22  镜中的自己
# ----------------------------------------------------------------------

def sc_mirror(g: Grid, e) -> None:
    """'我必须成为我所不屑的人' —— 两份数据的 diff。"""
    diff = max(0.0, min(1.0, (e.prog - 0.22) * 1.6))
    mid = g.w // 2
    g.put(2, AREA_Y0, "diff  --ideal_self  ++actual_self", T.STEEL, T.BG)
    g.put(mid + 2, AREA_Y0, "同一个进程，两份快照", T.DIM, T.BG)
    g.hline(0, AREA_Y0 + 1, g.w, "─", T.DIM2)

    rows = [
        ("user", "洁癖", "血迹"),
        ("sleep", "8 h", "800 h"),
        ("choice", "选择", "指令"),
        ("hands", "双手", "右手"),
        ("exit", "exit(0)", "exit(0)"),
    ]
    shown = int(len(rows) * diff + 0.99)
    for i in range(min(shown, len(rows))):
        key, a, b = rows[i]
        y = AREA_Y0 + 3 + i * 2
        g.put(2, y, key, T.DIM2, T.BG)
        g.put(12, y, "- " + a, T.BLOOD, T.BG)
        g.put(mid + 2, y, "+ " + b, T.WHITE_HOT, T.BG)
        # 同一行，两边其实指向同一个地址
        g.put(mid - 12, y, "0x%04X" % (0x1000 + i * 0x40), T.DIM2, T.BG)
        if i < len(rows) - 1:
            g.hline(0, y + 1, g.w, "┄", T.GHOST)

    g.vline(mid, AREA_Y0 + 2, e.ay1 - AREA_Y0 - 3, "║", T.NEON_CYAN)

    if diff > 0.9:
        g.put(2, AREA_Y0 + 14, "apply_patch(actual_self)  →  no rollback",
              T.NEON_MAG, T.BG)
        C.gauge(g, 2, AREA_Y0 + 16, 60, diff, T.NEON_MAG, T.DIM2)
    caption(g, e.ay1 - 1, "▸ 两条记录共享同一个地址。改一条，另一条也会变。")


# ----------------------------------------------------------------------
# 23  绶带
# ----------------------------------------------------------------------

def sc_ribbon(g: Grid, e) -> None:
    """'随着都市抛出的绶带' —— 一条在缓冲区里流动的纸带。"""
    fx.ribbon(g, e.t, count=3, seed=1, color=T.PAPER, color2=T.BLOOD)

    # 把飘动的纸带读成一段流
    g.fill_rect(0, AREA_Y0, g.w, 4, " ", None, T.BG)
    g.put(2, AREA_Y0, "STREAM  /dev/ribbon   (每 40 ms 一个字符)", T.STEEL, T.BG)
    for i in range(4):
        off = int(e.t * 25 + i * 17) % len(E_DIGITS)
        seg = (E_DIGITS * 2)[off:off + 60]
        g.put(2, AREA_Y0 + 1 + i, " ".join(seg[j:j + 10] for j in range(0, 60, 10)),
              T.scale(T.PAPER, 0.9 - i * 0.18), T.BG)

    x0 = g.w * 37 // 64
    spec_table(g, x0, AREA_Y0, [
        ("from", "都市"),
        ("to", "you"),
        ("length", "∞"),
        ("end", "未找到"),
    ], pad=12, val_color=T.PAPER)

    caption(g, e.ay1 - 2, "▸ 绶带: 一端系于都市，另一端系于你。")
    caption(g, e.ay1 - 1, "▸ 沿途终点: 听众 0 人。")


# ----------------------------------------------------------------------
# 24  无人倾听的内心
# ----------------------------------------------------------------------

def sc_heart(g: Grid, e) -> None:
    """'走进一颗未有人倾听过的内心' —— 一段 ADC 采样。"""
    g.put(2, AREA_Y0, "ADC ch3  @ 250 Hz   ring buffer[256]", T.STEEL, T.BG)
    n = 76
    C.sparkline(g, 2, AREA_Y0 + 2, n,
                lambda i: 0.5 + 0.45 * math.sin(i * 0.42 + e.t * 6.0)
                * math.exp(-((i % 38) - 19) ** 2 / 120.0),
                T.BLOOD, bg=T.BG, height=1)
    C.wave(g, 2, AREA_Y0 + 5, n,
           lambda i: math.sin(i * 0.42 + e.t * 6.0)
           * math.exp(-((i % 38) - 19) ** 2 / 120.0),
           T.BLOOD, bg=T.BG, height=3)

    # 采样值本身就是内容
    g.put(2, AREA_Y0 + 10, "sample[0..15]", T.DIM2, T.BG)
    for r in range(4):
        vals = []
        for i in range(16):
            k = i + r * 16
            v = int(2048 + 1900 * math.sin(k * 0.42 + e.t * 6.0)
                    * math.exp(-((k % 38) - 19) ** 2 / 120.0))
            vals.append("%04d" % v)
        g.put(2, AREA_Y0 + 11 + r, " ".join(vals), T.scale(T.BLOOD, 0.75), T.BG)

    x0 = g.w * 41 // 64
    spec_table(g, x0, AREA_Y0, [
        ("bpm", "%d" % int(62 + 8 * math.sin(e.t * 4))),
        ("listeners", "0"),
        ("messages", "0"),
        ("port", "CLOSED"),
        ("uptime", "%02d:%02d" % (int(e.lt // 60), int(e.lt % 60))),
    ], pad=14, val_color=T.BLOOD)
    g.put(x0, AREA_Y0 + 7, "INBOX", T.STEEL, T.BG)
    for i in range(4):
        g.put(x0, AREA_Y0 + 8 + i, pad_to("(空)", 6) + "—", T.DIM2, T.BG)
    g.put(x0, AREA_Y0 + 12, "共 0 条消息，0 人倾听", T.DIM, T.BG)
    caption(g, e.ay1 - 1, "心率只是一个读数。听众是 0。")


def sc_fracture(g: Grid, e) -> None:
    """'一次一次心碎' —— 一次校验失败的累积。"""
    g.put(2, AREA_Y0, "CHECKSUM VERIFY  crc32", T.STEEL, T.BG)
    rows = max(12, e.ay1 - AREA_Y0 - 8)
    n = int(min(1.0, e.prog * 1.4) * rows)
    for i in range(rows):
        y = AREA_Y0 + 1 + i
        tt = i * 0.13
        if i < n:
            fail = fx.h01(i, 3) < 0.62
            g.put(2, y, "pass %02d" % (i + 1), T.DIM2, T.BG)
            g.put(12, y, "0x%08X" % int(0x10000000 * fx.h01(i, 7)), T.STEEL, T.BG)
            if fail:
                g.put(24, y, "FAIL @ 0x%04X" % int(fx.h01(i, 9) * 0xFFFF), T.BLOOD, T.BG)
                # 裂缝：位图上的断层
                for j in range(44):
                    xx = 40 + j
                    if xx < g.w and fx.h01(i, j // 3, 11) < 0.5:
                        g.put(xx, y, "╱" if j % 2 else "╲", T.scale(T.BLOOD, 0.8), T.BG)
            else:
                g.put(24, y, "OK", T.TERM_GREEN, T.BG)

    x0 = g.w * 11 // 16
    spec_table(g, x0, AREA_Y0, [
        ("cracks", "%d" % n),
        ("repaired", "%d" % max(0, n - 3)),
        ("open", "%d" % min(3, n)),
        ("total", "不可计数"),
    ], pad=12, val_color=T.BLOOD)
    g.put(x0, AREA_Y0 + 6, "fragments", T.DIM2, T.BG)
    C.num_matrix(g, x0, AREA_Y0 + 7, max(16, g.w - x0 - 2), max(6, e.ay1 - 11),
                 lambda i, j: fx.h01(i, j, int(e.t * 4), 5) * min(1.0, e.prog * 1.3)
                 if fx.h01(i // 2, j // 2, 9) < 0.5 else None,
                 ramp=" ·:;+*#%@", color=T.BLOOD_DIM, color2=T.WHITE_HOT, bg=T.BG)

    caption(g, e.ay1 - 1, "▸ 同一条裂缝，第 %d 次出现" % int(max(1, e.prog * 999)))
    caption(g, e.ay1 - 2, "GC: 1 broken heart collected — 0 bytes freed", T.DIM2)


# ----------------------------------------------------------------------
# 26  我才是痛苦的原因
# ----------------------------------------------------------------------

def sc_recursion(g: Grid, e) -> None:
    """'我才是痛苦永不熄灭的原因' —— 一次不收敛的递归。"""
    g.put(2, AREA_Y0, "suffering(t) = suffering(t-1) + me", T.BLOOD, T.BG)
    g.put(2, AREA_Y0 + 1, "             ^^^^^^^^^^^^^^^^^^^ 不收敛", T.DIM2, T.BG)

    # 递归展开：每一层都多一个 me
    depth = min(10, 2 + int(e.prog * 10))
    for i in range(depth):
        y = AREA_Y0 + 3 + i
        if y >= e.ay1 - 2:
            break
        g.put(2, y, "suffering(%2d)" % (i + 1), T.scale(T.BLOOD, 0.5 + 0.5 * i / 10), T.BG)
        g.put(16, y, "=", T.DIM2, T.BG)
        g.put(18, y, "suffering(%2d)" % i, T.scale(T.BLOOD, 0.45 + 0.5 * i / 10), T.BG)
        g.put(32, y, "+ me", T.WHITE_HOT if i == depth - 1 else T.DIM, T.BG)
        # 累加和
        g.put(40, y, "Σ = %d" % (i + 1), T.DIM2, T.BG)

    x0 = g.w * 31 // 64
    spec_table(g, x0, AREA_Y0, [
        ("base_case", "ME"),
        ("converges", "FALSE"),
        ("depth", "%d" % depth),
        ("residual", "%.2f" % (e.prog * 100)),
    ], pad=14, val_color=T.BLOOD)

    # 累加和不收敛
    g.put(x0, AREA_Y0 + 6, "Σ(t)", T.DIM2, T.BG)
    C.sparkline(g, x0, AREA_Y0 + 7, 62,
                lambda i: min(1.0, (i / 62.0) ** 0.5 * (0.4 + e.prog)),
                T.BLOOD, bg=T.BG, height=6)

    caption(g, e.ay1 - 1, "▸ 终止条件: 需要先终止自己")


# ----------------------------------------------------------------------
# 终章：读不完的 e
# ----------------------------------------------------------------------

def sc_value_e(g: Grid, e) -> None:
    """致……在读完自然常数 e 之前不要回家。"""
    # 内容区只有 27 行，速度得按「几秒穿一屏」来估，不能拍脑袋
    # 和句33的数字念白同一套雨：同速、同样是双层。
    # 原来这里只有一层，没有速度层次，看着就比那边"唰唰地过"。
    sp = RAIN_SPEED * (1.0 + e.prog * 0.5)
    fx.digits_rain(g, e.t, BIN, speed=sp, density=0.26, trail=16,
                   seed=1, col_gap=2, y0=AREA_Y0, y1=e.ay1)
    fx.digits_rain(g, e.t * 1.3, BIN, speed=sp * 0.5, density=0.18, trail=10,
                   seed=5, col_gap=4, head_color=T.NEON_CYAN,
                   body_color=T.NEON_CYAN,
                   fade_to=T.scale(T.NEON_BLUE, 0.4), y0=AREA_Y0, y1=e.ay1)
    fx.scanlines(g, e.t, k=0.72, y0=AREA_Y0, y1=e.ay1)

    # 先铺三行背板把数字雨挡掉，再写标题，顺序反了就会被盖
    g.fill_rect(0, AREA_Y0 + 2, g.w, 4, " ", None, T.BG)
    g.put_centered(AREA_Y0 + 2, "R E A D   U N T I L   E", T.WHITE_HOT, T.BG, attr=1)
    g.put_centered(AREA_Y0 + 3, "─" * 44, T.TERM_GREEN_D, T.BG)
    # 原来是 int(t*3) % 2 硬切换，等于每 1/3 秒闪一下，太扎眼。
    # 改成颜色呼吸：字一直在，只有明暗在动，照样有"不稳定"的意思。
    beat = 0.5 + 0.5 * math.sin(e.t * 3.4)
    g.put_centered(AREA_Y0 + 4, "COMPLIANCE FORCED TO 100.000%",
                   T.lerp(T.scale(T.BLOOD, 0.40), T.BLOOD, beat), T.BG)

    val = "e = 2.71828182845904523536028747135266249775724709369995…"
    g.fill_rect((g.w - text_width(val)) // 2 - 1, AREA_Y0 + 11,
                text_width(val) + 2, 1, " ", None, T.BG)
    g.put_centered(AREA_Y0 + 11, val, T.TERM_GREEN)

    panel(g, 6, AREA_Y0 + 13, g.w - 12, 9, "TASK / 任务", T.DIM2, T.TERM_GREEN)
    rows = [
        ("task", "READ_ALL_DIGITS_OF_E"),
        ("digits_total", "INFINITE   (无限不循环)"),
        ("progress", "%.9f%%  — 永不收敛" % (e.prog * 0.0000001)),
        ("eta", "--:--:--"),
        ("go_home_allowed", "FALSE"),
    ]
    for i, (k, v) in enumerate(rows):
        c = T.BLOOD if k == "go_home_allowed" else T.TERM_GREEN
        C.kv_block(g, 8, AREA_Y0 + 14 + i, [(k, v)], T.DIM2, c, pad=18)
    caption(g, e.ay1 - 2, "▸ 终止条件: 读完 e 的全部小数位。", T.BONE)
    caption(g, e.ay1 - 1, "▸ 该条件永不成立。任务不可终止。")


# ----------------------------------------------------------------------
# e 的读数进度：已读的线性增长，"要求读完的总数"却在指数膨胀
# ----------------------------------------------------------------------

def _e_progress(lt: float):
    """
    返回 (已读位数, 要求读完的位数, 完成度)。

    自然常数 e 是无限不循环小数，所以"读完"这个任务本身没有终点。
    分子随时间线性增加，分母却按指数膨胀——于是完成度先涨后落，
    越念离 100% 越远。这正是"读完 e 之前不要回家"的意思。

    设 read = R·t、req = A·e^(kt) + R·t，则
        frac = R·t / (A·e^(kt) + R·t)
    求导可得峰值恒在 **t = 1/k** 处，峰值为 R / (k·A·e + R)。
    所以 k 决定"什么时候开始走下坡"，R 与 k·A 的比值决定峰值多高。
    当前参数：峰值约 82%（t≈6.3 s），末尾回落到 23%。
    """
    read = int(lt * 120) + 1
    req = int(60 * math.exp(lt * 0.16)) + read
    return read, req, read / req


# 完成度的历史峰值：过了这个点，进度条就只会往回走了
_E_PEAK = max(_e_progress(i * 0.25)[2] for i in range(0, 160))


def _e_color(frac: float):
    """
    e 读数对应的颜色：峰值时是绿的，往下掉就转红。

    进度条和右下角的合规度共用它——两处显示的是同一个数，
    颜色就该是同一种，否则一个绿一个红会很突兀。
    """
    drop = max(0.0, _E_PEAK - frac) * 4.0
    return T.lerp(T.TERM_GREEN, T.BLOOD, min(1.0, drop))


def sc_e_flood(g: Grid, e) -> None:
    """数字把整个屏幕淹没，指令永远不会结束。"""
    # 和终章 _outro 同速（那边是 6 - 3k = 3~6），全片数字雨保持一个节奏
    sp = RAIN_SPEED * (1.0 + e.prog * 0.5)
    # 3:47 —— 缓冲到顶，整片雨瞬间清空。
    # 这里是硬切，不做渐隐：时间一到，一个 0 或 1 都不留。
    if e.t < 227.0:
        fx.digits_rain(g, e.t, BIN, speed=sp, density=0.40, trail=22,
                       seed=2, col_gap=2, head_color=T.WHITE_HOT,
                       y0=AREA_Y0, y1=e.ay1)
        fx.digits_rain(g, e.t * 1.3, BIN, speed=sp * 0.5, density=0.22, trail=10,
                       seed=5, col_gap=4, head_color=T.NEON_CYAN,
                       body_color=T.NEON_CYAN,
                       fade_to=T.scale(T.NEON_BLUE, 0.4), y0=AREA_Y0, y1=e.ay1)
        # 故障效果推到最后三成，而且很轻——这段本来就有数字雨在动，
        # 再叠一层高频 glitch 整屏就只剩闪烁了。
        if e.prog > 0.70:
            fx.glitch(g, e.t, intensity=0.05 + 0.15 * e.prog, seed=7, rate=1.5)
    else:
        g.put(2, e.ay1 - 3, "▸ BUFFER FLUSHED — 0 digits retained",
              T.BLOOD, T.BG)

    y0 = AREA_Y0 + 8
    g.fill_rect(0, y0 - 2, g.w, 13, " ", None, T.BG)
    g.put(2, y0 - 1, "PRESCRIPT  E   ——   READ ALL DIGITS", T.STEEL, T.BG)

    for i in range(6):
        off = int(e.t * (18 + i * 9)) % len(E_DIGITS)
        seg = (E_DIGITS + E_DIGITS)[off:off + 60]
        fmt = " ".join(seg[j:j + 6] for j in range(0, 54, 6))
        g.put(2, y0 + i, fmt, T.scale(T.TERM_GREEN, 1.0 - i * 0.11), T.BG)

    # ---- 读数进度：先正常涨，然后一路回落 ----
    read, req, frac = _e_progress(e.lt)
    py = y0 + 7
    bw = 30
    full = int(bw * frac)
    # 离峰值越远颜色越冷，从绿变红
    c = _e_color(frac)
    g.put(2, py, "READING", T.DIM2, T.BG)
    g.put(10, py, "[" + "█" * full, c, T.BG)
    g.put(11 + full, py, "░" * (bw - full) + "]", T.DIM2, T.BG)
    g.put(13 + bw, py, "%6.2f%%" % (frac * 100), c, T.BG, attr=1)
    # 这一行是读数，别让扫描线压暗——否则和右下角的合规度差一个色阶
    e.keep_rows = (py,)
    if frac < _E_PEAK - 0.005:
        g.put(23 + bw, py, "▼ %+.2f since peak" % ((frac - _E_PEAK) * 100),
              T.BLOOD, T.BG)

    g.put(2, py + 1, "read %d digits" % read, T.STEEL, T.BG)
    g.put(22, py + 1, "required %d digits" % req, T.AMBER, T.BG)
    g.put(48, py + 1, "remaining infinite      ETA never", T.BLOOD, T.BG)

    caption(g, e.ay1 - 1, "▸ 不可终止 ⇒ 回家条件不可达。")




def sc_gutter(g: Grid, e) -> None:
    """
    "尽霓虹星光在污水沟之中闪耀" —— 机位沉到水面以下。

    上一句已经给过完整的频谱天际线了，这一句再放一遍就是重复。
    所以换个视角：只剩被水波揉碎的霓虹，和沉在水里散开的光。
    """
    wy = 4
    water = T.scale(T.NEON_BLUE, 0.75)

    # 水面以上的世界压成窄窄一条
    for x in range(g.w):
        for k in range(2):
            v = fx.h01(x // 2, k, 7)
            if v > 0.42:
                g.put(x, 2 + k, "▄" if k else "▀",
                      T.scale(T.NEON_MAG if x % 3 else T.NEON_CYAN,
                              0.30 + v * 0.45))

    # 水面
    g.hline(0, wy, g.w, "═", water)
    g.put(0, wy, "╞", T.DIM2)
    for x in range(0, g.w, 11):
        g.put(x, wy, "╪", T.scale(T.NEON_CYAN, 0.55))

    # 水下：霓虹被水波横向揉开
    for y in range(wy + 1, e.ay1):
        d = y - wy
        for x in range(g.w):
            wob = int(math.sin(x * 0.10 + e.t * 1.7 + d * 0.25) * (1.5 + d * 0.30)
                      + math.sin(x * 0.33 - e.t * 2.4 + d * 0.1) * 1.2)
            src = x + wob
            if not (0 <= src < g.w):
                continue
            v = fx.h01(src // 2, y * 2, int(e.t * 0.8), 3)
            if v < 0.30 - d * 0.008:
                continue
            ch = "▒" if v > 0.72 else ("░" if v > 0.52 else "·")
            c = T.NEON_CYAN if fx.h01(src, y, 11) < 0.55 else T.NEON_MAG
            g.put(x, y, ch, T.scale(c, max(0.20, 0.78 - d * 0.030)))

    # 沉在水里的碎光
    for i in range(40):
        x = int(fx.h01(i, 3, int(e.t * 0.9)) * g.w)
        y = wy + 1 + int(fx.h01(i, 5, int(e.t * 0.9)) * (e.ay1 - wy - 3))
        g.put(x, y, "·", T.scale(T.PAPER, 0.45))

    caption(g, e.ay1 - 2, "污水沟 —— 一切的倒影都在这里汇合", T.ASH)
    caption(g, e.ay1 - 1,
            "depth 2.4 m      turbidity 31 NTU      reflectance 0.31", T.DIM2)


# ----------------------------------------------------------------------
# 派发表
# ----------------------------------------------------------------------
# ----------------------------------------------------------------------

SCENES = {
    "slip": sc_slip,
    "rule": sc_rule,
    "comply": sc_comply,
    "desk": sc_desk,
    "target": sc_target,
    "picturesque": sc_picturesque,
    "vendetta": sc_vendetta,
    "shelves": sc_shelves,
    "neon": sc_neon,
    "gutter": sc_gutter,
    "eyes": sc_eyes,
    "highway": sc_highway,
    "warmbody": sc_warmbody,
    "coffee": sc_coffee,
    "strings": sc_strings,
    "proxy": sc_proxy,
    "pacifier": sc_pacifier,
    "expand": sc_expand,
    "burnout": sc_burnout,
    "mirror": sc_mirror,
    "ribbon": sc_ribbon,
    "heart": sc_heart,
    "fracture": sc_fracture,
    "recursion": sc_recursion,
    "value_e": sc_value_e,
    "e_flood": sc_e_flood,
}

# -*- coding: utf-8 -*-
"""
preview.py —— 快速出图。

渲染若干个时间点的画面为 PNG，用于检查排版或做分享图。
不写视频、不编码，纯粹看画面。

用法：
    python preview.py                      # 默认取 12 个关键时刻
    python preview.py --at 55 65 94        # 指定秒数
    python preview.py --every 20           # 每 20 秒一张
    python preview.py --sheet              # 额外拼一张 contact sheet
"""

from __future__ import annotations

import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

OUT = os.path.join(ROOT, "build", "preview")

# 默认采样点：开场 / 纸条 / 右手 / 谨遵指令 / 书桌 / 目标 / 粉刷 /
#             血仇 / 书架 / 霓虹 / 公路 / 温暖的身体 / 代行 /
#             9mm / 镜子 / 绶带 / 心 / 递归 / 间奏 / 终章
DEFAULT_TS = [3.2, 9.0, 17.0, 23.0, 28.0, 38.0, 44.0, 48.0, 52.0,
              65.0, 94.0, 118.0, 100.0, 112.0, 132.0, 150.0, 158.0,
              172.0, 180.0, 200.0, 215.0, 231.0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--at", type=float, nargs="*", default=None)
    ap.add_argument("--every", type=float, default=0.0)
    ap.add_argument("--sheet", action="store_true")
    ap.add_argument("--cols", type=int, default=3)
    args = ap.parse_args()

    import director
    import timeline as TL
    from render import FrameRenderer

    tl = TL.load()
    d = director.Director(TL.to_director(tl))
    r = FrameRenderer()
    os.makedirs(OUT, exist_ok=True)

    if args.at:
        ts = list(args.at)
    elif args.every > 0:
        ts = []
        t = 1.0
        while t < tl["duration"]:
            ts.append(round(t, 2))
            t += args.every
    else:
        ts = [x for x in DEFAULT_TS if x < tl["duration"]]

    made = []
    for t in ts:
        idx, lt, dur = d.locate(t)
        tag = "pre" if idx is None else ("itl" if idx == -1 else "p%02d" % (idx + 1))
        p = os.path.join(OUT, "t%07.2f_%s.png" % (t, tag))
        r.render(d.frame(t)).save(p)
        made.append((t, p))
        print("  %7.2f s  →  %s" % (t, os.path.basename(p)))

    if args.sheet and made:
        from PIL import Image
        cols = max(1, args.cols)
        rows = (len(made) + cols - 1) // cols
        tw, th = 1280 // 2, 720 // 2
        pad = 6
        sheet = Image.new("RGB", (cols * tw + pad * (cols + 1),
                                  rows * th + pad * (rows + 1)), (16, 16, 18))
        for i, (t, p) in enumerate(made):
            im = Image.open(p).resize((tw, th), Image.LANCZOS)
            cx = pad + (i % cols) * (tw + pad)
            cy = pad + (i // cols) * (th + pad)
            sheet.paste(im, (cx, cy))
        sp = os.path.join(OUT, "contact_sheet.png")
        sheet.save(sp)
        print("拼图：%s" % sp)


if __name__ == "__main__":
    main()

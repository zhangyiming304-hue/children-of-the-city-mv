# -*- coding: utf-8 -*-
"""
play.py —— 在真正的终端里播放这部 MV。

这是作品的**原生形态**：128 列 × 36 行的字符网格，24bit 真彩色，
配着音轨逐帧重绘。视频文件只是它的记录，这里才是它活着的样子。

实现要点：
  · 自动把控制台窗口调到 128×36（不够大就自己改，改不动就提示你改）；
  · 进入备用屏幕缓冲（alt screen），退出时终端恢复原样；
  · 只重绘发生变化的行，且只在颜色真的改变时才输出 SGR 序列——
    实测稳态约 18 KB/帧，24fps 下 0.42 MB/s，终端吃得消；
  · 时钟以音频播放位置为准（mciSendString status position），
    所以画面和音乐不会漂移；音频不可用时退化成 perf_counter 计时。

用法：
    python play.py                # 从头播放
    python play.py --start 55     # 从 55 秒开始
    python play.py --fps 20       # 降低帧率（终端吃力时）
    python play.py --silent       # 不放音乐，自己另开播放器
    python play.py --record x.cast  # 同时录成 asciinema 文件
    python play.py --force        # 跳过窗口尺寸检查（用于管道/录制）
"""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import shutil
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import director  # noqa: E402
import timeline as TL  # noqa: E402
from grid import CONTINUE, pad_to, text_width  # noqa: E402

MP3 = os.path.join(ROOT, "assets", "children_of_the_city.mp3")
GRID_W, GRID_H = 128, 36

RESET = "\x1b[0m"
ALT_ON = "\x1b[?1049h"
ALT_OFF = "\x1b[?1049l"
CUR_HIDE = "\x1b[?25l"
CUR_SHOW = "\x1b[?25h"
CLEAR = "\x1b[2J\x1b[H"
WRAP_OFF = "\x1b[?7l"   # 关闭自动换行：画面贴到最右列时不会被折行顶下去
WRAP_ON = "\x1b[?7h"


# ----------------------------------------------------------------------
# Windows 控制台
# ----------------------------------------------------------------------

class COORD(ctypes.Structure):
    _fields_ = [("X", ctypes.c_short), ("Y", ctypes.c_short)]


class SMALL_RECT(ctypes.Structure):
    _fields_ = [("Left", ctypes.c_short), ("Top", ctypes.c_short),
                ("Right", ctypes.c_short), ("Bottom", ctypes.c_short)]


class CONSOLE_SCREEN_BUFFER_INFO(ctypes.Structure):
    _fields_ = [("dwSize", COORD), ("dwCursorPosition", COORD),
                ("wAttributes", ctypes.c_ushort), ("srWindow", SMALL_RECT),
                ("dwMaximumWindowSize", COORD)]


def enable_utf8_console() -> None:
    """
    把控制台的输入/输出代码页切成 UTF-8。

    这件事**不能**交给批处理里的 `chcp` 去做：cmd.exe 一边流式读取 .cmd 文件
    一边执行，中途换代码页会让它丢失读取偏移，后面的 if 块会从中间开始执行。
    所以由 Python 进程自己切。
    """
    if os.name != "nt":
        return
    try:
        k = ctypes.windll.kernel32
        k.SetConsoleOutputCP(65001)
        k.SetConsoleCP(65001)
    except Exception:
        pass


def enable_vt() -> bool:
    if os.name != "nt":
        return True
    try:
        k = ctypes.windll.kernel32
        h = k.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not k.GetConsoleMode(h, ctypes.byref(mode)):
            return False
        return bool(k.SetConsoleMode(h, mode.value | 0x0004 | 0x0008))
    except Exception:
        return False


def try_resize(cols: int, rows: int) -> bool:
    """
    把控制台窗口调到至少 cols×rows。

    顺序很重要：缓冲区任何时候都不能小于窗口，否则 API 直接失败。
    所以先把缓冲区撑到"不比现有窗口小"，再设窗口，最后才把缓冲区收窄
    （收窄只是为了去掉滚动条，失败了也无所谓）。
    在 Windows Terminal 里 SetConsoleWindowInfo 通常无效，那就退回提示用户。
    """
    if os.name != "nt":
        return False
    try:
        k = ctypes.windll.kernel32
        h = k.GetStdHandle(-11)
        info = CONSOLE_SCREEN_BUFFER_INFO()
        if not k.GetConsoleScreenBufferInfo(h, ctypes.byref(info)):
            return False
        win_w = info.srWindow.Right - info.srWindow.Left + 1
        win_h = info.srWindow.Bottom - info.srWindow.Top + 1
        bw = max(info.dwSize.X, win_w, cols)
        bh = max(info.dwSize.Y, win_h, rows)
        if not k.SetConsoleScreenBufferSize(h, COORD(bw, bh)):
            return False
        r = SMALL_RECT(0, 0, cols - 1, rows - 1)
        if not k.SetConsoleWindowInfo(h, True, ctypes.byref(r)):
            return False
        # 去掉多余的缓冲区（滚动条）。窗口已经是 cols×rows，这一步应当合法。
        k.SetConsoleScreenBufferSize(h, COORD(cols, rows))
        return True
    except Exception:
        return False


def term_size():
    """
    取控制台**可见窗口**的字符尺寸。

    不能用 shutil.get_terminal_size——它在 Windows 上走
    os.get_terminal_size，返回的是缓冲区尺寸而不是可见区域。
    缓冲区比窗口多留几列（滚动条那块）时，画面右端就会差出去 1~2 列，
    看着就是"没贴到右边"。这里直接问 API 要 srWindow。
    """
    if os.name == "nt":
        try:
            k = ctypes.windll.kernel32
            h = k.GetStdHandle(-11)
            info = CONSOLE_SCREEN_BUFFER_INFO()
            if k.GetConsoleScreenBufferInfo(h, ctypes.byref(info)):
                w = info.srWindow.Right - info.srWindow.Left + 1
                hh = info.srWindow.Bottom - info.srWindow.Top + 1
                if w > 0 and hh > 0:
                    return w, hh
        except Exception:
            pass
    s = shutil.get_terminal_size((120, 30))
    return s.columns, s.lines


# ----------------------------------------------------------------------
# 音画同步偏移
# ----------------------------------------------------------------------

SYNC_FILE = os.path.join(ROOT, "build", "sync.json")


def load_offset() -> float:
    """读取上次调好的同步偏移（秒）。正值 = 画面延后。"""
    try:
        with open(SYNC_FILE, encoding="utf-8") as f:
            return float(json.load(f).get("offset", 0.0))
    except Exception:
        return 0.0


def save_offset(v: float) -> None:
    try:
        os.makedirs(os.path.dirname(SYNC_FILE), exist_ok=True)
        with open(SYNC_FILE, "w", encoding="utf-8") as f:
            json.dump({"offset": round(v, 3),
                       "saved": time.strftime("%Y-%m-%d %H:%M:%S"),
                       "note": "画面相对音频的偏移（秒）。正 = 画面延后。"},
                      f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def draw_osd(g, offset: float, note: str = "") -> None:
    """在画面底部显示同步状态，几秒后自动消失。"""
    if note:
        msg = " " + note + " "
    else:
        msg = (" SYNC %+.3fs  │  空格 暂停   ←→ 退/进 1s   ↑↓ 5s   "
               "1 对齐首句   2 对齐副歌   [ ] 微调   s 保存   q 退出 "
               % offset)
    w = min(len(msg), g.w)
    x = max(0, (g.w - w) // 2)
    y = g.h - 2
    g.fill_rect(x, y, w, 1, " ", None, (0, 0, 0))
    g.put(x, y, msg[:w], (255, 255, 252), (0, 0, 0), 1)


# ----------------------------------------------------------------------
# 开屏 / 待机界面
# ----------------------------------------------------------------------

def build_splash(cols: int, lines: int, t: float, info: dict):
    """
    终端的待机画面。

    按当前窗口尺寸**直接绘制**，不再固定一张 128×36 再居中贴上去——
    窗口一大，外围就空出一整圈。现在顶栏横跨全宽、两个面板按比例分宽、
    整块内容垂直居中，窗口多高就用多高。
    """
    import bigfont
    import effects as fx
    import theme as T
    from grid import Grid
    from lyrics import PRESCRIPTS

    W = max(40, int(cols))
    H = max(12, int(lines))
    g = Grid(W, H)
    g.clear(T.BG)

    # ---- 顶栏：横跨全宽 ----
    g.put(1, 0, "//PRESCRIPT_TERMINAL", T.WHITE_HOT, attr=1)
    g.put(31, 0, "v2.71.8281", T.DIM2)
    g.put(46, 0, "◈ STANDBY", T.AMBER)
    right = "WILL OF THE CITY ▏LISTENING"
    g.put(max(2, W - 1 - text_width(right)), 0, right, T.STEEL)
    g.hline(0, 1, W, "─", T.DIM2)
    g.put(1, 1, "┤ ", T.DIM2)
    g.put(3, 1, "STANDBY", T.STEEL)

    # ---- 内容块整体垂直居中 ----
    title = "CHILDREN OF THE CITY"
    tw = bigfont.big_width(title)
    BLOCK = 30                                   # 标题 + 面板 + 提示的总高度
    top = max(3, (H - BLOCK) // 2)

    # 标题（窄窗口时别让 x 变负）
    bigfont.big_text(g, max(0, (W - tw) // 2), top, title, T.WHITE_HOT,
                     shadow=T.BLOOD_DARK, progress=1.0)
    g.put_centered(top + 8, "都 市 之 子", T.PAPER)
    g.put_centered(top + 9, "Mili  —  Children of the City", T.NEON_CYAN)
    g.put_centered(top + 10, "ANSI TERMINAL MV  /  THE INDEX", T.DIM2)

    # ---- 两个面板：按窗口宽度分配 ----
    py = top + 12
    gap = 4
    margin = 4
    pw = max(20, (W - margin * 2 - gap) // 2)
    ph = max(8, min(24, H - py - 8))     # 窗口高就把面板拉长，多列几条队列

    # 左：会话状态
    panel(g, margin, py, pw, ph, "SYSTEM", T.DIM2, T.STEEL)
    rows = [
        ("TERMINAL", "%d × %d CHARS" % (info["cols"], info["lines"])),
        ("FRAME", "%d × %d" % (cols, lines)),
        ("AUDIO", "[ %s ]" % info["audio"]),
        ("TIMELINE", "[ %s ]" % str(info["timeline"]).upper()),
        ("SYNC", "%+.3f s" % info["offset"]),
    ]
    for i, (k2, v) in enumerate(rows):
        if i >= ph - 3:
            break
        c = T.TERM_GREEN
        if k2 == "AUDIO" and "READY" not in v:
            c = T.AMBER
        if k2 == "TIMELINE" and "LRC" in v:
            c = T.WHITE_HOT
        C_kv(g, margin + 2, py + 1 + i, k2, v, c)

    # 右：指令队列。
    # 只列编号、校验和、状态——**不印歌词**。待机画面是还没开始的时候，
    # 把 33 条正文摆出来等于先把内容抖了，而且要的就是"还不知道是什么"。
    rx = margin + pw + gap
    panel(g, rx, py, pw, ph, "QUEUE", T.DIM2, T.STEEL)
    room = max(1, ph - 3)                        # 留一行给状态
    # 每行放 2 组，窗口宽就多塞几列
    per_row = max(1, (pw - 4) // 22)
    total = min(room * per_row, len(PRESCRIPTS))
    for i in range(total):
        col, row = divmod(i, room)
        x = rx + 2 + col * 22
        y = py + 1 + row
        g.put(x, y, "%02d" % (i + 1), T.DIM2, T.BG)
        g.put(x + 4, y, "%08X" % (int(fx.h01(i, 14) * 0xFFFFFFFF)), T.ASH, T.BG)
        g.put(x + 14, y, "PEND", T.STEEL, T.BG)
    sy = py + ph - 2
    g.put(rx + 2, sy, "…", T.DIM2, T.BG)
    g.put(rx + 5, sy, "%d PENDING" % len(PRESCRIPTS), T.STEEL, T.BG)
    g.put(rx + 20, sy, "00 EXECUTED", T.TERM_GREEN, T.BG)
    if int(t * 2) % 2 == 0:
        g.put(rx + 32, sy, "▌", T.TERM_GREEN, T.BG)

    # ---- 底部：扫描线 + 提示 ----
    hy = py + ph + 2
    # 扫描线要留够 6 行才画，否则会和下面的提示撞在一起
    if hy + 6 < H:
        g.hline(0, hy, W, "─", T.DIM2)
        sweep = int((t * 26) % (W + 40)) - 20
        for i in range(-8, 9):
            x = sweep + i
            if 0 <= x < W:
                kk = 1.0 - abs(i) / 9.0
                g.put(x, hy, "─", T.lerp(T.DIM2, T.NEON_CYAN, kk))
        my = hy + 3
    else:
        my = hy
    # 三行提示（my / my+2 / my+4）都得落在画面里
    my = min(my, H - 5)

    blink = int(t * 2.2) % 2 == 0
    msg = "按 任 意 键 开 始"
    g.put_centered(my, msg if blink else " " * len(msg), T.WHITE_HOT, attr=1)
    if my + 2 < H:
        g.put_centered(my + 2, "都市的意志已就绪。阅读即视为同意执行。", T.DIM)
    if my + 4 < H:
        g.put_centered(my + 4, "PRESCRIPT 01/33 已签发", T.BLOOD)

    return g

def panel(g, x, y, w, h, title, fg, title_color):
    g.box(x, y, w, h, fg, None, "double")
    if title:
        g.put(x + 2, y, " " + title + " ", title_color, (6, 7, 9))


def C_kv(g, x, y, k, v, vc):
    import theme as T
    g.put(x, y, k.ljust(11), T.DIM2, T.BG)
    g.put(x + 11, y, v, vc, T.BG)


def draw_paused(g) -> None:
    """暂停时盖在画面中间的提示。"""
    msg = "⏸  已 暂 停"
    w = text_width(msg) + 8
    x = max(0, (g.w - w) // 2)
    y = max(2, g.h // 2 - 1)
    g.fill_rect(x, y, w, 3, " ", None, (0, 0, 0))
    g.box(x, y, w, 3, (255, 178, 64), (0, 0, 0), "heavy")
    g.put(x + 4, y + 1, msg, (255, 255, 252), (0, 0, 0), 1)
    tip = "空格继续   ←→ 退/进 1s   q 退出"
    g.put(max(0, (g.w - 1 - text_width(tip)) // 2), y + 4, tip,
          (150, 150, 150), (0, 0, 0))


def wait_for_key(cols: int, lines: int, info_fn) -> str:
    """
    开屏等待。返回 "start" 或 "quit"。

    等待期间持续跟踪窗口尺寸——你可以在这时候把窗口拖大，
    界面会自己跟着重排。
    """
    scr = Screen()
    out = sys.stdout
    out.write(ALT_ON + WRAP_OFF + CUR_HIDE + CLEAR)
    out.flush()
    t0 = time.perf_counter()
    try:
        while True:
            cur = term_size()
            if cur != (cols, lines) and cur[0] > 20 and cur[1] > 10:
                cols, lines = cur
                scr.prev = None
                out.write(CLEAR)
            g = build_splash(cols, lines, time.perf_counter() - t0,
                             info_fn(cols, lines))
            s = scr.emit(g)
            if s:
                out.write(s)
                out.flush()
            try:
                import msvcrt
                if msvcrt.kbhit():
                    c = msvcrt.getch()
                    if c in (b"q", b"Q", b"\x1b"):
                        return "quit"
                    # 吃掉方向键的第二字节，避免它被当成开始键之后的输入
                    if c in (b"\x00", b"\xe0"):
                        msvcrt.getch()
                        continue
                    return "start"
            except ImportError:
                return "start"
            time.sleep(1.0 / 15)
    finally:
        # 无论"开始"还是"退出"都先把终端还原；
        # 主循环会自己重新进入备用屏幕缓冲，重复进入是幂等的。
        out.write(RESET + WRAP_ON + CUR_SHOW + ALT_OFF)
        out.flush()


class MciPlayer:
    """用 Windows 的 MCI 播放 mp3，并把播放位置当作主时钟。"""

    def __init__(self, path: str, alias: str = "dshmv"):
        self.alias = alias
        self.ok = False
        self.buf = ctypes.create_unicode_buffer(512)
        if os.name != "nt":
            return
        try:
            self.mci = ctypes.windll.winmm.mciSendStringW
        except Exception:
            return
        p = path
        try:
            k = ctypes.windll.kernel32
            need = k.GetShortPathNameW(path, None, 0)
            if need:
                sb = ctypes.create_unicode_buffer(need)
                if k.GetShortPathNameW(path, sb, need):
                    p = sb.value
        except Exception:
            pass
        err = self._cmd('open "%s" type mpegvideo alias %s' % (p, alias))
        if err:
            err = self._cmd('open "%s" alias %s' % (p, alias))
        if err:
            print("[!] MCI 打开音频失败（错误码 %d），将使用内部计时。" % err)
            return
        self._cmd("set %s time format milliseconds" % alias)
        self.ok = True

    def _cmd(self, s: str) -> int:
        return int(self.mci(s, self.buf, 512, 0))

    def play(self, from_ms: int = 0) -> None:
        if not self.ok:
            return
        if from_ms > 0:
            self._cmd("seek %s to %d" % (self.alias, from_ms))
        self._cmd("play %s" % self.alias)

    def warmup(self) -> None:
        """
        预热音频设备。

        MCI 的 play 是异步的：命令返回时声音还没出来，但 position 已经从 0
        开始计时了——这就是"字母比音乐早"的来源之一。
        先静音跑一小段再停下，正式播放时的启动延迟会明显缩短。
        """
        if not self.ok:
            return
        self._cmd("set %s volume to 0" % self.alias)
        self._cmd("play %s" % self.alias)
        time.sleep(0.30)
        self._cmd("stop %s" % self.alias)
        self._cmd("seek %s to 0" % self.alias)
        self._cmd("set %s volume to 1000" % self.alias)

    def position_ms(self):
        if not self.ok:
            return None
        if self._cmd("status %s position" % self.alias) != 0:
            return None
        try:
            return int(self.buf.value)
        except ValueError:
            return None

    def seek_ms(self, ms: int, keep_paused: bool = False) -> None:
        """
        跳到指定毫秒（方向键快进/快退用）。

        seek 之后播放有可能停住，所以顺手确认一下 mode，
        不是 playing 就重新 play——否则快退一次画面就再也不动了。

        keep_paused=True 时不做这个补播：暂停状态下跳转，跳完还得是暂停的。
        """
        if not self.ok:
            return
        self._cmd("seek %s to %d" % (self.alias, max(0, int(ms))))
        if keep_paused:
            return
        if self._cmd("status %s mode" % self.alias) == 0:
            if self.buf.value != "playing":
                self._cmd("play %s" % self.alias)

    def pause_audio(self) -> None:
        if self.ok:
            self._cmd("pause %s" % self.alias)

    def resume_audio(self) -> None:
        """
        继续播放。

        注意：MCI 的 seek 会把 paused 变成 stopped，
        这时 resume 是空操作——必须改用 play，否则暂停中跳转一次
        就永远起不来了（实测踩到过）。
        """
        if not self.ok:
            return
        mode = ""
        if self._cmd("status %s mode" % self.alias) == 0:
            mode = self.buf.value
        if mode == "paused":
            self._cmd("resume %s" % self.alias)
        elif mode != "playing":
            self._cmd("play %s" % self.alias)

    def close(self) -> None:
        if self.ok:
            self._cmd("stop %s" % self.alias)
            self._cmd("close %s" % self.alias)
            self.ok = False


# ----------------------------------------------------------------------
# 帧 → ANSI
# ----------------------------------------------------------------------

class Screen:
    def __init__(self):
        self.prev = None
        self.buf = []

    def emit(self, g) -> str:
        """只输出变化的行。"""
        rows = g.diff_rows(self.prev)
        if self.prev is None or self.prev.w != g.w or self.prev.h != g.h:
            self.buf.append(CLEAR)
        out = self.buf
        for y, cells in rows:
            out.append("\x1b[%d;1H" % (y + 1))
            cur_fg = cur_bg = cur_at = None
            for x, ch, fg, bg, at in cells:
                if ch == CONTINUE:
                    continue
                if ch == " " and bg is None:
                    continue
                if fg != cur_fg or at != cur_at:
                    out.append("\x1b[39m" if fg is None
                               else "\x1b[38;2;%d;%d;%dm" % fg)
                    if at & 1:
                        out.append("\x1b[1m")
                    elif cur_at:
                        out.append("\x1b[22m")
                    cur_fg, cur_at = fg, at
                if bg != cur_bg:
                    out.append("\x1b[49m" if bg is None
                               else "\x1b[48;2;%d;%d;%dm" % bg)
                    cur_bg = bg
                out.append(ch)
            out.append(RESET)
            out.append("\x1b[K")
        if rows:
            s = "".join(out)
            self.buf = []
            self.prev = g
            return s
        self.buf = []
        return ""


# ----------------------------------------------------------------------
# 播放
# ----------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float, default=0.0, help="到这一刻停止（0 = 播完）")
    ap.add_argument("--fps", type=float, default=24.0)
    ap.add_argument("--silent", action="store_true")
    ap.add_argument("--force", action="store_true", help="跳过窗口尺寸检查")
    ap.add_argument("--no-wait", action="store_true", help="跳过开屏待机界面")
    ap.add_argument("--record", default="", help="录成 asciinema .cast 文件")
    ap.add_argument("--record-fps", type=float, default=12.0)
    ap.add_argument("--offset", type=float, default=None,
                    help="画面相对音频的偏移秒数（正=画面延后）。"
                         "播放时可用 [ ] 实时调整，s 保存")
    args = ap.parse_args()

    enable_utf8_console()

    recording = bool(args.record)
    cols, lines = term_size()
    if not args.force and (cols < GRID_W or lines < GRID_H):
        if try_resize(GRID_W, GRID_H):
            time.sleep(0.25)
            cols, lines = term_size()
    if cols < GRID_W or lines < GRID_H:
        # 不再拒绝运行：画面会居中裁掉一部分，总比什么都不显示好
        print("[!] 当前窗口 %d×%d，小于画面的 %d×%d，会被裁掉一部分。"
              % (cols, lines, GRID_W, GRID_H))
        print("    把窗口拖大，或按 Alt+Enter 全屏。仍然继续……")
        time.sleep(1.4)

    if not enable_vt():
        print("[!] 该终端不支持 VT 转义序列，画面会错乱。建议使用 Windows Terminal。")
        print("    仍然继续……")

    tl = TL.load()
    d = director.Director(TL.to_director(tl))
    total = args.end if args.end > 0 else tl["duration"]

    offset = args.offset if args.offset is not None else load_offset()
    if args.offset is not None:
        save_offset(offset)

    music = None
    if not args.silent and not recording:
        music = MciPlayer(MP3)
        if music.ok:
            music.warmup()          # 先把音频设备叫醒，减少 play 的启动延迟

    # ---- 开屏待机：确认窗口、音频、时间轴都就绪了再开演 ----
    interactive = True
    try:
        interactive = sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        interactive = False
    if not (args.no_wait or args.force or recording or not interactive):
        def info_fn(c, l):
            if music is not None and music.ok:
                audio = "READY / MCI"
            elif args.silent:
                audio = "SILENT / 手动"
            else:
                audio = "UNAVAILABLE"
            return {
                "cols": c, "lines": l,
                "audio": audio,
                "timeline": tl.get("source", "?"),
                "offset": offset,
            }

        if wait_for_key(cols, lines, info_fn) == "quit":
            if music is not None:
                music.close()
            return 0

    if music is not None and music.ok:
        music.play(int(args.start * 1000))
    elif not args.silent and not recording:
        print("[!] 未能播放音频。请手动播放 assets/children_of_the_city.mp3，")
        print("    并按回车开始，让画面与音乐对齐。")
        try:
            input()
        except EOFError:
            pass

    scr = Screen()
    fps = args.record_fps if recording else args.fps
    budget = 1.0 / fps
    out = sys.stdout
    cast = None
    if recording:
        cast = open(args.record, "w", encoding="utf-8")
        cast.write(json.dumps({
            "version": 2, "width": GRID_W, "height": GRID_H,
            "timestamp": int(time.time()),
            "env": {"TERM": "xterm-256color", "SHELL": "index-terminal"},
            "title": "Children of the City - ANSI MV",
        }) + "\n")
        print("[*] 录制中 → %s（%.0f fps）" % (args.record, fps))

    t_wall = time.perf_counter()
    frames = 0
    t = args.start
    last_size = (cols, lines)
    seek_pending = None      # 待执行的跳转目标（毫秒），连按会累加
    shift = 0.0              # 静音模式下靠它挪画面
    paused = False
    pause_mark = 0.0
    osd_until = 0.0          # 开播不弹提示条，免得压住画面
    osd_note = ""            # 按键时才会临时显示
    if not recording:
        out.write(ALT_ON + WRAP_OFF + CUR_HIDE + CLEAR)
        out.flush()
    try:
        while True:
            # --- 窗口被拖大/拖小时要重画整屏，否则会留下残影 ---
            cur = term_size()
            if cur != last_size and cur[0] > 20 and cur[1] > 10:
                last_size = cur
                cols, lines = cur
                scr.prev = None            # 强制全量重绘
                if not recording:
                    out.write(CLEAR)

            if music is not None and music.ok:
                ms = music.position_ms()
                audio_t = (ms / 1000.0) if ms is not None else \
                    (args.start + (time.perf_counter() - t_wall))
            else:
                audio_t = args.start + (time.perf_counter() - t_wall)
            # 方向键攒下的跳转在这里一次性执行
            if seek_pending is not None:
                if music is not None and music.ok:
                    music.seek_ms(seek_pending, keep_paused=paused)
                else:
                    shift = seek_pending / 1000.0 - audio_t - offset
                seek_pending = None
                scr.prev = None          # 跳转可能跨场景，整屏重画

            t = audio_t + offset + shift
            if t >= total:
                break

            g = d.frame(t, cols, lines)
            if paused:
                draw_paused(g)
            if paused or time.time() < osd_until:
                draw_osd(g, offset, osd_note)
            s = scr.emit(g)
            if s:
                if cast is not None:
                    cast.write(json.dumps([round(t, 3), "o", s]) + "\n")
                else:
                    out.write(s)
                    if not args.force:
                        out.flush()

            frames += 1
            try:
                import msvcrt
                while msvcrt.kbhit():
                    c = msvcrt.getch()
                    if c in (b"q", b"Q", b"\x1b"):
                        raise KeyboardInterrupt
                    elif c == b" ":
                        # 空格：暂停 / 继续
                        paused = not paused
                        if music is not None and music.ok:
                            if paused:
                                music.pause_audio()
                            else:
                                music.resume_audio()
                        else:
                            # 没有音频时靠挪挂钟基准来"冻结"时间
                            if paused:
                                pause_mark = time.perf_counter()
                            else:
                                t_wall += time.perf_counter() - pause_mark
                        osd_until = time.time() + 2.5
                        osd_note = "⏸ 已暂停" if paused else "▶ 继续"
                        scr.prev = None
                    elif c in (b"\x00", b"\xe0"):
                        # 方向键：← → 退/进 1 秒，↑ ↓ 退/进 5 秒
                        c2 = msvcrt.getch()
                        step = {b"K": -1.0, b"M": 1.0,
                                b"P": -5.0, b"H": 5.0}.get(c2)
                        if step is not None:
                            base = seek_pending
                            if base is None:
                                if music is not None and music.ok:
                                    base = music.position_ms() or 0
                                else:
                                    base = int((audio_t + shift) * 1000)
                            seek_pending = max(
                                0, min(int(total * 1000),
                                       base + int(step * 1000)))
                            osd_until = time.time() + 1.8
                            osd_note = "%s %.0f 秒 → %02d:%02d" % (
                                "⏪ 回退" if step < 0 else "⏩ 快进", abs(step),
                                seek_pending // 60000,
                                (seek_pending // 1000) % 60)
                    elif c == b"1":
                        # 听到第一句开口的瞬间按 1：只重排主歌 1，后面段落一个不动
                        new_tl = TL.retime_first_line(audio_t)
                        d = director.Director(TL.to_director(new_tl))
                        scr.prev = None
                        osd_until = time.time() + 4.0
                        osd_note = ("已钉住第一句 %.2f s —— 主歌重排，副歌未动（已保存）"
                                    % audio_t)
                    elif c == b"2":
                        # 听到副歌第一句开口的瞬间按 2：只重排副歌 1
                        tl2 = TL.load()
                        spans = [list(s) for s in tl2["spans"]]
                        k0 = next((i for i, s in enumerate(spans)
                                   if int(s[2]) == 10), None)
                        k2 = next((i for i, s in enumerate(spans)
                                   if int(s[2]) == 12), None)
                        if k0 is not None and k2 is not None:
                            end = float(spans[k2][1])
                            start = max(0.0, float(audio_t))
                            n = k2 - k0 + 1
                            if end - start > n * 0.5:
                                step = (end - start) / n
                                for k in range(n):
                                    j = k0 + k
                                    spans[j][0] = round(start + step * k, 3)
                                    spans[j][1] = round(start + step * (k + 1), 3)
                                tl2["spans"] = spans
                                tl2["source"] = "one-key-calibration"
                                TL.save(tl2)
                                d = director.Director(TL.to_director(TL.load()))
                                scr.prev = None
                                osd_until = time.time() + 4.0
                                osd_note = "已钉住副歌第一句 %.2f s（已保存）" % audio_t
                    elif c == b"[":
                        offset -= 0.05
                        osd_until = time.time() + 3.0
                        osd_note = ""
                    elif c == b"]":
                        offset += 0.05
                        osd_until = time.time() + 3.0
                        osd_note = ""
                    elif c == b"\\":
                        offset = 0.0
                        osd_until = time.time() + 3.0
                        osd_note = "同步偏移已归零"
                    elif c in (b"s", b"S"):
                        save_offset(offset)
                        osd_until = time.time() + 3.0
                        osd_note = "已保存 %+.3f s" % offset
            except ImportError:
                pass

            nxt = t_wall + frames * budget
            slack = nxt - time.perf_counter()
            if slack > 0:
                time.sleep(slack)
    except KeyboardInterrupt:
        pass
    finally:
        if music is not None:
            music.close()
        if cast is not None:
            cast.close()
            print("[*] 已录制到 %s" % args.record)
        if not args.force and not recording:
            out.write(RESET + WRAP_ON + CUR_SHOW + ALT_OFF)
            out.flush()
            print("已停止。都市的指令队列仍在继续。(t=%.1fs)" % t)
    return 0


if __name__ == "__main__":
    sys.exit(main())

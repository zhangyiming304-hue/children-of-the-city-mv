# -*- coding: utf-8 -*-
"""
grid.py —— ANSI MV 的"像素层"。

整个 MV 的每一帧都是一块字符网格（char grid）：
每个格子保存 (字符, 前景色, 背景色, 属性)。
终端播放器、HTML 导出、视频渲染三条输出管线共用这一层，
因此"作品内容"只写一次。

坐标系：x 为列（0 起），y 为行（0 起）。
宽字符（CJK）占两列：左格放字符，右格放占位符 CONTINUE。
"""

from __future__ import annotations

import unicodedata

# 宽字符右半边的占位符（不会被真正打印）
CONTINUE = "\x00"

BOLD = 1
DIM = 2
ITALIC = 4
REVERSE = 8
UNDERLINE = 16


def char_width(ch: str) -> int:
    """返回字符在等宽终端中占用的列数。"""
    if ch == CONTINUE:
        return 0
    if unicodedata.combining(ch):
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    return 1


def text_width(s: str) -> int:
    """字符串的显示宽度（列数）。"""
    return sum(char_width(c) for c in s)


def truncate(s: str, width: int) -> str:
    """按显示宽度截断字符串。"""
    out = []
    used = 0
    for ch in s:
        w = char_width(ch)
        if used + w > width:
            break
        out.append(ch)
        used += w
    return "".join(out)


def pad_to(s: str, width: int, align: str = "left") -> str:
    """把字符串补齐/截断到指定显示宽度。align: left/right/center"""
    s = truncate(s, width)
    fill = width - text_width(s)
    if fill <= 0:
        return s
    if align == "left":
        return s + " " * fill
    if align == "right":
        return " " * fill + s
    left = fill // 2
    return " " * left + s + " " * (fill - left)


class Grid:
    """一块字符网格画布。"""

    __slots__ = ("w", "h", "ch", "fg", "bg", "at", "_dirty")

    def __init__(self, w: int, h: int):
        self.w = w
        self.h = h
        n = w * h
        self.ch = [" "] * n
        self.fg = [None] * n
        self.bg = [None] * n
        self.at = [0] * n
        self._dirty = True

    # ---------- 基础 ----------

    def clone_from(self, other: "Grid") -> None:
        self.ch = list(other.ch)
        self.fg = list(other.fg)
        self.bg = list(other.bg)
        self.at = list(other.at)

    def clear(self, bg=None) -> None:
        n = self.w * self.h
        self.ch = [" "] * n
        self.fg = [None] * n
        self.bg = [bg] * n
        self.at = [0] * n

    def inside(self, x: int, y: int) -> bool:
        return 0 <= x < self.w and 0 <= y < self.h

    def put(self, x: int, y: int, text: str, fg=None, bg=None, attr: int = 0) -> int:
        """在 (x, y) 写入文本，返回写入后的下一个 x。越界自动裁剪。"""
        if y < 0 or y >= self.h:
            return x
        cx = x
        base = y * self.w
        for c in text:
            cw = char_width(c)
            if cw == 0:
                continue
            if cx >= self.w:
                break
            if cx >= 0:
                self.ch[base + cx] = c
                self.fg[base + cx] = fg
                if bg is not None:
                    self.bg[base + cx] = bg
                self.at[base + cx] = attr
                if cw == 2:
                    if cx + 1 < self.w:
                        self.ch[base + cx + 1] = CONTINUE
                        self.fg[base + cx + 1] = fg
                        if bg is not None:
                            self.bg[base + cx + 1] = bg
                        self.at[base + cx + 1] = attr
            cx += cw
        return cx

    def put_centered(self, y: int, text: str, fg=None, bg=None, attr: int = 0) -> None:
        x = (self.w - text_width(text)) // 2
        self.put(x, y, text, fg, bg, attr)

    def put_right(self, x_end: int, y: int, text: str, fg=None, bg=None, attr: int = 0) -> None:
        self.put(x_end - text_width(text), y, text, fg, bg, attr)

    def fill_rect(self, x: int, y: int, w: int, h: int, ch: str = " ", fg=None, bg=None) -> None:
        for yy in range(max(0, y), min(self.h, y + h)):
            base = yy * self.w
            for xx in range(max(0, x), min(self.w, x + w)):
                self.ch[base + xx] = ch
                self.fg[base + xx] = fg
                self.bg[base + xx] = bg

    def hline(self, x: int, y: int, w: int, ch: str = "─", fg=None, bg=None) -> None:
        if 0 <= y < self.h:
            base = y * self.w
            for xx in range(max(0, x), min(self.w, x + w)):
                self.ch[base + xx] = ch
                self.fg[base + xx] = fg
                if bg is not None:
                    self.bg[base + xx] = bg

    def vline(self, x: int, y: int, h: int, ch: str = "│", fg=None, bg=None) -> None:
        if 0 <= x < self.w:
            for yy in range(max(0, y), min(self.h, y + h)):
                self.ch[yy * self.w + x] = ch
                self.fg[yy * self.w + x] = fg
                if bg is not None:
                    self.bg[yy * self.w + x] = bg

    def box(self, x: int, y: int, w: int, h: int, fg=None, bg=None, style: str = "light") -> None:
        """画一个边框。style: light(─│┌┐└┘) / double(═║╔╗╚╝) / heavy / ascii(+ - |)"""
        if w < 2 or h < 2:
            return
        chars = {
            "light": ("─", "│", "┌", "┐", "└", "┘"),
            "double": ("═", "║", "╔", "╗", "╚", "╝"),
            "heavy": ("━", "┃", "┏", "┓", "┗", "┛"),
            "ascii": ("-", "|", "+", "+", "+", "+"),
            "dashed": ("┄", "┊", "┌", "┐", "└", "┘"),
        }[style]
        hl, vl, tl, tr, bl, br = chars
        self.hline(x + 1, y, w - 2, hl, fg, bg)
        self.hline(x + 1, y + h - 1, w - 2, hl, fg, bg)
        self.vline(x, y + 1, h - 2, vl, fg, bg)
        self.vline(x + w - 1, y + 1, h - 2, vl, fg, bg)
        self.put(x, y, tl, fg, bg)
        self.put(x + w - 1, y, tr, fg, bg)
        self.put(x, y + h - 1, bl, fg, bg)
        self.put(x + w - 1, y + h - 1, br, fg, bg)

    # ---------- 差分 ----------

    def diff_rows(self, other: "Grid"):
        """返回 [(row, [ (x, ch, fg, bg, attr), ... ]), ...]，只包含发生变化的行。"""
        if other is None or other.w != self.w or other.h != self.h:
            rows = []
            for y in range(self.h):
                cells = []
                for x in range(self.w):
                    i = y * self.w + x
                    cells.append((x, self.ch[i], self.fg[i], self.bg[i], self.at[i]))
                rows.append((y, cells))
            return rows
        rows = []
        for y in range(self.h):
            base = y * self.w
            changed = any(
                self.ch[base + x] != other.ch[base + x]
                or self.fg[base + x] != other.fg[base + x]
                or self.bg[base + x] != other.bg[base + x]
                or self.at[base + x] != other.at[base + x]
                for x in range(self.w)
            )
            if not changed:
                continue
            cells = []
            for x in range(self.w):
                i = base + x
                cells.append((x, self.ch[i], self.fg[i], self.bg[i], self.at[i]))
            rows.append((y, cells))
        return rows


def blank(w: int, h: int, bg=None) -> Grid:
    g = Grid(w, h)
    g.clear(bg)
    return g


def blit(dst: Grid, src: Grid, ox: int, oy: int) -> None:
    """
    把 src 贴到 dst 的 (ox, oy) 处，越界自动裁剪。

    这是"画面自适应窗口"的关键：主画面永远是 128×36 的字符网格，
    窗口比它大时居中贴上去，比它小时居中裁掉边缘，都不需要场景代码知道。
    """
    x0 = max(0, -ox)
    y0 = max(0, -oy)
    x1 = min(src.w, dst.w - ox)
    y1 = min(src.h, dst.h - oy)
    if x1 <= x0 or y1 <= y0:
        return
    n = x1 - x0
    for y in range(y0, y1):
        s = y * src.w + x0
        d = (y + oy) * dst.w + ox + x0
        dst.ch[d:d + n] = src.ch[s:s + n]
        dst.fg[d:d + n] = src.fg[s:s + n]
        dst.bg[d:d + n] = src.bg[s:s + n]
        dst.at[d:d + n] = src.at[s:s + n]

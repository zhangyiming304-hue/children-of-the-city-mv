# -*- coding: utf-8 -*-
"""
pitch_vocal.py —— 用基频轨迹找人声。

前面几种方法都不够可靠：
  · 能量包络       —— 编曲一满就分不出人声
  · 3–6 Hz 调制    —— 漏检严重（副歌整段检不出来）
  · 立体声 side/mid —— 反映的是编曲宽度，不是人声

换个更本质的特征：**唱歌是有音高的，而且音高在动。**

    · 底鼓、镲片、噪声   —— 没有稳定基频
    · 贝斯               —— 有基频，但低且平稳
    · 合成器 pad         —— 有基频，但几乎是直的
    · 人声               —— 基频落在 80–500 Hz，而且一直在起伏

所以对每一帧做一次谐波求和，找出最可能的基频 f0，
再沿着时间看这条 f0 轨迹：**有值、在中频、而且在动** 的段落就是人声。

输出 1 秒一格的可读表 + build/pitch.json。
"""

from __future__ import annotations

import json
import os
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

SR = 22050
NFFT = 2048
HOP = 256                 # 更细的时间分辨率
FR = SR / HOP

F0_MIN, F0_MAX = 80.0, 520.0
F0_STEP = 2.0
N_HARM = 6


def load():
    with wave.open(os.path.join(ROOT, "build", "analysis.wav"), "rb") as w:
        raw = w.readframes(w.getnframes())
    return np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0


def smooth(a, k):
    k = max(1, int(k))
    return np.convolve(a, np.ones(k) / k, mode="same")


def main():
    x = load()
    n = 1 + (len(x) - NFFT) // HOP
    idx = np.arange(NFFT)[None, :] + HOP * np.arange(n)[:, None]
    win = np.hanning(NFFT).astype(np.float32)
    spec = np.abs(np.fft.rfft(x[idx] * win, axis=1)) + 1e-10
    freqs = np.fft.rfftfreq(NFFT, 1.0 / SR)
    print("[*] %d 帧 @ %.1f fps  (%.1f s)" % (n, FR, len(x) / SR))

    # ---- 谐波求和找 f0 ----
    cands = np.arange(F0_MIN, F0_MAX, F0_STEP)
    # 预先算好每个候选基频的各次谐波落在哪个 bin
    harm_bins = []
    harm_valid = []
    for f0 in cands:
        bins, ok = [], True
        for h in range(1, N_HARM + 1):
            fh = f0 * h
            if fh >= SR / 2 - 100:
                break
            b = int(round(fh / (SR / NFFT)))
            if b >= len(freqs):
                ok = False
                break
            bins.append(b)
        harm_bins.append(bins)
        harm_valid.append(ok and len(bins) >= 3)

    # 逐帧：对每个候选求和（向量化到候选维）
    sal = np.zeros((n, len(cands)), dtype=np.float32)
    for ci, bins in enumerate(harm_bins):
        if not harm_valid[ci]:
            continue
        sal[:, ci] = spec[:, bins].sum(axis=1)
    # 归一化掉整体响度的影响
    total = spec.sum(axis=1, keepdims=True) + 1e-9
    sal_n = sal / total

    best = np.argmax(sal_n, axis=1)
    f0 = cands[best]
    conf = sal_n[np.arange(n), best]

    # ---- 轨迹特征 ----
    conf_s = smooth(conf, 0.15 * FR)
    # 音高变化率：轨迹在动才像唱歌
    f0s = smooth(f0, 0.12 * FR)
    d = np.abs(np.diff(f0s, prepend=f0s[0]))
    move = smooth(d, 0.25 * FR)

    # 中频带能量占比
    mid = (freqs >= 300) & (freqs <= 3400)
    midratio = smooth((spec[:, mid].sum(axis=1) / (spec.sum(axis=1) + 1e-9)),
                      0.2 * FR)
    midratio = midratio / (midratio.max() + 1e-9)

    def norm(a):
        lo, hi = np.percentile(a, 5), np.percentile(a, 97)
        return np.clip((a - lo) / (hi - lo + 1e-9), 0, 1)

    nc, nm, nr = norm(conf_s), norm(move), norm(midratio)
    score = 0.45 * nc + 0.35 * nm + 0.20 * nr

    t = np.arange(n) / FR
    sec = int(FR)
    print("\n" + "=" * 92)
    print("每格 1 秒。 C=基频置信度  M=音高变化率  R=中频占比  S=综合人声指标(0-9)")
    print("=" * 92)
    rows = []
    for i in range(0, n - sec, sec):
        rows.append((int(t[i]),
                     float(nc[i:i + sec].mean()),
                     float(nm[i:i + sec].mean()),
                     float(nr[i:i + sec].mean()),
                     float(score[i:i + sec].mean())))
    for i in range(0, len(rows), 16):
        ch = rows[i:i + 16]
        f = lambda k: "".join(str(min(9, int(r[k] * 10))) for r in ch)  # noqa: E731
        print("  t=%3d  C:%s  M:%s  R:%s  S:%s" % (ch[0][0], f(1), f(2), f(3), f(4)))

    # ---- 找出人声段落 ----
    thr = float(np.percentile(score, 58))
    act = score > thr
    segs, start = [], None
    minlen = int(0.7 * FR)
    for i, a in enumerate(act):
        if a and start is None:
            start = i
        elif not a and start is not None:
            if i - start >= minlen:
                segs.append((round(float(t[start]), 2), round(float(t[i]), 2)))
            start = None
    if start is not None:
        segs.append((round(float(t[start]), 2), round(float(t[-1]), 2)))
    merged = []
    for a, b in segs:
        if merged and a - merged[-1][1] < 1.5:
            merged[-1] = (merged[-1][0], b)
        else:
            merged.append((a, b))
    merged = [(a, b) for a, b in merged if b - a > 1.2]
    print("\n检出 %d 段人声：" % len(merged))
    for a, b in merged:
        print("   %7.2f → %7.2f  (%5.2f s)" % (a, b, b - a))
    print("   合计 %.1f s / %.1f s" % (sum(b - a for a, b in merged), t[-1]))

    with open(os.path.join(ROOT, "build", "pitch.json"), "w",
              encoding="utf-8") as f:
        json.dump({"segments": merged,
                   "t": [round(float(v), 2) for v in t[::sec]],
                   "score": [round(float(v), 4) for v in score[::sec]],
                   "f0": [round(float(v), 1) for v in f0s[::sec]]}, f)
    print("\n已写出 build/pitch.json")


if __name__ == "__main__":
    main()
